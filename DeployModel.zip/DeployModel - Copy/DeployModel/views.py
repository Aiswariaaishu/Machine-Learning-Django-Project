from django.http import HttpResponse
from django.shortcuts import render
#from urllib import request
#import requests
from django.shortcuts import render
import joblib
from sklearn.preprocessing import LabelEncoder

def home(request):
    return render(request,'home.html')

def result(request):


    #linearmodel =joblib.load('finalized_modeltwo.sav')
    xgb_model =joblib.load('finalized_modelxgb.sav')
    # knn = joblib.load('finalized_modelknn.sav')
    lis = []
    lis.append(request.GET['deptn'])
    lis.append(request.GET['majorn'])
    lis.append(request.GET['degreen'])
    lis.append(request.GET['schooln'])
    lis.append(request.GET['titlen'])

    lis2 = []


    if request.GET['deptn'] == 'Police':
        lis2.append(25)
    elif request.GET['deptn'] == 'Health & Human Services':
        lis2.append(14)

    elif request.GET['deptn'] == 'Finance':
        lis2.append(11)
    elif request.GET['deptn'] == 'County Attorney':
        lis2.append(6)
    elif request.GET['deptn'] == 'Community Use Public Facilities':
        lis2.append(3)
    elif request.GET['deptn'] == 'Public Information':
        lis2.append(27)
    elif request.GET['deptn'] == "State's Attorney":
        lis2.append(30)
    elif request.GET['deptn'] == "General Services":
        lis2.append(13)
    elif request.GET['deptn'] == "Fire/Rescue Services":
        lis2.append(12)
    elif request.GET['deptn'] == "Correction & Rehabilitation":
       lis2.append(5)
    elif request.GET['deptn'] == "Housing & Community Affairs":
          lis2.append(15)
    elif request.GET['deptn'] == "County Council":
          lis2.append(7)
    elif request.GET['deptn'] == 'Technology Services':
          lis2.append(31)
    elif request.GET['deptn'] == "Transportation":
          lis2.append(32)
    elif request.GET['deptn'] == "Environmental Protection":
          lis2.append(10)
    elif request.GET['deptn'] == "Recreation":
          lis2.append(28)
    elif request.GET['deptn'] == 'County Executive':
         lis2.append(8)
    elif request.GET['deptn'] == "Human Resources":
         lis2.append(16)
    elif request.GET['deptn'] == "General Services":
         lis2.append(13)
    elif request.GET['deptn'] == "Libraries":
         lis2.append(20)
    elif request.GET['deptn'] == "Liquor Control":
         lis2.append(21)
    elif request.GET['deptn'] == 'Consumer Protection':
         lis2.append(4)
    elif request.GET['deptn'] == 'Animal services':
         lis2.append(0)
    elif request.GET['deptn'] == 'Permitting Services':
         lis2.append(24)
    elif request.GET['deptn'] == 'Investment Trustees':
         lis2.append(18)
    elif request.GET['deptn'] == 'Management & Budget':
         lis2.append(22)
    elif request.GET['deptn'] == 'Sheriff':
         lis2.append(29)
    elif request.GET['deptn'] == 'Community Engagement Cluster':
         lis2.append(2)
    elif request.GET['deptn'] == 'Procurement':
         lis2.append(26)
    elif request.GET['deptn'] == 'Emergency Mgmt & Homeland Security':
         lis2.append(9)
    elif request.GET['deptn'] == 'Legislative Oversight':
         lis2.append(19)
    elif request.GET['deptn'] == 'Human Rights':
         lis2.append(17)
    elif request.GET['deptn'] == 'Board of Elections':
         lis2.append(1)
    elif request.GET['deptn'] == 'Office of Racial Equity and Social Justice':
         lis2.append(23)


    if request.GET['majorn'] == 'Business/Admin./Mgmt.':
        lis2.append(65)
    elif request.GET['majorn'] == 'Other/Misc.':
        lis2.append(69)
    elif request.GET['majorn'] == 'Accounting (Business)':
        lis2.append(0)
    elif request.GET['majorn'] == 'Pre-Nursing':
        lis2.append(74)
    elif request.GET['majorn'] == 'Masters (MA/MS/MPH/etc.)':
        lis2.append(61)
    elif request.GET['majorn'] == 'Health & Human Services':
        lis2.append(46)
    elif request.GET['majorn'] == 'Information Technology':
        lis2.append(51)
    elif request.GET['majorn'] == 'Communication':
        lis2.append(16)
    elif request.GET['majorn'] == 'Finance (Business)':
        lis2.append(35)
    elif request.GET['majorn'] == 'Criminal Justice':
        lis2.append(22)
    elif request.GET['majorn'] == 'Psychology':
        lis2.append(76)
    elif request.GET['majorn'] == 'Paralegal Studies':
        lis2.append(70)
    elif request.GET['majorn'] == 'African-American Studies':
        lis2.append(2)
    elif request.GET['majorn'] == 'Fire Protection Engineering':
        lis2.append(36)
    elif request.GET['majorn'] == 'Non-Degree':
        lis2.append(64)
    elif request.GET['majorn'] == 'Community Health':
        lis2.append(17)
    elif request.GET['majorn'] == 'Political Science':
        lis2.append(72)
    elif request.GET['majorn'] == 'Government and Politics':
        lis2.append(44)
    elif request.GET['majorn'] == 'Social Work':
        lis2.append(83)
    elif request.GET['majorn'] == 'Agricultural General':
        lis2.append(3)
    elif request.GET['majorn'] == 'Public Administration':
        lis2.append(77)
    elif request.GET['majorn'] == 'General Studies':
        lis2.append(42)
    elif request.GET['majorn'] == 'English Language and Literature':
        lis2.append(30)
    elif request.GET['majorn'] == 'Forensic Science':
        lis2.append(39)
    elif request.GET['majorn'] == 'Fire Science':
        lis2.append(37)
    elif request.GET['majorn'] == 'Civil and Environmental Engineering':
        lis2.append(15)
    elif request.GET['majorn'] == 'Law':
        lis2.append(55)
    elif request.GET['majorn'] == 'Emergency Management':
        lis2.append(28)
    elif request.GET['majorn'] == 'Human Resources':
        lis2.append(48)
    elif request.GET['majorn'] == 'Nursing':
        lis2.append(66)
    elif request.GET['majorn'] == 'Sociology':
        lis2.append(84)
    elif request.GET['majorn'] == 'Job Related':
        lis2.append(53)
    elif request.GET['majorn'] == 'Mechanical Engineering':
        lis2.append(63)
    elif request.GET['majorn'] == 'Computer Systems Management':
        lis2.append(20)
    elif request.GET['majorn'] == 'Computer Science':
        lis2.append(19)
    elif request.GET['majorn'] == 'HVAC':
        lis2.append(45)
    elif request.GET['majorn'] == 'Nutritional Sciences':
        lis2.append(67)
    elif request.GET['majorn'] == 'History':
        lis2.append(47)
    elif request.GET['majorn'] == 'Linguistics':
        lis2.append(44)
    elif request.GET['majorn'] == 'Computer Engineering':
        lis2.append(18)
    elif request.GET['majorn'] == 'Information Systems-Business':
        lis2.append(50)
    elif request.GET['majorn'] == 'Engineering (Undecided) ':
        lis2.append(29)
    elif request.GET['majorn'] == 'Science Education':
        lis2.append(81)
    elif request.GET['majorn'] == 'Professional/Technical':
        lis2.append(75)
    elif request.GET['majorn'] == 'Public Safety':
        lis2.append(78)
    elif request.GET['majorn'] == 'Physical Education':
        lis2.append(71)
    elif request.GET['majorn'] == 'General Business and Management':
        lis2.append(41)
    elif request.GET['majorn'] == 'Family Studies':
        lis2.append(34)
    elif request.GET['majorn'] == 'Operations Management (Business)':
        lis2.append(68)
    elif request.GET['majorn'] == 'Environmental Science and Policy (Science)':
        lis2.append(32)
    elif request.GET['majorn'] == 'Criminology and Criminal Justice':
        lis2.append(23)
    elif request.GET['majorn'] == 'Russian Language and Literature':
        lis2.append(80)
    elif request.GET['majorn'] == "Spanish Language and Literature":
        lis2.append(85)
    elif request.GET['majorn'] == 'Environmental, Educational and Park Management':
        lis2.append(33)
    elif request.GET['majorn'] == 'Architecture':
        lis2.append(6)
    elif request.GET['majorn'] == 'Electrical Engineering':
        lis2.append(27)
    elif request.GET['majorn'] == 'Logistics, Transportation and Supply Chain Management (Business)':
        lis2.append(58)
    elif request.GET['majorn'] == 'Conservation of Soil, Water, and Environment':
        lis2.append(21)
    elif request.GET['majorn'] == 'Early Childhood Education ':
        lis2.append(25)
    elif request.GET['majorn'] == 'Biological Sciences: General Biology':
        lis2.append(12)
    elif request.GET['majorn'] == 'Marketing (Business) ':
        lis2.append(60)
    elif request.GET['majorn'] == 'Animal Sciences: Animal Care and Management':
        lis2.append(5)
    elif request.GET['majorn'] == 'Undecided (Letters and Sciences)':
        lis2.append(86)
    elif request.GET['majorn'] == 'Pre-Medical Technology':
        lis2.append(73)
    elif request.GET['majorn'] == 'Bioengineering':
        lis2.append(9)
    elif request.GET['majorn'] == 'Geography':
        lis2.append(43)
    elif request.GET['majorn'] == 'Early Childhood Education':
        lis2.append(24)
    elif request.GET['majorn'] == 'Marketing (Business)':
        lis2.append(59)
    elif request.GET['majorn'] == 'International Business':
        lis2.append(52)
    elif request.GET['majorn'] == 'Liberal Arts/Gen. Studies':
        lis2.append(56)
    elif request.GET['majorn'] == 'Education (Teacher:Undecided)':
        lis2.append(26)
    elif request.GET['majorn'] == 'Art History':
        lis2.append(8)
    elif request.GET['majorn'] == 'French Language and Literature':
        lis2.append(40)
    elif request.GET['majorn'] == 'Mathematics':
        lis2.append(62)
    elif request.GET['majorn'] == 'Urban Forestry':
        lis2.append(87)
    elif request.GET['majorn'] == 'Aerospace Engineering':
        lis2.append(1)
    elif request.GET['majorn'] == 'Central European, Russian and Eurasian Studies':
        lis2.append(14)
    elif request.GET['majorn'] == 'Art Education':
        lis2.append(7)
    elif request.GET['majorn'] == 'Environmental Science and Policy (Policy)':
        lis2.append(31)
    elif request.GET['majorn'] == 'Social Studies Education':
        lis2.append(82)
    elif request.GET['majorn'] == 'American Studies':
        lis2.append(4)
    elif request.GET['majorn'] == 'Romance Languages':
        lis2.append(79)
    elif request.GET['majorn'] == 'Biological Sciences: Ecology and Evolution':
        lis2.append(11)
    elif request.GET['majorn'] == 'Foreign Language Education':
        lis2.append(38)
    elif request.GET['majorn'] == 'Kinesiological Sciences':
        lis2.append(54)
    elif request.GET['majorn'] == 'Biological Sciences: Cell Biology and Genetics':
        lis2.append(10)
    elif request.GET['majorn'] == "Women's Studies":
        lis2.append(88)

    if request.GET['degreen'] == 'AA':
        lis2.append(0)
    elif request.GET['degreen'] == 'Masters (MA/MS/MPH/etc.)':
        lis2.append(4)
    elif request.GET['degreen'] == 'Bachelors (BA/BS)':
        lis2.append(0)
    elif request.GET['degreen'] == "Other":
        lis2.append(6)
    elif request.GET['degreen'] == 'Certificate':
        lis2.append(2)
    elif request.GET['degreen'] == 'Ph.D. (DCS)':
        lis2.append(7)
    elif request.GET['degreen'] == 'Non-Degree':
        lis2.append(5)
    elif request.GET['degreen'] == 'Ph.D. (DDE)':
        lis2.append(8)
    elif request.GET['degreen'] == 'Juris Doctor':
        lis2.append(3)


    if request.GET['schooln'] == 'Montgomery College Rockville Campus':
        lis2.append(220)
    elif request.GET['schooln'] == 'BOWIE STATE UNIVERSITY':
        lis2.append(47)
    elif request.GET['schooln'] == "Mount St Mary's University":
        lis2.append(224)
    elif request.GET['schooln'] == 'University of Maryland - University College':
        lis2.append(332)
    elif request.GET['schooln'] == "PRINCE GEORGE'S COMMUNITY COLLEGE":
        lis2.append(250)
    elif request.GET['schooln'] == 'University of Maryland - Baltimore':
        lis2.append(329)
    elif request.GET['schooln'] == 'NATIONAL ASSOCIATION OF HOUSING AND REDEVELOPMENT OFFICIALS':
        lis2.append(226)
    elif request.GET['schooln'] == 'FREDERICK COMMUNITY COLLEGE':
        lis2.append(106)
    elif request.GET['schooln'] == 'University of Maryland - College Park':
            lis2.append(331)
    elif request.GET['schooln'] == 'GEORGE WASHINGTON UNIVERSITY':
        lis2.append(116)
    elif request.GET['schooln'] == 'George Washington University':
        lis2.append(124)
    elif request.GET['schooln'] == 'MONTGOMERY COMMUNITY COLLEGE':
        lis2.append(206)
    elif request.GET['schooln'] == 'Weber State University':
        lis2.append(351)
    elif request.GET['schooln'] == 'CAPELLA UNIVERSITY':
        lis2.append(57)
    elif request.GET['schooln'] == 'STRAYER UNIVERSITY':
        lis2.append(285)
    elif request.GET['schooln'] == 'HOWARD UNIVERSITY':
        lis2.append(135)
    elif request.GET['schooln'] == 'Waldorf College':
            lis2.append(349)
    elif request.GET['schooln'] == 'Triton Training Group':
        lis2.append(313)
    elif request.GET['schooln'] == 'American College of Physicians (ACP)':
        lis2.append(20)
    elif request.GET['schooln'] == 'ARGOSY UNIVERSITY':
        lis2.append(6)
    elif request.GET['schooln'] == 'UNIVERSITY OF DC':
        lis2.append(315)
    elif request.GET['schooln'] == 'COLUMBIA SOUTHERN UNIVERSITY':
        lis2.append(65)
    elif request.GET['schooln'] == 'CAPITOL COLLEGE':
        lis2.append(58)
    elif request.GET['schooln'] == 'UNIVERSITY OF BALTIMORE':
        lis2.append(314)
    elif request.GET['schooln'] == 'Robert Morris University':
            lis2.append(275)
    elif request.GET['schooln'] == 'UNIVERSITY OF PHOENIX':
        lis2.append(324)
    elif request.GET['schooln'] == 'American Public University System':
        lis2.append(26)
    elif request.GET['schooln'] == 'GLOCK PROFESSIONAL, INC':
        lis2.append(120)
    elif request.GET['schooln'] == 'HOOD COLLEGE':
        lis2.append(133)
    elif request.GET['schooln'] == 'BOSTON UNIVERSITY':
        lis2.append(46)
    elif request.GET['schooln'] == 'MONTGOMERY COUNTY COMMUNITY COLLEGE':
        lis2.append(208)
    elif request.GET['schooln'] == 'UNIVERSITY OF FLORIDA':
        lis2.append(316)
    elif request.GET['schooln'] == 'PENN FOSTER COLLEGE':
            lis2.append(246)
    elif request.GET['schooln'] == 'University of Maryland - Baltimore County':
        lis2.append(330)
    elif request.GET['schooln'] == 'School of PE':
        lis2.append(289)
    elif request.GET['schooln'] == 'MORGAN STATE UNIVERSITY':
        lis2.append(210)
    elif request.GET['schooln'] == 'WALDEN UNIVERSITY':
        lis2.append(347)
    elif request.GET['schooln'] == 'JOHNS HOPKINS UNIVERSITY':
        lis2.append(170)
    elif request.GET['schooln'] == 'SALISBURY UNIVERSITY':
        lis2.append(277)
    elif request.GET['schooln'] == 'MD SHRM State Council':
        lis2.append(202)
    elif request.GET['schooln'] == 'UNIVERSITY OF MARYLAND, UNIVERSITY COLLEGE':
        lis2.append(322)
    elif request.GET['schooln'] == 'GEORGE MASON UNIVERSITY':
        lis2.append(115)
    elif request.GET['schooln'] == 'Villanova University':
        lis2.append(344)
    elif request.GET['schooln'] == 'MD SHRM STATE COUNCIL':
        lis2.append(201)
    elif request.GET['schooln'] == 'CHAMBERLAIN COLLEGE OF NURSING':
        lis2.append(61)
    elif request.GET['schooln'] == 'COMMUNITY COLLEGE OF BALTIMORE COUNTY':
        lis2.append(67)
    elif request.GET['schooln'] == 'NORTHERN VIRGINIA COMMUNITY COLLEGE':
        lis2.append(229)
    elif request.GET['schooln'] == 'Shemer Bar Review, LLC.':
        lis2.append(291)
    elif request.GET['schooln'] == 'COLUMBIA UNION COLLEGE':
        lis2.append(66)
    elif request.GET['schooln'] == 'UNIVERSITY OF MARYLAND AT SHADY GROVE CENTER':
        lis2.append(320)
    elif request.GET['schooln'] == 'Arizona State University':
        lis2.append(32)
    elif request.GET['schooln'] == 'MONTGOMERY COUNTY COLLEGE':
        lis2.append(207)
    elif request.GET['schooln'] == 'Harrisburg Area Community College - Harrisburg':
        lis2.append(138)
    elif request.GET['schooln'] == 'Wilmington University':
        lis2.append(354)
    elif request.GET['schooln'] == 'Shippensburg University of Pennsylvania':
        lis2.append(292)
    elif request.GET['schooln'] == 'Breastfeeding Outlook':
        lis2.append(52)
    elif request.GET['schooln'] == 'Human Resources Institute':
        lis2.append(144)
    elif request.GET['schooln'] == 'NIGP: The Institute for Public Procurement':
        lis2.append(228)
    elif request.GET['schooln'] == 'OFFICE OF EDUCATION AND TRAINING FOR ADDICTION SERVICES':
        lis2.append(241)
    elif request.GET['schooln'] == 'Sistema Universitario Ana G Mendez - Universidad Del Turabo':
        lis2.append(293)
    elif request.GET['schooln'] == 'Environmental Systems Research Institute (ESRI)':
        lis2.append(97)
    elif request.GET['schooln'] == 'BENEDICTINE UNIVERSITY':
        lis2.append(41)
    elif request.GET['schooln'] == 'UNIVERSITY OF MARYLAND, COLLEGE PARK':
        lis2.append(321)
    elif request.GET['schooln'] == 'ACADEMI':
        lis2.append(0)
    elif request.GET['schooln'] == 'HOWARD COMMUNITY COLLEGE':
        lis2.append(134)
    elif request.GET['schooln'] == 'Purdue University':
        lis2.append(263)
    elif request.GET['schooln'] == 'COLT DEFENSE LLC':
        lis2.append(64)
    elif request.GET['schooln'] == 'GEORGETOWN UNIVERSITY':
        lis2.append(117)
    elif request.GET['schooln'] == 'SIGNET NORTH AMERICA':
        lis2.append(281)
    elif request.GET['schooln'] == 'PESI  ---CONTINUING EDUCATIOIN SEMINARS':
        lis2.append(248)
    elif request.GET['schooln'] == 'Remote Medical International':
        lis2.append(273)
    elif request.GET['schooln'] == 'BERLITZ LANGUAGE CENTER':
        lis2.append(42)
    elif request.GET['schooln'] == 'AMERICAN MILITARY UNIVERSITY':
        lis2.append(3)
    elif request.GET['schooln'] == 'The Newberry Group, Inc':
        lis2.append(305)
    elif request.GET['schooln'] == 'INTERNATIONAL ASSOCIATION OF COMPUTER INVESTIGATIVE SPECIALIST':
        lis2.append(148)
    elif request.GET['schooln'] == 'JOHN E. REID AND ASSOCIATES, INC.':
        lis2.append(168)
    elif request.GET['schooln'] =='PENNSYLVANIA STATE UNIVERSITY':
        lis2.append(247)
    elif request.GET['schooln'] == 'HAGERSTOWN COMMUNITY COLLEGE':
        lis2.append(128)
    elif request.GET['schooln'] == 'BELLEVUE UNIVERSITY':
        lis2.append(40)
    elif request.GET['schooln'] == 'BALTIMORE CITY COMMUNITY COLLEGE':
        lis2.append(38)
    elif request.GET['schooln'] == 'VEHICLE DYNAMICS INSTITUTE (VDI)':
        lis2.append(342)
    elif request.GET['schooln'] == 'PUBLIC AGENCY TRAINING COUNCIL':
        lis2.append(253)
    elif request.GET['schooln'] == 'PAT MCCARTHY PRODUCTIONS, INC':
        lis2.append(245)
    elif request.GET['schooln'] == 'GEORGIA K9 NTC, LLC':
        lis2.append(118)
    elif request.GET['schooln'] == 'Loyola College in Maryland':
        lis2.append(192)
    elif request.GET['schooln'] == 'LIBERTY UNIVERSITY':
        lis2.append(186)
    elif request.GET['schooln'] == 'TOWSON UNIVERSITY':
        lis2.append(302)
    elif request.GET['schooln'] == 'ASHWORTH COLLEGE':
        lis2.append(9)
    elif request.GET['schooln'] == 'Kaplan University':
        lis2.append(179)
    elif request.GET['schooln'] == 'MCKISSOCK, LP':
        lis2.append(200)
    elif request.GET['schooln'] == 'MARYLAND FIRE AND RESCUE INSTITUTE':
        lis2.append(198)
    elif request.GET['schooln'] == 'ASHFORD UNIVERSITY':
        lis2.append(8)
    elif request.GET['schooln'] == 'Kennesaw State University':
        lis2.append(181)
    elif request.GET['schooln'] == 'THE CENTER FOR ALTERNATIVE DISPUTE RESOLUTION':
        lis2.append(301)
    elif request.GET['schooln'] == 'MONTOGMERY COLLEGE':
        lis2.append(209)
    elif request.GET['schooln'] == 'SHRM TRAINING FOR PHR AND SPHR CERTIFICATION':
        lis2.append(279)
    elif request.GET['schooln'] == 'Appraisal Institute':
        lis2.append(31)
    elif request.GET['schooln'] == 'Johns Hopkins University':
        lis2.append(171)
    elif request.GET['schooln'] == 'The SANS (SysAdmin, Audit, Network, Security) INSTITUTE':
        lis2.append(306)
    elif request.GET['schooln'] == 'BORRA CPA REVIEW':
        lis2.append(45)
    elif request.GET['schooln'] == 'FROSTBURG STATE UNIVERSITY':
        lis2.append(107)
    elif request.GET['schooln'] == 'Essex County College':
        lis2.append(98)
    elif request.GET['schooln'] == 'Pennsylvania State University - Penn State Main Campus':
        lis2.append(255)
    elif request.GET['schooln'] == 'ROPES THAT RESCUE LTD.':
        lis2.append(266)
    elif request.GET['schooln'] == 'GALLAUDET UNIVERSITY':
        lis2.append(114)
    elif request.GET['schooln'] == 'UNIVERSITY OF NEW ENGLAND':
        lis2.append(323)
    elif request.GET['schooln'] == 'CORNELL UNIVERSITY':
        lis2.append(344)
    elif request.GET['schooln'] == 'MD SHRM STATE COUNCIL':
        lis2.append(70)
    elif request.GET['schooln'] == 'Career Academy Inc':
        lis2.append(75)
    elif request.GET['schooln'] == 'SHRM TRAINING FOR PHR AND SPHR CERTIFICATION ':
        lis2.append(280)
    elif request.GET['schooln'] == 'ASSOCIATION OF CERTIFIED FRAUD EXAMINERS':
        lis2.append(11)
    elif request.GET['schooln'] == 'Princeton University':
        lis2.append(258)
    elif request.GET['schooln'] == 'Montessori Western Teacher Training Program':
            lis2.append(219)
    elif request.GET['schooln'] == 'Berlitz Language Centers':
        lis2.append(51)
    elif request.GET['schooln'] == 'Fox Valley Technical College':
        lis2.append(32)
    elif request.GET['schooln'] == 'MONTGOMERY COUNTY COLLEGE':
        lis2.append(111)
    elif request.GET['schooln'] == 'COLLEGE OF SOUTHERN MARYLAND':
        lis2.append(62)
    elif request.GET['schooln'] =='Colorado Technical University':
        lis2.append(85)
    elif request.GET['schooln'] =='WIDENER UNIVERSITY SCHOOL OF LAW':
        lis2.append(348)
    elif request.GET['schooln'] =='BUCKS COUNTY COMMUNITY COLLEGE':
        lis.append(49)
    elif request.GET['schooln'] =='CAPE COD INSTITUTE':
        lis2.append(56)
    elif request.GET['schooln'] =='BAIR Analytics Inc':
        lis2.append(37)
    elif request.GET['schooln'] =='CONTEMPORARY FORUMS':
        lis2.append(68)
    elif request.GET['schooln'] =='Virginia Task Force 2':
        lis2.append(345)
    elif request.GET['schooln'] =='Learning Tree, Inc.':
        lis2.append(189)
    elif request.GET['schooln'] =='Association for Talent Development (ATD)':
        lis2.append(35)
    elif request.GET['schooln'] =='SKILLPATH SEMINARS':
        lis2.append(283)
    elif request.GET['schooln'] =='Indiana University':
        lis2.append(154)
    elif request.GET['schooln'] =='K9 GUARDIAN, INC.':
        lis2.append(175)
    elif request.GET['schooln'] =='Rescue 3 International, Inc.':
        lis2.append(274)
    elif request.GET['schooln'] =='HEALTHY CHILDREN PROJECT, INC':
        lis2.append(131)
    elif request.GET['schooln'] =='Nova Southeastern University':
        lis2.append(240)
    elif request.GET['schooln'] ==  'F.A.J.Exams':
        lis2.append(101)
    elif request.GET['schooln'] ==   'GOVERNMENT FINANCE OFFICERS ASSOCIATION':
        lis2.append(121)
    elif request.GET['schooln'] ==   'Pace Institute':
        lis2.append(254)
    elif request.GET['schooln'] ==   'New York Medical College':
        lis2.append(236)
    elif request.GET['schooln'] ==   'Institute of Electrical and Electronics Engineers (IEEE)':
        lis2.append(158)
    elif request.GET['schooln'] ==   'REDBACK ONE, LLC':
        lis2.append(264)
    elif request.GET['schooln'] ==   'EMDR INSTITUTE, INC':
        lis2.append(93)
    elif request.GET['schooln'] ==   'Loyola University Maryland':
        lis2.append(193)
    elif request.GET['schooln'] ==   'STORM MOUNTAIN TRAINING CENTER':
        lis2.append(284)
    elif request.GET['schooln'] ==    'Themis Bar Review':
        lis2.append(309)
    elif request.GET['schooln'] =='CATHOLIC UNIVERSITY OF AMERICA':
        lis2.append(59)
    elif request.GET['schooln'] == 'COLLISION SAFETY INSTITUTE (CSI)':
        lis2.append(63)
    elif request.GET['schooln'] ==     'Norwich University':
        lis2.append(238)
    elif request.GET['schooln'] ==      'SUNY Empire State College':
        lis2.append(287)
    elif request.GET['schooln'] ==       'INTERNATIONAL ASSOCIATION OF ARSON INVESTIGATORS':
        lis2.append(147)
    elif request.GET['schooln'] ==       'ASIS INTERNATIONAL':
        lis2.append(10)
    elif request.GET['schooln'] ==        'Beck Institute':
        lis2.append(50)
    elif request.GET['schooln'] ==         'University of Maryland Global Campus':
        lis2.append(333)
    elif request.GET['schooln'] ==          'ICA Language Services':
        lis2.append(145)
    elif request.GET['schooln'] ==           'Regis University':
        lis2.append(271)
    elif request.GET['schooln'] ==            'Cambridge Nursing Assistant Academy':
        lis2.append(74)
    elif request.GET['schooln'] ==             'Rasmussen College':
        lis2.append(268)
    elif request.GET['schooln'] ==              'National Fire Protection Association':
        lis2.append(232)
    elif request.GET['schooln'] ==              'PESI HEALTHCARE LLC':
        lis2.append(249)
    elif request.GET['schooln'] ==              'International Association of Forensic Nurses':
        lis2.append(163)
    elif request.GET['schooln'] ==              'Institute for Natural Resources (INR)':
        lis2.append(157)
    elif request.GET['schooln'] ==              'AMERICAN PUBLIC UNIVERSITY':
        lis2.append(4)
    elif request.GET['schooln'] ==               'Independent Electrical Contractors Chesapeake':
        lis2.append(151)
    elif request.GET['schooln'] ==                'University of Richmond':
        lis2.append(337)
    elif request.GET['schooln'] ==                 'FIRE DEPARTMENT TRAINING NETWORK':
        lis2.append(103)
    elif request.GET['schooln'] ==                 'ANNE ARUNDEL COMMUNITY COLLEGE':
        lis2.append(5)
    elif request.GET['schooln'] ==                  'Trauma and Critical Care Foundation':
        lis2.append(311)
    elif request.GET['schooln'] ==                   'Project Management Institute (PMI)':
        lis2.append(260)
    elif request.GET['schooln'] ==                    'GRADUATE SCHOOL, USDA':
        lis2.append(122)
    elif request.GET['schooln'] ==                    'Society for Human Resource Management':
        lis2.append(294)
    elif request.GET['schooln'] ==                     'Howard Community College':
        lis2.append(143)
    elif request.GET['schooln'] ==                     'LEADERSHIP MONTGOMERY':
        lis2.append(185)
    elif request.GET['schooln'] ==                     'University of Chicago':
        lis2.append(327)
    elif request.GET['schooln'] ==                     'B D ASSOCIATES, INC.':
        lis2.append(36)
    elif request.GET['schooln'] ==                      'UNIVERSITY OF MARYLAND':
        lis2.append(317)
    elif request.GET['schooln'] ==                       'Associated Center for Therapy':
        lis2.append(34)
    elif request.GET['schooln'] ==                       'Lactation Education Resources':
        lis2.append(188)
    elif request.GET['schooln'] ==                       'ALICE Training Institute':
        lis2.append(1)
    elif request.GET['schooln'] ==                        'National Criminal Enforcement Association':
        lis2.append(231)
    elif request.GET['schooln'] ==                         'Eastern Kentucky University':
        lis2.append( 95)
    elif request.GET['schooln'] ==                         'The Center for Forensic Science and Research Education':
        lis2.append(304)
    elif request.GET['schooln'] ==                          'Tripwire Operations Group':
        lis2.append(312)
    elif request.GET['schooln'] ==                           'Montgomery Community College':
        lis2.append(221)
    elif request.GET['schooln'] ==                            'HITS, Inc':
        lis2.append(132)
    elif request.GET['schooln'] ==                             'HARLEY-DAVIDSON RIDERS EDGE':
        lis2.append(129)
    elif request.GET['schooln'] ==                             'Marshall University':
        lis2.append(211)
    elif request.GET['schooln'] ==                              'HealthSciences Institute':
        lis2.append( 141)
    elif request.GET['schooln'] ==                              'American Institute of CPAs':
        lis2.append(22)
    elif request.GET['schooln'] ==                              'American Institute of Certified Public Accountants':
        lis2.append(23)
    elif request.GET['schooln'] ==                              'The University of Alabama':
        lis2.append(307)
    elif request.GET['schooln'] ==                               'American Association of Diabetes Educators':
        lis2.append(17)
    elif request.GET['schooln'] ==                               'BLUE RIDGE COMMUNITY AND TECHNICAL COLLEGE':
        lis2.append(43)
    elif request.GET['schooln'] ==                               'Our Lady of the Lake University':
        lis2.append( 244)
    elif request.GET['schooln'] ==                                'Indiana University of Pennsylvania':
        lis2.append(156)
    elif request.GET['schooln'] ==                                'University of South Alabama':
        lis2.append(338)
    elif request.GET['schooln'] ==                                'American Payroll Association':
        lis2.append( 24)
    elif request.GET['schooln'] ==                                 'GLOCK INC.':
        lis2.append(119)
    elif request.GET['schooln'] ==                                 'YORK COLLEGE OF PENNSYLVANIA':
        lis2.append(355)
    elif request.GET['schooln'] ==                                  'COPPIN STATE UNIVERSITY':
        lis2.append(69)
    elif request.GET['schooln'] ==                                  'SIMPLILEARN SOLUTIONS':
        lis2.append( 282)
    elif request.GET['schooln'] ==                                  'INTERNATIONAL ASSOCIATION OF FIRE CHIEFS':
        lis2.append(149)
    elif request.GET['schooln'] ==                                   'GRAND CANYON UNIVERSITY':
        lis2.append(123)
    elif request.GET['schooln'] ==                                   'UNIVERSITY OF MARYLAND AT BALTIMORE COUNTY':
        lis2.append(319)
    elif request.GET['schooln'] ==                                   'California Polytechnic State University-San Luis Obispo':
        lis2.append(73)
    elif request.GET['schooln'] ==                                    'Ace Tech Institute':
        lis2.append(13)
    elif request.GET['schooln'] ==                                    'Johnson Controls':
        lis2.append(173)
    elif request.GET['schooln'] ==                                    'Kaplan Test Prep':
        lis2.append(178)
    elif request.GET['schooln'] ==                                     'M.S. Electrical Training, LLC':
        lis2.append(196)
    elif request.GET['schooln'] ==                                      'University of Massachusetts Health Services':
        lis2.append(335)
    elif request.GET['schooln'] ==                                      'Kennedy Krieger Institute':
        lis2.append(180)
    elif request.GET['schooln'] ==                                      'ITT Technical Institute - Indianapolis':
        lis2.append(150,)
    elif request.GET['schooln'] ==                                       'HARVARD ASSOCIATES IN POLICE SCIENCE, INC.':
        lis2.append( 130)
    elif request.GET['schooln'] ==                                        'AMERICAN CRIME PREVENTION INSTITUTE (ACPI)':
        lis2.append(2)
    elif request.GET['schooln'] ==                                        'CALIBRE PRESS':
        lis2.append(54)
    elif request.GET['schooln'] ==                                         'International School of Languages (ISL)':
        lis2.append(166)
    elif request.GET['schooln'] ==                                          'M.S. Electrical Training LLC':
        lis2.append(195)
    elif request.GET['schooln'] ==                                           'MARYLAND POLICE AND CORRECTIONAL TRAINING COMMISSIONS (MPCTC':
        lis2.append(199)
    elif request.GET['schooln'] ==                                            'Remington Arms Company, LLC':
        lis2.append(272)
    elif request.GET['schooln'] ==                                            'Desert Snow, LLC':
        lis2.append( 90)
    elif request.GET['schooln'] ==                                            'MANAGEMENT CONCEPTS':
        lis2.append(197)
    elif request.GET['schooln'] ==                                             'LA HIDTA HOMICIDE SCHOOL':
        lis2.append(183)
    elif request.GET['schooln'] ==                                             'Professional Education Services, LP':
        lis2.append(259)
    elif request.GET['schooln'] ==                                             'Southern New Hampshire University':
        lis2.append( 296)
    elif request.GET['schooln'] ==                                             'FORT HAYS STATE UNIVERSITY':
        lis2.append(105)
    elif request.GET['schooln'] ==                                             'Green Ops':
        lis2.append(126)
    elif request.GET['schooln'] ==                                              'Indiana Institute of Technology':
        lis2.append( 153)
    elif request.GET['schooln'] ==                                              'West Texas A & M University':
        lis2.append(352)
    elif request.GET['schooln'] ==                                               'Frostburg State University':
        lis2.append(113)
    elif request.GET['schooln'] ==                                               'Washington Adventist University':
        lis2.append( 350)
    elif request.GET['schooln'] ==                                               'Cellebrite Inc':
        lis2.append(77)
    elif request.GET['schooln'] ==                                                'Stevenson University':
        lis2.append(299)
    elif request.GET['schooln'] ==                                                'MID-ATLANTIC REGIONAL GANG INVESTIGATOS NETWORK':
        lis2.append(205)
    elif request.GET['schooln'] ==                                                'Chicago School of Professional Psychology':
        lis2.append(81)
    elif request.GET['schooln'] ==                                                'National Institute of Governmental Purchasing':
        lis2.append(23)
    elif request.GET['schooln'] ==                                                'Maryland Association of Public Accountants':
        lis2.append(21)
    elif request.GET['schooln'] ==                                                 'TRILOGY HSE':
        lis2.append(30)
    elif request.GET['schooln'] ==                                                 'M.J. Francoeur & Associates Dale Carnegie Training':
        lis2.append(19)
    elif request.GET['schooln'] ==                                                  'BECKER PROFESSIONAL EDUCATION':
        lis2.append(39)
    elif request.GET['schooln'] ==                                                   'Cypress Creek EMS':
        lis2.append(88)
    elif request.GET['schooln'] ==                                                    'Alliance Francaise DC':
        lis2.append(15)
    elif request.GET['schooln'] ==                                                    'Seton Hall University':
        lis2.append(29)
    elif request.GET['schooln'] ==                                                     'Vyne Education':
        lis2.append(34)
    elif request.GET['schooln'] ==                                                      'International Association of Undercover Officers':
        lis2.append(16)
    elif request.GET['schooln'] ==                                                      'Art Institute of Cincinnati':
        lis2.append(33)
    elif request.GET['schooln'] ==                                                      'American Society of Pension Professionals and Actuaries (ASPPA)':
        lis2.append(28)
    elif request.GET['schooln'] ==                                                      'Cheetah Learning':
        lis2.append(80)
    elif request.GET['schooln'] ==                                                      'National Business Institute':
        lis2.append(23)
    elif request.GET['schooln'] ==                                                      'CE You!':
        lis2.append(60)
    elif request.GET['schooln'] ==                                                      'Concordia University':
        lis2.append(86)
    elif request.GET['schooln'] ==                                                      'Oregon State University':
        lis2.append(243)
    elif request.GET['schooln'] ==                                                      'Embry-Riddle Aeronautical University - Daytona Beach':
        lis2.append( 96)
    elif request.GET['schooln'] ==                                                      'Kaplan Institute':
        lis2.append( 176)
    elif request.GET['schooln'] ==                                                      'Sage Dynamics, LLC':
        lis2.append(288)
    elif request.GET['schooln'] ==                                                      'New Horizons Career Center':
        lis2.append(234)
    elif request.GET['schooln'] ==                                                      'McAfee Institute':
        lis2.append( 215)
    elif request.GET['schooln'] ==                                                      'West Virginia University': 353
    elif request.GET['schooln'] ==                                                       'Psychwire':
        lis2.append(261)
    elif request.GET['schooln'] ==                                                       'Sons of Liberty Gun Works':
        lis2.append(295)
    elif request.GET['schooln'] ==                                                       'Kaplan Schweser':
        lis2.append( 177)
    elif request.GET['schooln'] ==                                                        'Mid Atlantic OSHA Training Institute Education Center':
        lis2.append(217)
    elif request.GET['schooln'] ==                                                         'Evangel University':
        lis2.append( 99)
    elif request.GET['schooln'] ==                                                         'Carroll Community College':
        lis2.append(76)
    elif request.GET['schooln'] ==                                                          'Morning Star Academy (MSA), School of Allied Health':
        lis2.append(223)
    elif request.GET['schooln'] ==                                                          'University of Pennsylvania':
        lis2.append(336)
    elif request.GET['schooln'] ==                                                          'Marymount University':
        lis2.append(214)
    elif request.GET['schooln'] ==                                                           'California Coast University':
        lis2.append(72)
    elif request.GET['schooln'] ==                                                           'Rochester Institute of Technology':
        lis2.append(276)
    elif request.GET['schooln'] ==                                                           'UTICA COLLEGE':
        lis2.append(326)
    elif request.GET['schooln'] ==                                                           'Georgetown University':
        lis2.append(125)
    elif request.GET['schooln'] ==                                                            'RUTGERS UNIVERSITY - NEWARK - SCHOOL OF PUBLIC AFFAIRS AND ADMINISTRATION':
        lis2.append(267)
    elif request.GET['schooln'] ==                                                            'Institutional Limited Partners Association (ILPA)':
        lis2.append(160)
    elif request.GET['schooln'] ==                                                            'Frederick Community College':
        lis2.append(112)
    elif request.GET['schooln'] ==                                                            'Presentation College':
        lis2.append(257)
    elif request.GET['schooln'] ==                                                             'Starbright Training Institute':
        lis2.append(298)
    elif request.GET['schooln'] ==                                                             'CUSTOM CANINE UNLIMITED, LLC.':
        lis2.append( 71)
    elif request.GET['schooln'] ==                                                              'LABOR ARBITRATION INSTITUTE':
        lis2.append(184)
    elif request.GET['schooln'] ==                                                               'Guerilla Approach':
        lis2.append(127)
    elif request.GET['schooln'] ==                                                               'University of the Cumberlands':
        lis2.append(340)
    elif request.GET['schooln'] ==                                                               'REGENT UNIVERSITY':
        lis2.append(265)
    elif request.GET['schooln'] ==                                                               'STREET COP TRAINING':
        lis2.append(286)
    elif request.GET['schooln'] ==                                                                'BOMI International':
        lis2.append(44)
    elif request.GET['schooln'] ==                                                                 'RedVector Convergence Training':
        lis2.append(269)
    elif request.GET['schooln'] ==                                                                  'K-9 Cop Magazine':
        lis2.append(174)
    elif request.GET['schooln'] ==                                                                   'American Health Information Management Association':
        lis2.append( 21)
    elif request.GET['schooln'] ==                                                                   'Interior Designers Institute':
        lis2.append(161)
    elif request.GET['schooln'] ==                                                                    'Brown University':
        lis2.append( 53)
    elif request.GET['schooln'] ==                                                                     'Ferentz Institute':
        lis2.append(108)
    elif request.GET['schooln'] ==                                                                      'Trauma Institute & Child Trauma Institute':
        lis2.append(310)
    elif request.GET['schooln'] ==                                                                       'ASA Institute of Business and Computer Technology':
        lis2.append(7)
    elif request.GET['schooln'] ==                                                                       'Anne Arundel Community College':
        lis2.append( 30)
    elif request.GET['schooln'] ==                                                                        'Stratford University':
        lis2.append(300)
    elif request.GET['schooln'] ==                                                                        'Adelphi University':
        lis2.append( 14)
    elif request.GET['schooln'] ==                                                                         'Notre Dame University of Maryland':
        lis2.append(239)
    elif request.GET['schooln'] ==                                                                          'University of Cincinnati - Main Campus':
        lis2.append(328)
    elif request.GET['schooln'] ==                                                                           'Clemson University':
        lis2.append( 82)
    elif request.GET['schooln'] ==                                                                            'JOHN JAY COLLEGE':
        lis2.append(169)
    elif request.GET['schooln'] ==                                                                             'Hale Products':
        lis2.append(137)
    elif request.GET['schooln'] ==                                                                             'Public Pension Financial Forum':
        lis2.append(262)
    elif request.GET['schooln'] ==                                                                              'EMDR OF GREATER WASHINGTON':
        lis2.append( 94)
    elif request.GET['schooln'] ==                                                                               'Howard College':
        lis2.append(142)
    elif request.GET['schooln'] ==                                                                                'BSR FIREARMS TRAINING CENTER':
        lis2.append( 48)
    elif request.GET['schooln'] ==                                                                                 'Indiana University Bloomington':
        lis2.append(155)
    elif request.GET['schooln'] ==                                                                                  'American Physician Institute':
        lis2.append( 25)
    elif request.GET['schooln'] ==                                                                                   'Colorado State University':
        lis2.append( 83)
    elif request.GET['schooln'] ==                                                                                   'PSYCHOTHERAPY NETWORKER SYMPOSIUM':
        lis2.append(252)
    elif request.GET['schooln'] ==                                                                                    'Mid Atlantic Chapter of the Association for Contextual Behavioral Sciences (MACACBS)':
        lis2.append(216)
    elif request.GET['schooln'] ==                                                                                    'New York Institute of Art and Design':
        lis2.append(235)
    elif request.GET['schooln'] ==                                                                                     'Maryland State Bar Association':
        lis2.append(213)
    elif request.GET['schooln'] ==                                                                                      'First Airway, LLC':
        lis2.append(109)
    elif request.GET['schooln'] ==                                                                                       'Indian River Community College':
        lis2.append(152)
    elif request.GET['schooln'] ==                                                                                        'Old Dominion University':
        lis2.append(242)
    elif request.GET['schooln'] ==                                                                                        'American Association of Diabetes Educators (AADE)':
        lis2.append( 18)
    elif request.GET['schooln'] ==                                                                                        'Colorado State University: Global Campus':
        lis2.append( 84)
    elif request.GET['schooln'] ==                                                                                        'PROJECT MANAGEMENT INSTITUTE':
        lis2.append(251)
    elif request.GET['schooln'] ==                                                                                         'New York University':
        lis2.append(237)
    elif request.GET['schooln'] ==                                                                                         'UNIVERSITY OF THE DISTRICT OF COLUMBIA':
        lis2.append(325)
    elif request.GET['schooln'] ==                                                                                         'Harvard Medical School, Massachusetts Mental Health Center':
        lis2.append(139)
    elif request.GET['schooln'] ==                                                                                          'American Sentinel University - Aurora':
        lis2.append( 27)
    elif request.GET['schooln'] ==                                                                                           'Duke University':
        lis2.append( 92)
    elif request.GET['schooln'] ==                                                                                           'Kent State University':
        lis2.append(182)
    elif request.GET['schooln'] ==                                                                                            'Montreat College':
        lis2.append(222)
    elif request.GET['schooln'] ==                                                                                             'VARSITY TUTORS':
        lis2.append(341)
    elif request.GET['schooln'] ==                                                                                             'University of Vermont':
        lis2.append(339)
    elif request.GET['schooln'] ==                                                                                              'CALIFORNIA UNIVERSITY OF PENNSYLVANIA':
        lis2.append( 55)
    elif request.GET['schooln'] ==                                                                                              'INPUT-ACE':
        lis2.append(146)
    elif request.GET['schooln'] ==                                                                                              'American University':
        lis2.append( 29)
    elif request.GET['schooln'] ==                                                                                              'Introduction Today, Inc.':
        lis2.append(167)
    elif request.GET['schooln'] ==                                                                                              'UNIVERSITY OF MARYLAND AT BALTIMORE':
        lis2.append(318)
    elif request.GET['schooln'] ==                                                                                               'Force Science Institute, LTD.':
        lis2.append(110)
    elif request.GET['schooln'] ==                                                                                                'Modern Samura Project':
        lis2.append(218)
    elif request.GET['schooln'] ==                                                                                                 'FBI Leeda':
        lis2.append(102)
    elif request.GET['schooln'] ==                                                                                                 'Central Michigan University':
        lis2.append( 78)
    elif request.GET['schooln'] ==                                                                                                 'Institute of Police Technology & Management':
        lis2.append(159)
    elif request.GET['schooln'] ==                                                                                                 'Daigle Law Group, LLC':
        lis2.append( 89)
    elif request.GET['schooln'] ==                                                                                                 'University of Maryland Medical System':
        lis2.append(334)
    elif request.GET['schooln'] ==                                                                                                  'Centrifuge Training, LLC':
        lis2.append( 79)
    elif request.GET['schooln'] ==                                                                                                   'SHIPPENSBURG UNIVERSITY':
        lis2.append(278)
    elif request.GET['schooln'] ==                                                                                                   'HR Certification':
        lis2.append(136)
    elif request.GET['schooln'] ==                                                                                                    'American College of Medical Toxicology':
        lis2.append( 19)
    elif request.GET['schooln'] ==                                                                                                    'International Association of Financial Crimes Investigators':
        lis2.append(162)
    elif request.GET['schooln'] ==                                                                                                     'NATIONAL WHITE COLLAR CRIME CENTER':
        lis2.append(227)
    elif request.GET['schooln'] ==                                                                                                     'Special Operations Medical Association (SOMA)':
        lis2.append(297)
    elif request.GET['schooln'] ==                                                                                                      'Harvard University':
        lis2.append(140)
    elif request.GET['schooln'] ==                                                                                                       'Drexel University':
        lis2.append( 91)
    elif request.GET['schooln'] ==                                                                                                       'Academy of Art University':
        lis2.append( 12)
    elif request.GET['schooln'] ==                                                                                                        "Mount St. Mary's College":
        lis2.append(225)
    elif request.GET['schooln'] ==                                                                                                        'Expertise School of':
        lis2.append(100)
    elif request.GET['schooln'] ==                                                                                                         'Johnson & Wales University':
        lis2.append(172)
    elif request.GET['schooln'] ==                                                                                                         'MGH Psychiatry Academy':
        lis2.append(203)
    elif request.GET['schooln'] ==                                                                                                          'LWRC International':
        lis2.append(187)
    elif request.GET['schooln'] ==                                                                                                           'Concordia University, St. Paul':
        lis2.append( 87)
    elif request.GET['schooln'] ==                                                                                                            'Regis College':
        lis2.append(270)
    elif request.GET['schooln'] ==                                                                                                             'The Wright Institute':
        lis2.append(308)
    elif request.GET['schooln'] ==                                                                                                             'Liberty University':
        lis2.append(191)
    elif request.GET['schooln'] ==                                                                                                             'MID-ATLANTIC REGIONAL GANG INVESTIGATORS  NETWORK':
        lis2.append(204)
    elif request.GET['schooln'] ==                                                                                                              'Liberty Gun Works':
        lis2.append(190)
    elif request.GET['schooln'] ==                                                                                                              'FIRST RESPONDERS GRANT (FRG)':
        lis2.append(104)
    elif request.GET['schooln'] ==                                                                                                              'Personality Insights':
        lis2.append(256)
    elif request.GET['schooln'] ==                                                                                                               'Valdosta State University':
        lis2.append(343)
    elif request.GET['schooln'] ==                                                                                                                'International Association of Undercover Officers (IAUO)':
        lis2.append(165)
    elif request.GET['schooln'] ==                                                                                                                'American Association for Marriage and Family Therapy':
        lis2.append(16)

    # if request.GET['schooln'] == 'Montgomery College Rockville Campus':
    #     lis2.append(220)
    if request.GET['titlen']   ==    'INTRODUCTION TO BUSINESS' :
        lis2.append(1731)
    elif request.GET['titlen'] ==    'MA 160':
        lis2.append(1968)
    elif request.GET['titlen'] == 'INTRO TO AMERICAN MUSIC':
        lis2.append(1693)
    elif request.GET['titlen'] == 'PUBLIC POLICY ANALYSIS':
        lis2.append(2493)
    elif request.GET['titlen'] == 'MHA 500 CONTEMPORARY ISSUES IN HEALTH CARE':
        lis2.append(2107)
    elif request.GET['titlen'] == 'ACCT FINANCIAL MGMT CAPSTONE':
        lis2.append( 81)
    elif request.GET['titlen'] == 'ACCOUNTING 202':
        lis2.append( 48)
    elif request.GET['titlen'] == 'NUTRITION ONLINE':
        lis2.append(2217)
    elif request.GET['titlen'] == 'CLINICAL ADV FIELD PRACTICUM - SWCL 794 - 01':
        lis2.append( 575)
    elif request.GET['titlen'] == 'CIVIL LITIGATION':
        lis2.append( 550)
    elif request.GET['titlen'] == 'LIBS 150 INFORMATION LITERACY AND RESEARCH METHODS':
        lis2.append(1948)
    elif request.GET['titlen'] == 'EDCP 100, PRINCIPLES AND STRATEGIES OF SUCCESSFUL LEARNING ':
        lis2.append( 934)
    elif request.GET['titlen'] == 'CISCO ADVANCED ROUTING AND SWITCHING TECHNOLOGIES: INTERNETWORKING 3':
        lis2.append( 543)
    elif request.GET['titlen'] == 'PSYCHOLOGY':
        lis2.append(2450)
    elif request.GET['titlen'] == 'FUNDAMENTALS OF GLOBAL HEALTH':
        lis2.append(1294)
    elif request.GET['titlen'] == 'BEST PRACTICES IN EVENT MANAGEMENT  - ON CAMPUS':
        lis2.append( 314)
    elif request.GET['titlen'] == 'EVENT COORDINATION':
        lis2.append(1126)
    elif request.GET['titlen'] == 'EVENT COORDINATION - ON LINE':
        lis2.append(1127)
    elif request.GET['titlen'] == 'LABOR- MANAGEMENT RELATIONS':
        lis2.append(1879)
    elif request.GET['titlen'] == 'ENGLISH 101':
        lis2.append(1056)
    elif request.GET['titlen'] == 'AT 140 - SUSPENSION AND STEERING':
        lis2.append( 276)
    elif request.GET['titlen'] == 'CISCO NETWORKING FUNDAMENTALS: INTERNETWORKING':
        lis2.append( 546)
    elif request.GET['titlen'] == 'PRINCIPLES OF ACCOUNTING I':
        lis2.append(2377)
    elif request.GET['titlen'] == 'MANAGEMENT AND ORGANIZATIONAL THEORY':
        lis2.append(1983)
    elif request.GET['titlen'] == 'INTERNSHIP IN COUNSELING':
        lis2.append(1680)
    elif request.GET['titlen'] == 'ACCOUNTING FOR GOVERNMENT AND NOT-FOR-PROFIT':
        lis2.append( 64)
    elif request.GET['titlen'] == 'ADVANCED AUTOMOTIVE TECHNOLOGIES ATTC 3760':
        lis2.append( 117)
    elif request.GET['titlen'] == 'JOUR350 PHOTOJOURNALISM IN THE DIGITAL AGE':
        lis2.append(1856)
    elif request.GET['titlen'] == 'COMM493 STRATEGIES FOR VISUAL COMMUNICATIONS':
        lis2.append( 656)
    elif request.GET['titlen'] == 'PSYC308Q PSYCHOLOGY OF RELIGION AND SPIRITUALITY':
        lis2.append(2444)
    elif request.GET['titlen'] == 'CISCO NETWORKING ROUTER TECHNOLOGIES: INTERNETWORKING 2':
        lis2.append( 547)
    elif request.GET['titlen'] == 'INTRDUCTORY PSYCHOLOGY PSY 1010':
        lis2.append(1691)
    elif request.GET['titlen'] == 'FLEET MANAGEMENT ATTC 3520':
        lis2.append(1225)
    elif request.GET['titlen'] == 'LEADERSHIP IN COMMUNITY/PUBLIC HEALTH NURSING':
        lis2.append(1909)
    elif request.GET['titlen'] == 'HS5007 INTRODUCTION TO RESEARCH METHODOLOGY':
        lis2.append(1521)
    elif request.GET['titlen'] == 'REAL PROPERTY':
        lis2.append(2525)
    elif request.GET['titlen'] == 'PRINCIPLE OF HEALTH LIVING  HE100-3RA':
        lis2.append(2373)
    elif request.GET['titlen'] == 'WILLS & ESTATES LA 120-3T':
        lis2.append(2885)
    elif request.GET['titlen'] == 'AMERICAN GOVERNMENT PS 101-3RA':
        lis2.append( 199)
    elif request.GET['titlen'] == 'CJ220 CRIMINAL EVIDENCE & PROCEDURE':
        lis2.append( 554)
    elif request.GET['titlen'] == 'HUMAN RELATIONS':
        lis2.append(1557)
    elif request.GET['titlen'] == 'SOCIOLOGY: CRIMINOLOGY':
        lis2.append(2660)
    elif request.GET['titlen'] == 'SOCIAL PSYCHOLOGY':
        lis2.append(2636)
    elif request.GET['titlen'] == 'AFRICAN POLITICAL THOUGHT - AFST 372 - 01':
        lis2.append( 163)
    elif request.GET['titlen'] == 'ORGANIZATIONAL BEHAVIOR':
        lis2.append(2239)
    elif request.GET['titlen'] == 'EVENT MARKETING':
        lis2.append(1128)
    elif request.GET['titlen'] == 'INCENDIARY FIRE ANALYSIS INVESTIGATION':
        lis2.append(1611)
    elif request.GET['titlen'] == 'REMINGTON 700 RIFLE ARMORER CLASS':
        lis2.append(2542)
    elif request.GET['titlen'] == 'RISK MANAGEMENT':
        lis2.append(2567)
    elif request.GET['titlen'] == 'BIOLOGY 101':
        lis2.append( 336)
    elif request.GET['titlen'] == 'INTERNAL MEDICINE MAINTAINANCE OF CERTIFICATION PREPARTORY COURSE':
        lis2.append(1673)
    elif request.GET['titlen'] == 'NUTRITION FITNESS & WELLNESS':
        lis2.append(2215)
    elif request.GET['titlen'] == 'HS5436 UTILIZATION OF COMMUNITY RESOURCES':
        lis2.append(1523)
    elif request.GET['titlen'] == 'COUPLES AND FAMILY COUNSELING':
        lis2.append( 753)
    elif request.GET['titlen'] == 'SPANISH 101':
        lis2.append(2681)
    elif request.GET['titlen'] == 'FUNDAMENTALS OF ANATOMY & PHYSIOLOGY I':
        lis2.append(1288)
    elif request.GET['titlen'] == 'CRIMINAL LAW':
        lis2.append( 790)
    elif request.GET['titlen'] == 'PRINCIPLE OF HEALTH LIVING':
        lis2.append(2372)
    elif request.GET['titlen'] == 'LEADERSHIP':
        lis2.append(1900)
    elif request.GET['titlen'] == 'INTRODUCTION TO AUTOMOTIVE TECHNOLOGY  ATTC 3000':
        lis2.append(1730)
    elif request.GET['titlen'] == 'INTRODUCTION TO PSYCHOLOGY':
        lis2.append(1784)
    elif request.GET['titlen'] == 'IFSM 300  (INFORMATION SYSTEMS IN ORGANIZATIONS) ':
       lis2.append(1594)
    elif request.GET['titlen'] == 'RSC-801 FUNDAMENTALS OF DOCTORAL LEARNING':
       lis2.append(2576)
    elif request.GET['titlen'] == 'PUAD 624 WB1-4113: PUBLIC ORGANIZATIONTHEORY':
       lis2.append(2470)
    elif request.GET['titlen'] == 'ADDICTIONS PRE PRACTICUM':
       lis2.append(92)
    elif request.GET['titlen'] == 'EDTC 605-----TEACH INFO MEDIA IN DIGITAL WORLD':
       lis2.append( 948)
    elif request.GET['titlen'] == 'MEETINGS AND CONFERENCES - ONLINE - CLASS ID 577':
       lis2.append(2068)
    elif request.GET['titlen'] == 'DISC8140-A INFO SYSTEMS IN LEGAL CONTEXTS     - THE COST PER CLASS IS $4407':
       lis2.append( 888)
    elif request.GET['titlen'] == 'PERSONAL COMPUTER Os SUPPORT':
       lis2.append(2296)
    elif request.GET['titlen'] == 'PERSONAL COMPUTER HARDWARE SUPPORT':
       lis2.append(2295)
    elif request.GET['titlen'] == 'CONSTRUCT PLAN READING':
       lis2.append( 709)
    elif request.GET['titlen'] == 'HUMAN BEHAVIOR AND SOCIAL ':
       lis2.append(1546)
    elif request.GET['titlen'] == 'GENERAL ECOLOGY EVSP416':
       lis2.append(1318)
    elif request.GET['titlen'] == 'WATER SCIENCE EVSP310':
       lis2.append(2865)
    elif request.GET['titlen'] == "GLOCK ARMORE'S COURSE":
       lis2.append(1360)
    elif request.GET['titlen'] == 'HISTORY':
       lis2.append(1451)
    elif request.GET['titlen'] == 'ACCOUNTING INFORMATION SYSTEMS ':
       lis2.append( 69)
    elif request.GET['titlen'] == 'MGMT 554 LEGAL ENVIRONMENT OF BUSINESS':
       lis2.append(2084)
    elif request.GET['titlen'] == 'PSYCHOLOGY 102':
       lis2.append(2453)
    elif request.GET['titlen'] == 'YOUTH CRIME PROBLEMS':
       lis2.append(2923)
    elif request.GET['titlen'] == 'FUNCTIONAL SPOKEN SPANISH':
       lis2.append(1282)
    elif request.GET['titlen'] == 'BMGT 110, INTRODUCTION TO BUSINESS AND MANAGEMENT ':
       lis2.append( 357)
    elif request.GET['titlen'] == 'FUNDAMENTALS OF ANATOMY & PHYSIOLOGY II':
       lis2.append(1289)
    elif request.GET['titlen'] == 'CRIMINAL EVIDENCE/PROCEDURE':
       lis2.append( 778)
    elif request.GET['titlen'] == 'RESEARCH AND STRATEGIC COMMUNICATIONS':
       lis2.append(2552)
    elif request.GET['titlen'] == 'SWCL 710 ADVANCED GROUP METHODS':
       lis2.append(2750)
    elif request.GET['titlen'] == 'SWCL 710 PARADIGMS CLINICAL SOCIAL WORK PRACTICE':
       lis2.append(2751)
    elif request.GET['titlen'] == 'ENGLISH 102':
       lis2.append(1057)
    elif request.GET['titlen'] == 'BUSINESS FINANCE':
       lis2.append( 425)
    elif request.GET['titlen'] == 'PRINCIPLES OF ENGLISH GRAMMER':
       lis2.append(2384)
    elif request.GET['titlen'] == 'BFS 3460 FIRE PROTECTION SYSTEMS':
       lis2.append( 315)
    elif request.GET['titlen'] == 'BFS 3470 FIRE PROTECTION HYDRAULICS AND WATER SUPPLY':
       lis2.append( 316)
    elif request.GET['titlen'] == 'INTRODUCTION TO NUTRITION':
       lis2.append(1775)
    elif request.GET['titlen'] == 'SOCIAL WORK RESEARCH':
       lis2.append(2650)
    elif request.GET['titlen'] == 'ENGLISH':
       lis2.append(1055)
    elif request.GET['titlen'] == 'RACE AND ETHNIC RELATIONS':
       lis2.append(2520)
    elif request.GET['titlen'] == 'METABOLIC BIOCHEMISTRY':
       lis2.append(2072)
    elif request.GET['titlen'] == 'FIRE PREVENTION':
       lis2.append(1214)
    elif request.GET['titlen'] == 'SHRM PHR/SPHR':
       lis2.append(2614)
    elif request.GET['titlen'] == 'P.E. CIVIL REVIEW COURSE':
       lis2.append(2256)
    elif request.GET['titlen'] == 'SOCIAL WORK METHODS II':
       lis2.append(2647)
    elif request.GET['titlen'] == 'FIELD INSTRUCTION I':
       lis2.append(1173)
    elif request.GET['titlen'] == 'PUAD 630 - ANALYTICAL TECHNIQUES':
       lis2.append(2472)
    elif request.GET['titlen'] == 'PUAD - 732 - LEADERSHIP AND ORGANIZATIONAL CHANGE':
       lis2.append(2465)
    elif request.GET['titlen'] == 'INTRODUCITON TO SOCIAL SCIENCES':
       lis2.append(1725)
    elif request.GET['titlen'] == 'DIVERSITY AWARENESS  BEHS 220':
       lis2.append( 898)
    elif request.GET['titlen'] == 'THESIS SEMINAR (CREP 799)':
       lis2.append(2815)
    elif request.GET['titlen'] == 'WRITING A QUALITY PROSPECTUS HUMN  8550':
       lis2.append(2902)
    elif request.GET['titlen'] ==  'QUANTITATIVE REASONING AND ANALYSIS':
       lis2.append(2517)
    elif request.GET['titlen'] ==  'MANAGERIAL ECONOMICS & GLOBALIZATION':
       lis2.append(1988)
    elif request.GET['titlen'] ==  'PARADIGMS CLINICAL SW PRACTICE':
       lis2.append(2266)
    elif request.GET['titlen'] ==  'INTRODUCTION TO LAWYERING SKILLS/CIVIL PROCEDURE I':
       lis2.append(1769)
    elif request.GET['titlen'] ==  'POLITICAL SCIENCE':
       lis2.append(2346)
    elif request.GET['titlen'] ==  'EMGT  306 - POLITICAL AND POLICY ISSUES IN EMERGENCY MANAGEMENT':
       lis2.append(1011)
    elif request.GET['titlen'] ==  'BUSINESS MANAGEMENT':
       lis2.append( 434)
    elif request.GET['titlen'] ==  'EXCL 301 LEARNING ANALYSIS AND PLANNING LECTURE/ TOTAL COAT $798':
       lis2.append(1134)
    elif request.GET['titlen'] ==  'HISTORY OF THE UNITED STATES':
       lis2.append(1468)
    elif request.GET['titlen'] ==  'NSCI 362 ENVIRON CHANGE SUSTAINABILITY':
       lis2.append(2175)
    elif request.GET['titlen'] ==  'ACCOUNTING I':
       lis2.append(66)
    elif request.GET['titlen'] ==  'STUDENT LEARNING SUCCESS':
       lis2.append(2736)
    elif request.GET['titlen'] ==  'SUPERVISION RELATIONSHIP TRAINING':
       lis2.append(2742)
    elif request.GET['titlen'] ==  'ANTHROPOLOGY - AN-105':
       lis2.append( 228)
    elif request.GET['titlen'] ==  'MODELS OF SUPERVISION TRAINING':
       lis2.append(2127)
    elif request.GET['titlen'] ==  'GROUP/MULTICULTURAL SUPERVISION TRAINING':
       lis2.append(1386)
    elif request.GET['titlen'] ==  'ETHICS SUPERVISION TRAINING':
       lis2.append(1123)
    elif request.GET['titlen'] ==  'ADV. PRACTICE WITH INDIVIDUAL':
       lis2.append( 102)
    elif request.GET['titlen'] ==  'PSYCHOPATHOLOGY':
       lis2.append(2460)
    elif request.GET['titlen'] ==  'ADMINISTRATION THEORY':
       lis2.append(96)
    elif request.GET['titlen'] ==  'INTERCULTURAL COMMUNICATION AND LEADERSHIP':
       lis2.append(1652)
    elif request.GET['titlen'] ==  'THE MD SHRM STRATEGIC BUSINESS COURSE':
       lis2.append(2796)
    elif request.GET['titlen'] ==  'MHA 501 ORGANIZATIONAL COMMUNICATION':
       lis2.append(2108)
    elif request.GET['titlen'] ==  'ACCOUNTING 608 FRAUD EXAMINATION AND ACCOUNTING ETHICS':
       lis2.append(61)
    elif request.GET['titlen'] ==  'INTRODUCTION TO GEOGRAPHY ( # 81406-6980)':
       lis2.append(1753)
    elif request.GET['titlen'] ==  'FOUNDATION IN AGING CERTIFICATE':
       lis2.append(1244)
    elif request.GET['titlen'] ==  'EHS 630 ISSUES AND PROPOSALS':
       lis2.append( 963)
    elif request.GET['titlen'] ==  'NURSING IN HEALTH ILLNESS':
       lis2.append(2201)
    elif request.GET['titlen'] ==  'NURSING IN MENTAL HEALTH ILLNESS':
       lis2.append(2203)
    elif request.GET['titlen'] ==  'APPRAISAL AND ASSESSMENTS':
       lis2.append( 238)
    elif request.GET['titlen'] ==  'ALCOHOL IN U.S. SOCIETY':
       lis2.append( 183)
    elif request.GET['titlen'] ==  'HISTORY OF TERRORISM':
       lis2.append(1463)
    elif request.GET['titlen'] ==  'HISTORY OF VIOLENCE IN AMERICA':
       lis2.append(1470)
    elif request.GET['titlen'] ==  'PROJECT MANAGEMENT ESSENTIALS AND BEST PRACTICES':
       lis2.append(2413)
    elif request.GET['titlen'] ==  'PROJECT MANAGEMENT INTEGRATION WITH MICROSOFT PROJECT 2007':
       lis2.append(2417)
    elif request.GET['titlen'] ==   'ELECTRONICS AND INSTRUMENTATION ONE':
       lis2.append( 971)
    elif request.GET['titlen'] ==   'FIN 100        PRINCIPLES OF FINANCE':
       lis2.append(1175)
    elif request.GET['titlen'] ==    'SCI 110     INTRODUCTION TO PHYSICAL SCIENCE':
       lis2.append(2586)
    elif request.GET['titlen'] ==    'PUAD 734 STRATEGIC PLANNING':
       lis2.append(2474)
    elif request.GET['titlen'] ==    'PUAD 798 PROBLEM SOLVING IN PA':
       lis2.append(2476)
    elif request.GET['titlen'] ==    'ECONOMICS ':
       lis2.append( 922)
    elif request.GET['titlen'] ==    'ALGEBRA':
       lis2.append( 184)
    elif request.GET['titlen'] ==    'SOCIOLOGY':
       lis2.append(2652)
    elif request.GET['titlen'] ==  'HEALTH NUTRITION':
       lis2.append(1416)
    elif request.GET['titlen'] ==  'PROJECT MANAGEMENT ESSENTIALS AND BEST PRACTICES (PMC001)':
       lis2.append(2414)
    elif request.GET['titlen'] ==  'GENERAL BIOLOGY':
       lis2.append(1316)
    elif request.GET['titlen'] ==  'SIX SIGMA GREENBELT CERTIFICATION':
       lis2.append(2619)
    elif request.GET['titlen'] ==  'FLUID MECHANICS':
       lis2.append(1226)
    elif request.GET['titlen'] ==  '2012 MD SHRM STRATEGIC BUSINESS COURSE:  MANAGING INDIVIDUAL AND ORGANIZATIONAL CHANGE':
       lis2.append(10)
    elif request.GET['titlen'] ==  'BUSINESS 101':
       lis2.append( 414)
    elif request.GET['titlen'] ==  'SEMINAR':
        lis2.append(2599)
    elif request.GET['titlen'] ==  'COMMUNITY HEALTH':
       lis2.append( 666)
    elif request.GET['titlen'] ==  'WEB APPLICATION DEVELOPMENT USING PHP & MYSQL':
       lis2.append(2871)
    elif request.GET['titlen'] ==  'ADVANCED DATABASE APPLICATION':
       lis2.append( 128)
    elif request.GET['titlen'] ==  'SIGN LANGUAGE  ASL I':
       lis2.append(2617)
    elif request.GET['titlen'] ==   'PROBLEMS OF SOUTHERN AFRICA - POLS 271 - 01':
       lis2.append(2399)
    elif request.GET['titlen'] ==    'MATHEMATICS':
       lis2.append(2045)
    elif request.GET['titlen'] ==     'INTRODUCTION TO HEALTH CARE ADMINISTRATION':
       lis2.append(1760)
    elif request.GET['titlen'] ==     'STRATEGIC MANAGEMENT CAPSTONE':
       lis2.append(2723)
    elif request.GET['titlen'] ==     'ACCOUNTING 213':
       lis2.append(49)
    elif request.GET['titlen'] ==      'FOOD SERVICE SANITATION':
       lis2.append(1227)
    elif request.GET['titlen'] == 'RESEARCH METHODS IN SOCIAL SCIENCE':
       lis2.append(2562)
    elif request.GET['titlen'] == 'WORD PROCESS APPLICATION':
       lis2.append(2890)
    elif request.GET['titlen'] ==  'IFSM 300 (INFORMATION SYSTEMS IN ORGANIZATIONS)':
       lis2.append(1595)
    elif request.GET['titlen'] ==  'GERONTOLOGY':
       lis2.append(1336)
    elif request.GET['titlen'] ==  'ADVANCED BUSINESS ENGLISH':
       lis2.append( 119)
    elif request.GET['titlen'] ==     'INTRODUCTION TO GEOGRAPHIC INFORMATION SYSTEMS':
       lis2.append(1752)
    elif request.GET['titlen'] ==      'FORENSIC BIOLOGY':
       lis2.append(1238)
    elif request.GET['titlen'] ==      'INTRO TO STATISTICAL METHOD':
       lis2.append(1718)
    elif request.GET['titlen'] ==      'MICROBIOLOGY':
       lis2.append(2112)
    elif request.GET['titlen'] ==       'CHILD PSYCHOLOGY':
       lis2.append( 534)
    elif request.GET['titlen'] ==       'EMERGENCY RESPONSE PREPAREDNESS AND PLANNING (EMGT 304)':
       lis2.append(1007)
    elif request.GET['titlen'] ==        'COMPUTERS USE AND MANAGEMENT':
       lis2.append( 693)
    elif request.GET['titlen'] ==        'LBSC 735 LEGAL ISSUES IN MANAGING INFORMATION':
       lis2.append(1894)
    elif request.GET['titlen'] ==    'PUAD 623 BUREACRACY AND THE POLITICAL PROCESS':
       lis2.append(2468)
    elif request.GET['titlen'] ==     'PUAD 624 PUBLIC ADMINISTRATION THEORY':
       lis2.append(2469)
    elif request.GET['titlen'] ==     'PUAD 628 STATISTICAL APPLICATIONS IN PUBLIC ADMINSTRATION':
       lis2.append(2471)
    elif request.GET['titlen'] ==      'ITI123: ANDROID DEVELOPMENT I':
       lis2.append(1844)
    elif request.GET['titlen'] ==       'ITI081: IPHONE AND IPAD FOR APPLICATION PROGRAMMING-LEVEL I':
       lis2.append(1841)
    elif request.GET['titlen'] ==       'AMERICAN SIGN LANGUAGE':
       lis2.append( 208)
    elif request.GET['titlen'] == 'ITI124: ANDROID DEVELOPMENT II':
       lis2.append(1845)
    elif request.GET['titlen'] ==       'ITI082: IPHONE AND IPAD FOR APPLICATION PROGRAMMING-LEVEL II':
       lis2.append(1842)
    elif request.GET['titlen'] ==        'ITI133: HTML5: DESKTOP AND MOBILE--LEVEL I':
       lis2.append(1846)
    elif request.GET['titlen'] ==       'ITI134: HTML5: DESKTOP AND MOBILE--LEVEL II':
       lis2.append(1847)
    elif request.GET['titlen'] ==       'ITI105: ADOBE PHOTOSHOP I - FOUNDATION SKILLS':
       lis2.append(1843)
    elif request.GET['titlen'] ==        'ITE 115 - INTRO COMPUTER APPL/CONCEPTS':
       lis2.append(1837)
    elif request.GET['titlen'] ==       'ITN 100 - INTRO/TELECOMMUNICATIONS':
       lis2.append(1850)
    elif request.GET['titlen'] ==       'ITN 260 - NETWORK SEC. BASICS':
       lis2.append(1851)
    elif request.GET['titlen'] ==       'ITE  221 - E80W   PC HARDWARE & O/S ARCHITECTURE':
       lis2.append(1836)
    elif request.GET['titlen'] ==        'INTRODUCTION TO CARTOGRAPHY':
       lis2.append(1733)
    elif request.GET['titlen'] ==  'BAR REVIEW':
       lis2.append( 285)
    elif request.GET['titlen'] ==        'BUILDING TRADES - BLUE PRINT READING':
       lis2.append( 394)
    elif request.GET['titlen'] ==         'AIR CONDITIONING AND HEAT PUMP - BU 273 - 401':
       lis2.append( 176)
    elif request.GET['titlen'] ==          'GENERAL SOCIAL WORK PRACTICE 1':
       lis2.append(1325)
    elif request.GET['titlen'] ==           'ORGANIZATIONAL POLICY & LEADERSHIP IN HUMAN SERVICES':
       lis2.append(2247)
    elif request.GET['titlen'] ==            'AMERICAN LITERATURE II':
       lis2.append( 202)
    elif request.GET['titlen'] ==            'BCJ 4701 CRIMINAL JUSTICE ORGANIZATION':
       lis2.append( 299)
    elif request.GET['titlen'] ==         'CRISIS MANAGEMENT AND COMMUNICATIONS':
       lis2.append( 802)
    elif request.GET['titlen'] == 'WILDLAND FIRES: SCIENCE AND APPLICATIONS':
       lis2.append(2883)
    elif request.GET['titlen'] == 'ELEMENTARY SPANISH ( # 82270-7981)':
       lis2.append( 979)
    elif request.GET['titlen'] == 'ACCOUNTING QUICKBOOKS I AND II':
       lis2.append(70)
    elif request.GET['titlen'] == 'INTRO TO DATABASE MGMT SYSTEM':
       lis2.append(1702)
    elif request.GET['titlen'] == 'COLLEGE ALGEBRA':
       lis2.append( 642)
    elif request.GET['titlen'] == 'FINANCIAL PLAN & INVESTMENT':
       lis2.append(1187)
    elif request.GET['titlen'] == 'EDUCATIONAL PSYCHOLOGY':
       lis2.append( 954)
    elif request.GET['titlen'] ==  'CONTEMPORARY ISSUES':
       lis2.append( 713)
    elif request.GET['titlen'] ==             'NURSING CONCEPTS':
       lis2.append(2195)
    elif request.GET['titlen'] ==              'COUNTERTERRORISM':
       lis2.append( 752)
    elif request.GET['titlen'] ==              'NURSING 6180':
       lis2.append( 2190)
    elif request.GET['titlen'] ==               'COLL100 FOUNDATIONS OF ONLINE LEARNING':
       lis2.append(639)
    elif request.GET['titlen'] ==               'ENG 101 PROFICIENCY IN WRITING':
       lis2.append( 1041)
    elif request.GET['titlen'] ==           'AMERICAN SIGN LANGUAGE III - ASLS L202 #2051':
       lis2.append(211)
    elif request.GET['titlen'] ==            'ACCOUNTING II':
       lis2.append(67)
    elif request.GET['titlen'] ==             'CRJ501 SEMINAR IN CRIMINAL JUSTICE':
       lis2.append(817)
    elif request.GET['titlen'] ==             "WOMEN'S STUDIES":
       lis2.append( 2886)
    elif request.GET['titlen'] ==             'PRINCIPLES OF MAP DESIGN':
       lis2.append( 2388)
    elif request.GET['titlen'] ==             'FINANCE FOR BUSINESS':
       lis2.append( 1178)
    elif request.GET['titlen'] ==             'ACCOUNTING':
       lis2.append(46)
    elif request.GET['titlen'] ==             'NURSING IN MENTAL HEALTH':
       lis2.append( 2202)
    elif request.GET['titlen'] ==             'MICROBIOLOGY 203':
       lis2.append( 2113)
    elif request.GET['titlen'] ==             'EDD 7106 DISCIPLINED INQUIRY I':
       lis2.append(936)
    elif request.GET['titlen'] ==             'EDD 7000 EXPERIENTAL LEARNING: LEADERSHIP ISSUES':
       lis2.append(935)
    elif request.GET['titlen'] ==             'SURVEY OF CORRECTIONS':
       lis2.append( 2746)
    elif request.GET['titlen'] ==            'SOCIOLOGY 101':
       lis2.append( 2653)
    elif request.GET['titlen'] ==             'COMPUTER USE AND MANAGEMENT':
       lis2.append(691)
    elif request.GET['titlen'] ==             'INTRODUCTION TO COMPUTER APPLICATIONS':
       lis2.append( 1736)
    elif request.GET['titlen'] ==             'FINANCIAL MANAGEMENT':
       lis2.append( 1182)
    elif request.GET['titlen'] ==             'TECH OF RDNG & WRTG 1':
       lis2.append( 2775)
    elif request.GET['titlen'] ==              'EN 101,TECH OF RDNG & WRTG':
       lis2.append( 1028)
    elif request.GET['titlen'] ==              'ENGLISH 201':
       lis2.append( 1064)
    elif request.GET['titlen'] ==               'COMPREHENSIVE LACTATION COURSE':
       lis2.append(675)
    elif request.GET['titlen'] ==                'INTRODUCTION TO FEDERAL CONTRACTING AND PROCUREMENT':
       lis2.append( 1746)
    elif request.GET['titlen'] ==                'AMBA 640 MANAGING PROJECTS, OPERATIONS AND INFORMATION SYSTEMS':
       lis2.append(189)
    elif request.GET['titlen'] ==                 'HUMAN ANAT & PHYS II':
       lis2.append(1542,)
    elif request.GET['titlen'] == 'PRIMARY CARE OF THE FAMILY':
       lis2.append( 2363)
    elif request.GET['titlen'] ==                 'ASSESSMENT AND MANAGEMENT OF FAMILY CARE':
       lis2.append(271)
    elif request.GET['titlen'] ==                 'PSY/360':
       lis2.append( 2436)
    elif request.GET['titlen'] ==                 'WRTG 394 ADVANCED BUSINESS WRITING':
       lis2.append( 2921)
    elif request.GET['titlen'] ==                'CMST 295    FUNDAMENTALS OF DIGITAL MEDIA':
       lis2.append(626)
    elif request.GET['titlen'] ==                 'WORLD CLASS PROCUREMENT PRACTICES':
       lis2.append(2894)
    elif request.GET['titlen'] ==                 'ENGLISH 311 17TH AND 18TH CENTURY BRITISH LITERATURE':
       lis2.append(1070)
    elif request.GET['titlen'] ==                 'ENGL 303 CRITICAL APPROACHES TO LITERATURE':
       lis2.append(1051)
    elif request.GET['titlen'] ==                  'HIST 309 HISTORICAL WRITING':
       lis2.append(1442)
    elif request.GET['titlen'] ==                  'ON CHEMICAL DEPENDENCE AND HUMAN DEVELOPMENT':
       lis2.append(2231)
    elif request.GET['titlen'] ==                  'MGMT 615 - INTERNATIONAL COMM LEADERSHIP':
       lis2.append(2094)
    elif request.GET['titlen'] ==                   'MGMT 640 - FINANCIAL DECISION MAKING FOR MANAGERS':
       lis2.append(2098)
    elif request.GET['titlen'] ==                   'MGT315: 40-HOUR BASIC MEDIATION COURSE':
       lis2.append(2105)
    elif request.GET['titlen'] ==                 'MGMT 551 MANAGEMENT THEORY':
       lis2.append(2082)
    elif request.GET['titlen'] ==                  'FIRE PREVENTION ORGANIZATION & MANAGEMENT':
       lis2.append(1215)
    elif request.GET['titlen'] ==                   'INTERMEDIATE ENGLISH':
       lis2.append(1664)
    elif request.GET['titlen'] ==                   'BUSINESS LAW I. 380,':
       lis2.append( 431)
    elif request.GET['titlen'] ==                   'BUSINESS LAW II. 381':
       lis2.append( 433)
    elif request.GET['titlen'] ==                   'ALGEBRA WITH APPLICATIONS':
       lis2.append( 186)
    elif request.GET['titlen'] ==                    'IMPLEMENTING VERSIONED WORKFLOWS IN A MULTIUSER GEODATABASE':
       lis2.append(1610)
    elif request.GET['titlen'] ==                    'SOCIAL JUSTICE AND HEALTH CARE POLICY':
       lis2.append(2632)
    elif request.GET['titlen'] ==                     'PERSPECTIVES IN LAW ENFORCEMENT MANAGEMENT':
       lis2.append(2306)
    elif request.GET['titlen'] ==                      'INTERCULTURAL COMMUNITY LEADERSHIP':
       lis2.append(1654)
    elif request.GET['titlen'] ==                       'HAZARD ASSESSMENT AND PREPAREDNESS':
       lis2.append(1391)
    elif request.GET['titlen'] ==                       'BMGT 365 ORGANIZATIONAL LEADERSHIP':
       lis2.append( 362)
    elif request.GET['titlen'] ==                       'HRMN 300 HUMAN RESOURCE MANAGEMENT':
       lis2.append(1513)
    elif request.GET['titlen'] ==                        'SOCIAL AND ETHICAL DIMENSIONS OF ENGINEERING TECHNOLOGY':
       lis2.append(2630)
    elif request.GET['titlen'] ==                        'ANALOG AND DIGITAL ELECTRONICS':
       lis2.append( 214)
    elif request.GET['titlen'] ==                        'COMPUTER ORGANIZATION':
       lis2.append( 685)
    elif request.GET['titlen'] ==                        'ALGORITHMS':
       lis2.append( 188)
    elif request.GET['titlen'] ==                        'ONLINE COURSE: HOW TO PROCESS AND EVALUATE BIDS':
       lis2.append(2233)
    elif request.GET['titlen'] ==                        'WORLD RELIGIONS':
       lis2.append(2898)
    elif request.GET['titlen'] ==                        'MATH 009, INTRODUCTORY ALGEBRA ':
       lis2.append(2020)
    elif request.GET['titlen'] ==                       'MATH 012':
       lis2.append(2021)
    elif request.GET['titlen'] ==                        'NURSING':
       lis2.append(2188)
    elif request.GET['titlen'] ==                        'ENGLISH LITERATURE AND COMPOSITION':
       lis2.append(1078)
    elif request.GET['titlen'] ==                        'HISTORY OF THE AMERICAN INDIAN':
       lis2.append(1464)
    elif request.GET['titlen'] ==                         'THE GEORGE WASHINGTON OFFICE OF CONTINUING EDUCATION: PEDIATRIC BOARD REVIEW':
       lis2.append(2791)
    elif request.GET['titlen'] ==                         '2012 MAINTENANCE OF CERTIFICATION EXAM PREPARATION COURSE: INTERNAL MEDICINE':
       lis2.append(9)
    elif request.GET['titlen'] ==                         'CELLULAR AND PHYSIOLOGICAL TRANSPORT PHENOMENA':
       lis2.append( 490)
    elif request.GET['titlen'] =='PHA 6935  PRINCIPLES OF FORENSIC SCIENCE':
       lis2.append(2311)
    elif request.GET['titlen'] == 'TACTICAL PISTOL 1':
       lis2.append(2768)
    elif request.GET['titlen'] =='CISCO CCNA':
       lis2.append( 544)
    elif request.GET['titlen'] == 'HEALTH 101':
       lis2.append(1403)
    elif request.GET['titlen'] ==                          'CERAMICS I':
       lis2.append( 497)
    elif request.GET['titlen'] ==                           'GOVP200 INTERNATIONAL POLITICAL RELATIONS':
       lis2.append(1378)
    elif request.GET['titlen'] ==                            'HOMELAND SECURITY  (HMLS 310)':
       lis2.append(1488)
    elif request.GET['titlen'] ==                             'CALCULUS I':
       lis2.append( 448)
    elif request.GET['titlen'] ==                             'ECONOMICS 201':
       lis2.append( 923)
    elif request.GET['titlen'] ==                              'CONTEMPORARY GLOBAL CONTROVERSIES':
       lis2.append( 712)
    elif request.GET['titlen'] ==                               'INTRODUCTION TO GLOBAL HEALTH':
       lis2.append(1755)
    elif request.GET['titlen'] ==                                'FINANCIAL DECISION MAKING FOR MANAGERS':
       lis2.append(1181)
    elif request.GET['titlen'] ==                                'INTRO TO GRADUATE LIBRARY RESEARCH SKILLS':
       lis2.append(1705)
    elif request.GET['titlen'] ==                                 'ECON 551: FOUNDATIONS OF ECONOMICS':
       lis2.append( 920)
    elif request.GET['titlen'] ==                                  "GLOCK ARMORE'S COURSE-ADVANCED ARMORERS COURSE":
       lis2.append(1361)
    elif request.GET['titlen'] ==                                   'ELEMENTARY SIGN LANGUAGE':
       lis2.append( 978)
    elif request.GET['titlen'] ==                              'ORGANIZATIONAL THEORY AND BEHAVIOR':
       lis2.append(2249)
    elif request.GET['titlen'] ==                              'LEGAL ENV. BUSINESS':
       lis2.append(1931)
    elif request.GET['titlen'] ==                              'INTRO TO US POLITICS':
       lis2.append(1721)
    elif request.GET['titlen'] ==                              'BMS 23500 PHARMACOLOGY FOR VETERINARY TECHNICIANS':
       lis2.append( 378)
    elif request.GET['titlen'] ==                               "COLT ARMORER'S COURSE-M16/M4 RIFLE":
       lis2.append(646)
    elif request.GET['titlen'] =='CRIMINAL JUSTICE':
       lis2.append( 781)
    elif request.GET['titlen'] ==                                'STATISTICS':
       lis2.append(2712)
    elif request.GET['titlen'] == 'INTRODUCTON TO RESEARCH':
       lis2.append(1805)
    elif request.GET['titlen'] ==                                 'STRATEGIC PROCUREMENT PLANNING':
       lis2.append(2729)
    elif request.GET['titlen'] ==                                 'LAW-ENFORCEMENT ADMINISTRATION':
       lis2.append(1891)
    elif request.GET['titlen'] ==                                  'PSYCHOLOGY OF INTERPERSONAL RELATIONSHIPS':
       lis2.append(2456)
    elif request.GET['titlen'] ==                                   'BUS 409  COMPENSATION MANAGEMENT':
       lis2.append( 399)
    elif request.GET['titlen'] ==                                   'CIS 111      INTRO TO RELAT DBASE MGT SYST':
       lis2.append( 539)
    elif request.GET['titlen'] ==                               'INFORMATION SYSTEM MANAGEMENT':
       lis2.append(1628)
    elif request.GET['titlen'] ==                               'ADVANCED PATROL RIFLE':
       lis2.append( 139)
    elif request.GET['titlen'] ==                                'HAZMAT SAFETY OFFICER':
       lis2.append(1395)
    elif request.GET['titlen'] ==                                 'ADVANCED DIALECTICAL BEHAVIOR THERAPY':
       lis2.append( 129)
    elif request.GET['titlen'] ==                                 'DIALECTICAL BEHAVIOR THERAPY':
       lis2.append( 877)
    elif request.GET['titlen'] ==                                  'Remote Medicine for the Advanced Provider':
       lis2.append(2579)
    elif request.GET['titlen'] ==                                   'SPANISH LANGUAGE TRAINING':
       lis2.append(2689)
    elif request.GET['titlen'] ==                                    'CMRJ501 CRIMINOLOGY':
       lis2.append( 609)
    elif request.GET['titlen'] ==                                     'ALBEBRA 1B':
       lis2.append( 180)
    elif request.GET['titlen'] ==                                      'BUSINESS COMMUNICATIONS & CRITICAL THINKING':
       lis2.append( 421)
    elif request.GET['titlen'] ==                                      'CELLBRITE CELL PHONE DATA RETREIVAL TRAINING':
       lis2.append( 488)
    elif request.GET['titlen'] ==                                      'CERTIFIED FORENSIC COMPUTER EXAMINER':
       lis2.append( 502)
    elif request.GET['titlen'] ==                                 'INTERVIEW AND INTERROGATION SEMINAR':
       lis2.append(1684)
    elif request.GET['titlen'] ==                                  'CONCEPTS AND APPLICATIONS OF INFORMATION TECHNOLOGY':
       lis2.append( 698)
    elif request.GET['titlen'] ==                                   'PUBLIC POLICY 201 - INTRO. TO HOMELAND SECURITY':
       lis2.append(2492)
    elif request.GET['titlen'] ==                                    'HHS034:  PHLEBOTOMY TECHNICIAN':
       lis2.append(1431)
    elif request.GET['titlen'] ==                                    'CMRJ505 RESEARCH METHODS IN CRIMINAL JUSTICE AND SECURITY':
       lis2.append( 610)
    elif request.GET['titlen'] ==                                    'WESTERN CIVILIZATION II':
       lis2.append(2878)
    elif request.GET['titlen'] ==                                     'ALGEBRA, INTERMEDIATE':
       lis2.append( 187)
    elif request.GET['titlen'] ==                                     'WRTG 101 - INTRODUCTION TO WRITING':
       lis2.append(2910)
    elif request.GET['titlen'] ==                                     'LIBS 150 - INTRODUCTION TO RESEARCH':
       lis2.append(1947)
    elif request.GET['titlen'] ==                                     'AUTOMOTIVE ELECTRICITY I':
       lis2.append( 284)
    elif request.GET['titlen'] ==                                    'HHS034 PHLEBOTOMY TECHNICIAN':
       lis2.append(1430)
    elif request.GET['titlen'] ==                                     'PHLEBOTOMY TECH':
       lis2.append(2326)
    elif request.GET['titlen'] ==                                      'INTELLIGENCE ANALYSIS':
       lis2.append(1645)
    elif request.GET['titlen'] ==                                       'CJAC 424 COMMUNITY POLICING':
       lis2.append( 557)
    elif request.GET['titlen'] ==                                        'CJAC 434 OPERATIONS MANAGEMENT IN CRIMINAL JUSTICE ORGANIZATIONS':
       lis2.append( 558)
    elif request.GET['titlen'] ==                                        'CARE AND PREVENTION OF ATHLETIC INJURY':
       lis2.append( 456)
    elif request.GET['titlen'] ==                                        'MINORITIES IN THE UNITED STATES':
       lis2.append(2117)
    elif request.GET['titlen'] ==                                         'INTRODUCTION TO DRAWING':
       lis2.append(1743)
    elif request.GET['titlen'] ==                                         'RESEARCH METHODS IN PSYCHOLOGY':
       lis2.append(2561)
    elif request.GET['titlen'] ==                                         'PSYCHOLOGY OF RELIGION AND SPIRITUALITY':
       lis2.append(2457)
    elif request.GET['titlen'] ==                                          'FOUNDATIONS OF FORENSIC PSYCHOLOGY':
       lis2.append(1253)
    elif request.GET['titlen'] ==                                        'LE CUSTOM CARBINE COURSE':
       lis2.append(1897)
    elif request.GET['titlen'] ==                                        'ENGLISH WRITING/ENGLISH 101':
       lis2.append(1080)
    elif request.GET['titlen'] ==                                        'INTERMEDIATE ALGEBRA/MAT 92':
       lis2.append(1661)
    elif request.GET['titlen'] ==                                         'HHS 034 PHLEBOTOMY TECH':
       lis2.append(1428)
    elif request.GET['titlen'] ==                                          'PROTECTIVE AND EVASIVE DRIVING':
       lis2.append(2423)
    elif request.GET['titlen'] ==                                          'CELL PHONE TECHNOLOGY AND FORENSIC DATA RECOVERY CERTIFICATION':
       lis2.append( 487)
    elif request.GET['titlen'] ==                                          'INTRODUCTION TO HUMANITIES':
       lis2.append(1766)
    elif request.GET['titlen'] ==                                           'PRINCIPLES OF WEB DESIGN AND TECHNOLOGY IT':
       lis2.append(2393)
    elif request.GET['titlen'] ==                                            "PAT MCCARTHY'S STREET CRIMES SEMINAR":
       lis2.append(2269)
    elif request.GET['titlen'] ==                                            'AJS/501 INTRO TO GRADUATE STUDY IN CRIMINAL JUSTICE AND SECURITY':
       lis2.append( 178)
    elif request.GET['titlen'] ==                                           'AJS/502 SUVERY OF JUSTICE AND SECURITY':
       lis2.append( 179)
    elif request.GET['titlen'] ==                                            'BCJ 4101 POLICE AND COMMUNITY RELATIONS':
       lis2.append( 298)
    elif request.GET['titlen'] ==                                             'K9 TRAILING SEMINAR':
       lis2.append(1870)
    elif request.GET['titlen'] ==                                             'STREET CRIMES SEMINAR':
       lis2.append(2731)
    elif request.GET['titlen'] ==                                             'MATH-ALGEBRA':
       lis2.append(2040)
    elif request.GET['titlen'] ==                                              'INTRODUCTION TO FORESTRY WITH LAB':
       lis2.append(1751)
    elif request.GET['titlen'] ==                                               'EDD7107: DISCIPLINE INQUIRY II':
       lis2.append( 943)
    elif request.GET['titlen'] ==                                                'MAT 107/MODERN ELEMENTARY STATISTICS':
       lis2.append(2011)
    elif request.GET['titlen'] ==                                                'ABNORMAL PSYCHOLOGY':
       lis2.append(38)
    elif request.GET['titlen'] ==                                                 'ES100-INTRODUCTION TO ENGINEERING DESIGN':
       lis2.append(1099)
    elif request.GET['titlen'] ==                                                  'STATISTICS -102':
       lis2.append(2713)
    elif request.GET['titlen'] ==                                                   'MANGEMENT OF HUMAN RESOURCES':
       lis2.append(1994)
    elif request.GET['titlen'] ==                                                    'PERSONALIZED APPROACH TO HEALTH':
       lis2.append(2302)
    elif request.GET['titlen'] ==                                             'INTRO/GRAPHIC DESIGN SOFTWARE - ADS 319':
       lis2.append(1723)
    elif request.GET['titlen'] ==                                             'INTRO TO SQL USING ORACLE':
       lis2.append(1717)
    elif request.GET['titlen'] ==                                             'WEB APPS USING COLDFUSION':
       lis2.append(2872)
    elif request.GET['titlen'] ==                                             'EVALUATION RESEARCH':
       lis2.append(1125)
    elif request.GET['titlen'] ==                                             'GE 263':
       lis2.append(1312)
    elif request.GET['titlen'] ==                                              'EDD7106: DISCIPLINE INQUIRY 1':
       lis2.append( 942)
    elif request.GET['titlen'] ==                                              'EDD7204: ART OF LEADERSHIP':
       lis2.append( 944)
    elif request.GET['titlen'] ==                                              'EDD 7202: DATA DRIVEN DECISION MAKING':
       lis2.append( 938)
    elif request.GET['titlen'] ==                                              'GB 612 51 LEGAL & REGULATORY ENVIRONMENT':
       lis2.append(1308)
    elif request.GET['titlen'] ==                                              'OMDE 610 TEACHING AND LEARNING IN ONLINE DISTANCE EDUCATION (3)':
       lis2.append(2230)
    elif request.GET['titlen'] ==                                               'LEARNER SUPPORT IN DISTANCE EDUCATION AND TRAINING':
       lis2.append(1920)
    elif request.GET['titlen'] ==                                             'ADVANCED QUALITATIVE RESEARCH METHODS':
       lis2.append( 142)
    elif request.GET['titlen'] ==                                             'THEORY ANALYSIS OF BEHAVIOR':
       lis2.append(2811)
    elif request.GET['titlen'] ==                                             'ACCOUNTING 201':
       lis2.append(47)
    elif request.GET['titlen'] ==                                              'ECON 201, PRINCIPLES OF MACROECONOMICS':
       lis2.append( 917)
    elif request.GET['titlen'] ==                                              'HOW TO CREATE AN EFFECTIVE WORK BREAKDOWN STRUCTURE':
       lis2.append(1497)
    elif request.GET['titlen'] ==                                               'COMPUTER CONCEPTS':
       lis2.append( 681)
    elif request.GET['titlen'] ==                                               'PRINCIPLES HEALTHIER LIVING':
       lis2.append(2374)
    elif request.GET['titlen'] ==                                                'ART THERAPY':
       lis2.append( 257)
    elif request.GET['titlen'] ==                                                'INFOMATION TECHNOLOGY':
       lis2.append(1623)
    elif request.GET['titlen'] ==                                                 'CALCULUS II':
       lis2.append( 449)
    elif request.GET['titlen'] ==                                                 'IFSM 304- 5125. ETHICS IN INFORMATION TECHNOLOGY':
       lis2.append(1598)
    elif request.GET['titlen'] ==                                                 'APPLIED CALCULUS':
       lis2.append( 232)
    elif request.GET['titlen'] ==                                                 'COUNSELOR PROFESSIONAL IDENTITY, FUNCTION AND ETHICS':
       lis2.append( 748)
    elif request.GET['titlen'] ==                                               'HUMAN GROWTH AND DEVELOPMENT':
       lis2.append(1555)
    elif request.GET['titlen'] ==                                               'LAW 711 - CONSTITUTIONAL CRIMINAL PROCEDURE I':
       lis2.append(1885)
    elif request.GET['titlen'] ==                                                'U.S. HISTORY':
       lis2.append(2837)
    elif request.GET['titlen'] ==                                                 'ANATOMY AND PHYSIOLOGY II':
       lis2.append( 217)
    elif request.GET['titlen'] ==                                                 'PHYSIOLOGY':
       lis2.append(2332)
    elif request.GET['titlen'] ==                                                 'HOLISTIC HEALTH AND LIFESTYLES':
       lis2.append(1483)
    elif request.GET['titlen'] ==                                                 'ANATOMY AND PHYSIOLOGY':
       lis2.append( 216)
    elif request.GET['titlen'] ==                                                 'HEAL300 - BIOSTATISTICS FOR OUBLIC HEALTH PRACTICE':
       lis2.append(1400)
    elif request.GET['titlen'] ==                                                  'PROGRAM EVALUATION':
       lis2.append(2407)
    elif request.GET['titlen'] ==                                                   'ENGL395 - WRITING FOR HEALTH PROFESSIONS':
       lis2.append(1054)
    elif request.GET['titlen'] ==                                                   'HLTH434 - INTRO TO PUBLIC HEALTH INFORMATICS':
       lis2.append(1477)
    elif request.GET['titlen'] ==                                                   'VICTIMOLOGY':
       lis2.append(2856)
    elif request.GET['titlen'] ==                                                  'PRIVATE SECURITY':
       lis2.append(2394)
    elif request.GET['titlen'] ==                                                  'CORRECTIONAL ADMINISTRATION':
       lis2.append( 732)
    elif request.GET['titlen'] ==                                                  'PROBATION & PAROLE':
       lis2.append(2397)
    elif request.GET['titlen'] ==                                                   'STAT  225 - INTRODUCTION TO STATISTICAL METHODS FOR THE BEHAVIORAL SCIENCES':
       lis2.append(2709)
    elif request.GET['titlen'] ==                                                    'WRTG 391 ADVANCED EXPOSITORY AND RESEARCH WRITING':
       lis2.append(2916)
    elif request.GET['titlen'] ==                                                     'BEHS 380 - END OF LIFE: ISSUES AND PERSPECTIVES':
       lis2.append( 313)
    elif request.GET['titlen'] ==                                                     'MGMT 563- MARKETING MANAGEMENT':
       lis2.append(2087)
    elif request.GET['titlen'] ==                                                     'CIS 127 MS WINDOWS OPERATING SYSTEMS':
       lis2.append( 540)
    elif request.GET['titlen'] ==                                                      'INDUSTRIAL AND ORGANIZATIONAL PSYCHOLOGY':
       lis2.append(1614)
    elif request.GET['titlen'] ==                                                       'DISSERTATION GUIDANCE':
       lis2.append( 895)
    elif request.GET['titlen'] ==                                                    'CNT 120 NETWORK COMM TECH I':
       lis2.append( 630)
    elif request.GET['titlen'] ==                                                     'ELEC 125 INTODUCTION TO PC TECHNOLOGY':
       lis2.append( 966)
    elif request.GET['titlen'] ==                                                      'METR 101 WEATHER AND CLIMATE':
       lis2.append(2077)
    elif request.GET['titlen'] ==                                                      'ETHIC MINORITIES':
       lis2.append(1103)
    elif request.GET['titlen'] ==                                                      'REAL ESTATE APPRAISAL - SERIES':
       lis2.append(2524)
    elif request.GET['titlen'] ==                                                      'ORGANIZATIONAL THEORY AND DESIGN':
       lis2.append(2250)
    elif request.GET['titlen'] ==                                                       'INTRODUCTION TO GRADUATE RESEARCH':
       lis2.append(1758)
    elif request.GET['titlen'] ==                                                       'FIRE INSPECTOR I':
       lis2.append(1202)
    elif request.GET['titlen'] == 'TABLEAU 1':
       lis2.append(2764)
    elif request.GET['titlen'] ==                                                        'CERTIFIED NURSING ASSISTANCE':
       lis2.append( 504)
    elif request.GET['titlen'] ==                                                        'CGD/318 PUBLIC RELATIONS & POROMOTIONAL WRITING':
       lis2.append( 516)
    elif request.GET['titlen'] ==                                                        'FIRE & EXPLOSION: INVESTIGATION & RECONSTRUCTION':
       lis2.append(1193)
    elif request.GET['titlen'] ==                                                         'INTERCULTURAL COMMUNICATION & LEADERSHIP':
       lis2.append(1651)
    elif request.GET['titlen'] ==                                                       'ETHICAL BEHAVIOR IN CRIMINAL JUSTICE':
       lis2.append(1105)
    elif request.GET['titlen'] ==                                                        'JUVENILE DELINQUENCY':
       lis2.append(1865)
    elif request.GET['titlen'] ==                                                        'FINANCIAL ACCOUNTING':
       lis2.append(1179)
    elif request.GET['titlen'] ==                                                         'FUNDAMENTALS OF ENVIRONMENTAL SYSTEMS':
       lis2.append(1292)
    elif request.GET['titlen'] ==                                                         'WEB DESIGN CERTIFICATE':
       lis2.append(2874)
    elif request.GET['titlen'] ==                                                          'HSMN625 - CRITICAL INFRASTRUCTURES':
       lis2.append(1534)
    elif request.GET['titlen'] ==                                                          'ENVIRONMENTAL CHANGE AND SUSTAINABILITY':
       lis2.append(1087)
    elif request.GET['titlen'] ==                                                          'PSYCHOLOGY AND SOCIOLOGY OF DISASTERS':
       lis2.append(2454)
    elif request.GET['titlen'] ==                                                           'TORTS':
       lis2.append(2825)
    elif request.GET['titlen'] ==                                                            'HSMN640 - ENERGY INFRASTRUCTURE SECURITY':
       lis2.append(1535)
    elif request.GET['titlen'] ==                                                            '2013 ANNUAL ADR CONFERENCE':
       lis2.append(11)
    elif request.GET['titlen'] ==                                                             'CERTIFIED NURSING  ASSISTANCE':
       lis2.append( 503)
    elif request.GET['titlen'] ==                                                         'ACCOUNTING FOR MANAGERS':
       lis2.append(65)
    elif request.GET['titlen'] ==                                                         'PHILOSOPHY':
       lis2.append(2322)
    elif request.GET['titlen'] ==                                                          'BIO 205 - GENERAL MICROBIOLOGY':
       lis2.append( 326)
    elif request.GET['titlen'] ==                                                          'ENG 112 - COLLEGE COMPOSITION II':
       lis2.append(1044)
    elif request.GET['titlen'] ==                                                           'INDUSTRIAL FIRE SAFETY':
       lis2.append(1615)
    elif request.GET['titlen'] ==                                                            'PERFORMANCE BASED DESIGN':
       lis2.append(2291)
    elif request.GET['titlen'] ==                                                             'POLITICAL AND POLICY ISSUES IN EMERGENCY MANAGEMENT':
       lis2.append(2345)
    elif request.GET['titlen'] ==                                                             'EMERGENCY RESPONSE AND PREPAREDNESS':
       lis2.append(1006)
    elif request.GET['titlen'] ==                                                              'BUSINESS & PRFOESSIONAL SPEECH COMUNICATION':
       lis2.append( 413)
    elif request.GET['titlen'] ==                                                               'INTERMEDIATE ALGEBRA':
       lis2.append(1659)
    elif request.GET['titlen'] ==                                                               'INTERNATIONAL PUBLIC MANAGEMENT ASSOCIATION FOR HUMAN RESOURCES CERTIFICATION':
       lis2.append(1675)
    elif request.GET['titlen'] ==                                                            '15-HOUR NATIONAL USAP COURSE':
       lis2.append(5)
    elif request.GET['titlen'] ==                                                             'HUMAN RESOURCE MANAGEMENT':
       lis2.append(1559)
    elif request.GET['titlen'] ==                                                              'MODERN SPANISH CULTURE':
       lis2.append(2128)
    elif request.GET['titlen'] ==                                                              'INDEPENDENT RESEARCH IN CRIMINAL JUSTICE CCJS399':
       lis2.append(1612)
    elif request.GET['titlen'] ==                                                               'CCJS452 CORRECTIONS':
       lis2.append( 481)
    elif request.GET['titlen'] ==                                                                'PUBLIC HEALTH BIOLOGY':
       lis2.append(2487)
    elif request.GET['titlen'] ==                                                                'HEAT & MASS TRANSFER PROCESS':
       lis2.append(1424)
    elif request.GET['titlen'] ==                                                                 'BASIC RIDER I':
       lis2.append( 295)
    elif request.GET['titlen'] ==                                                                  'FOR508 - ADVANCED COMPUTER FORENSIC ANALYSIS AND INCIDENT RESPONSE':
       lis2.append(1229)
    elif request.GET['titlen'] ==                                                                   'FOR408 - COMPUTER FORENSIC INVESTIGATIONS - WINDOWS IN-DEPTH':
       lis2.append(1228)
    elif request.GET['titlen'] ==                                                                   'ISSUES AND PRACTICES IN HUMAN RESOURCE MANAGEMENT':
       lis2.append(1823)
    elif request.GET['titlen'] ==                                                               'BASIC APPRAISAL PROCEDURES':
       lis2.append( 287)
    elif request.GET['titlen'] ==                                                                'BASIC APPAISAL PRINCIPLES':
       lis2.append( 286)
    elif request.GET['titlen'] ==                                                                'MEDAITION':
       lis2.append(2059)
    elif request.GET['titlen'] ==                                                                'AR-15/M16 ARMORER':
       lis2.append( 240)
    elif request.GET['titlen'] ==                                                                 'PRINCIPLE HEALTH LIVING':
       lis2.append(2369)
    elif request.GET['titlen'] ==                                                                 'MATHEMATICAL IDEAS':
       lis2.append(2044)
    elif request.GET['titlen'] ==                                                                 'FIRE INSPECTOR 1':
       lis2.append(1201)
    elif request.GET['titlen'] ==                                                                 'FINANCIAL ACCOUNTING AND REPORTING, CPA REVIEW':
       lis2.append(1180)
    elif request.GET['titlen'] ==                                                                  'HS5423 - PHILOSOPHY OF SOCIAL WORK':
       lis2.append(1522)
    elif request.GET['titlen'] ==                                                                  'FOUNDATIONS':
       lis2.append(1247)
    elif request.GET['titlen'] ==                                                                   'BUSINESS LAW II':
       lis2.append( 432)
    elif request.GET['titlen'] ==                                                                   'PRINCIPLES OF SUPERVISION':
       lis2.append(2391)
    elif request.GET['titlen'] ==                                                                    "GLOCK PROFESSIONAL, INC. ARMORER'S COURSE":
       lis2.append(1366)
    elif request.GET['titlen'] ==                                                                  'HRER 504: SEMINAR IN EMPLOYMENT RELATIONS':
       lis2.append(1502)
    elif request.GET['titlen'] ==                                                                  'ELEMENTARY SPANISH I':
       lis2.append( 981)
    elif request.GET['titlen'] ==                                                                   'HRER 800: INTERNATIONAL AND COMPARATIVE EMPLOYMENT RELATIONS':
       lis2.append(1503)
    elif request.GET['titlen'] ==                                                                   'WEB DESIGN CERTIFICATE (CONTINUE WITH 3 MORE CLASSES)':
       lis2.append(2875)
    elif request.GET['titlen'] ==                                                                   'ADVANCED WEB DESIGN CERTIFICATE (7 NEW CLASSES FOR THE ADVANCED LEVEL)':
       lis2.append( 158)
    elif request.GET['titlen'] ==                                                                   'ECONOMICS II':
       lis2.append( 927)
    elif request.GET['titlen'] ==                                                                   'EMAN  600 - 9040   COMPREHENSIVE CRISIS AND EMERGENCY MANAGEMENT':
       lis2.append( 994)
    elif request.GET['titlen'] ==                                                                   'MGMT  610 - 9022   ORGANIZATIONAL THEORY':
       lis2.append(2079)
    elif request.GET['titlen'] ==                                                                   'INTRO TO HUMAN COMMUNICATION':
       lis2.append(1706)
    elif request.GET['titlen'] ==                                                                    'MARKETING MANAGEMENT':
       lis2.append(1999)
    elif request.GET['titlen'] ==                                                                    'ACCOUTING FOR NONACCOUNTING MANAGERS':
       lis2.append(71)
    elif request.GET['titlen'] ==                                                                    'LAW AND PUBLIC POLICY':
       lis2.append(1886)
    elif request.GET['titlen'] ==                                                                    'PUBLIC ADMINISTRATION IN SOCIETY':
       lis2.append(2481)
    elif request.GET['titlen'] ==                                                                     'PROFESSIONAL HUMAN RESOURCE MANAGEMENT CERTIFICATION':
       lis2.append(2402)
    elif request.GET['titlen'] ==                                                                      'ALGEBRA & TRIGONOMETRY':
       lis2.append( 185)
    elif request.GET['titlen'] ==                                                                       'FEDERAL INCOME TAX II-AC214':
       lis2.append(1156)
    elif request.GET['titlen'] ==                                                                       'PHA 6935 FORENSIC ANRHROPOLGY 1':
       lis2.append(2312)
    elif request.GET['titlen'] ==                                                                        'ADVANCED SKILLS RESCUE WORKSHOP':
       lis2.append( 150)
    elif request.GET['titlen'] ==                                                                         'PST 212 - SURVEY OF DEAF CULTURE IN THE UNITED STATES':
       lis2.append(2434)
    elif request.GET['titlen'] ==                                                                          'PERFORMANCE MANAGEMENT (AMA022)':
       lis2.append(2292)
    elif request.GET['titlen'] =='ED/PS208-ONL-1':
       lis2.append( 932)
    elif request.GET['titlen'] ==                                                                     'SYSTEM ANALYSIS AND DESIGN':
       lis2.append(2760)
    elif request.GET['titlen'] ==                                                                      'MEDICAL ORGANIC CHEMISRTY I':
       lis2.append(2063)
    elif request.GET['titlen'] ==                                                                       'SUCCESSFUL PROJECT MANAGEMENT':
       lis2.append(2739)
    elif request.GET['titlen'] ==                                                                       'A PRACTICAL APPROACH TO PROJECT MANAGEMENT':
       lis2.append(35)
    elif request.GET['titlen'] ==                                                                       'MATHEMATICS  MATH 101':
       lis2.append(2046)
    elif request.GET['titlen'] ==                                                                        'PSYCHOLOGY 101':
       lis2.append(2452)
    elif request.GET['titlen'] ==                                                                        'SOCIOLOGY OF RELIGION':
       lis2.append(2658)
    elif request.GET['titlen'] ==                                                                         'PRINCIPLES OF BIOLOGY 107':
       lis2.append(2379)
    elif request.GET['titlen'] ==                                                                          'GENERAL PSYCHOLOGY':
       lis2.append(1322)
    elif request.GET['titlen'] ==                                                                          'MGMT 562- FINANCIAL & MANAGERIAL ACCOUNTING':
       lis2.append(2086)
    elif request.GET['titlen'] ==                                                                           'LONG-TERM CARE ADMINSTRATION':
       lis2.append(1959)
    elif request.GET['titlen'] ==                                                                            'PUBLIC HEALTH ADMINISTRATION':
       lis2.append(2485)
    elif request.GET['titlen'] ==                                                                            'SOCIAL WORK W/ADDICTIVE BEHAVIORS':
       lis2.append(2651)
    elif request.GET['titlen'] ==                                                                        'INTERNAL INVESTIGATION NOTE-TAKING AND REPORTS':
       lis2.append(1672)
    elif request.GET['titlen'] ==                                                                        'LABOR LAW AND LABOR ARBITRATION COFERENCE':
       lis2.append(1876)
    elif request.GET['titlen'] ==                                                                         'PROFESSIONAL BOOKKEEPING':
       lis2.append(2400)
    elif request.GET['titlen'] ==                                                                          'MACRO ECONOMICS':
       lis2.append(1973)
    elif request.GET['titlen'] == 'PRINC MANAGEMENT':
       lis2.append(2366)
    elif request.GET['titlen'] ==                                                                           'HIS 101 - HISTORY OF WESTERN CIVILIZATION I':
       lis2.append(1433)
    elif request.GET['titlen'] ==                                                                            'HUMAN COMMUNICATIONS':
       lis2.append(1550)
    elif request.GET['titlen'] =='GLOBAL GEOGRAPHY 110':
       lis2.append(1347)
    elif request.GET['titlen'] ==                                                                            'DIFFERENTIAL EQUATIONS':
       lis2.append( 878)
    elif request.GET['titlen'] ==                                                                            'ENGINEERING STATICS':
       lis2.append(1047)
    elif request.GET['titlen'] ==                                                                            'CHEMISTRY':
       lis2.append( 529)
    elif request.GET['titlen'] ==                                                                            'NETWORK ENGINEER ALL ACCESS TRAINING':
       lis2.append(2163)
    elif request.GET['titlen'] ==                                                                            'ETHICAL LEADERSHIP IN ORGANIZATIONS & SOCIETY':
       lis2.append(1107)
    elif request.GET['titlen'] ==                                                                          'SOCIAL WORK PRACTICE WITH INDIVIDUALS':
       lis2.append(2649)
    elif request.GET['titlen'] ==                                                                          'SOCIAL WORK PRACTICE WITH COMMUNITIES & ORGANIZATIONS':
       lis2.append(2648)
    elif request.GET['titlen'] ==                                                                          'ENGLISH 113':
       lis2.append(1063)
    elif request.GET['titlen'] ==                                                                           'MATHEMATICS PREP':
       lis2.append(2048)
    elif request.GET['titlen'] ==                                                                           'HVAC ELECTRICITY - BU 172':
       lis2.append(1576)
    elif request.GET['titlen'] ==                                                                            'ELEMENTS OF STATISTICS - MA 116 - 420':
       lis2.append( 988)
    elif request.GET['titlen'] ==                                                                             'CRIT READ/WRITE/RESEARCH - EN 102 - 440':
       lis2.append( 804)
    elif request.GET['titlen'] ==                                                                             'PRINC MANAGEMENT - MG 101 - 3RA':
       lis2.append(2367)
    elif request.GET['titlen'] ==                                                                             'INTRODUCTION TO NUTRITION - NF 103 - 410':
       lis2.append(1776)
    elif request.GET['titlen'] ==                                                                             'REL 246 - CHRISTIANITY':
       lis2.append(2540)
    elif request.GET['titlen'] ==                                                                             'HR METRICS AND WORKFORCE ANALYTICS':
       lis2.append(1501)
    elif request.GET['titlen'] ==                                                                            'SURVEY OF AMERICAN MILITARY HISTORY':
       lis2.append(2745)
    elif request.GET['titlen'] ==                                                                             'HISTORY OF PEACEKEEPING: 1988-PRESENT':
       lis2.append(1461)
    elif request.GET['titlen'] ==                                                                             'CENTRAL ASIAN POLITICS IN ANTHROPOLOGICAL PERSPECTIVE':
       lis2.append( 494)
    elif request.GET['titlen'] ==                                                                              'ES 220- MECAHNICS OF MATERIALS':
       lis2.append(1098)
    elif request.GET['titlen'] ==                                                                              'PH 161- GENERAL PHYSICS I':
       lis2.append(2308)
    elif request.GET['titlen'] ==                                                                              'BIOLOGY - PLANT BIOLOGY BTNY 1203':
       lis2.append( 335)
    elif request.GET['titlen'] ==                                                                               'SOCIOLOGY-SOCIAL PROBLEMS SOC 1020':
       lis2.append(2659)
    elif request.GET['titlen'] ==                                                                               'CHEMISTRY-INTRODUCTORY CHEMISTRY CHEM 1010':
       lis2.append( 531)
    elif request.GET['titlen'] ==                                                                                'ART  HISTORY':
       lis2.append( 252)
    elif request.GET['titlen'] ==                                                                                'BMGT422 AUDITING THEORY AND PRACTICE':
        lis2.append( 374)
    elif request.GET['titlen'] ==                                                                                'STATISTICS 200':
        lis2.append(2714)
    elif request.GET['titlen'] ==                                                                             'SPEECH 108':
        lis2.append(2697)
    elif request.GET['titlen'] ==                                                                              'AMERICAN POPULAR MUSIC':
        lis2.append( 206)
    elif request.GET['titlen'] ==                                                                               'EDD 8102 LEADERSHIP PRACTICUM':
        lis2.append( 940)
    elif request.GET['titlen'] ==                                                                                'PERSONAL AND COMMUNITY HEALTH':
        lis2.append(2293)
    elif request.GET['titlen'] ==                                                                                'USING DATA ANALYSTICS TO DETECT FRAUD':
        lis2.append(2850)
    elif request.GET['titlen'] ==                                                                                'THE PRINCETON REVIEW - GRE PREP COURSE':
        lis2.append(2798)
    elif request.GET['titlen'] ==                                                                                'AT 111 ENGINE REPAIR':
        lis2.append( 275)
    elif request.GET['titlen'] ==                                                                                'PRIMARY CARE OF WOMEN':
        lis2.append(2364)
    elif request.GET['titlen'] ==                                                                                'THE MANAGER IN ORGANIZATIONS AND SOCIETY':
        lis2.append(2795)
    elif request.GET['titlen'] ==                                                                                'MATH 091, BEGINNING ALGEBRA SYLLABUS':
        lis2.append(2026)
    elif request.GET['titlen'] ==                                                                                'TRANSNATIONAL ORGANIZED CRIME':
        lis2.append(2830)
    elif request.GET['titlen'] ==                                                                                'LEGAL ETHICS':
        lis2.append(1932)
    elif request.GET['titlen'] ==                                                                                'INTRODUCTION TO HUMAN COMMUNICATION':
        lis2.append(1765)
    elif request.GET['titlen'] ==                                                                                'BMGT 317 DECISION MAKING':
        lis2.append( 358)
    elif request.GET['titlen'] ==                                                                                 'NURSING - PEDIATRICS / CONCEPTS 2':
        lis2.append(2189)
    elif request.GET['titlen'] ==                                                                                  'ENGLISH 104 - REPORT & TECHNICAL WRITING':
        lis2.append(1060)
    elif request.GET['titlen'] ==                                                                                  'MANAGEMENT 230':
        lis2.append(1976)
    elif request.GET['titlen'] ==                                                                                  'HOW TO EVALUATE  AND PROCESS BIDS':
        lis2.append(1498)
    elif request.GET['titlen'] ==                                                                                'SPECIFICATION WRITING':
        lis2.append(2694)
    elif request.GET['titlen'] ==                                                                                'SPANISH I':
        lis2.append(2686)
    elif request.GET['titlen'] ==                                                                                'SUPPLY CHAIN PROFESSIONAL':
        lis2.append(2743)
    elif request.GET['titlen'] ==                                                                                'NEGOTIATING SKILLS - INFLUENCE AND PERSUASION':
        lis2.append(2158)
    elif request.GET['titlen'] ==                                                                                'PUBLIC SAFETY ISSUES':
        lis2.append(2502)
    elif request.GET['titlen'] ==                                                                                'CPPB PREP COURSE':
        lis2.append( 761)
    elif request.GET['titlen'] ==                                                                                'SPIRITUAL FORMATION  DSMN 520':
        lis2.append(2700)
    elif request.GET['titlen'] ==                                                                                'TEAM SKILLS RESCUE WORKSHOP':
        lis2.append(2773)
    elif request.GET['titlen'] ==                                                                                'ENGLISH COMPOSITION I: EXPOSITORY WRITING':
        lis2.append(1076)
    elif request.GET['titlen'] ==                                                                                'ADVANCED ROPE RESCUE':
        lis2.append( 149)
    elif request.GET['titlen'] ==                                                                                 'ADVANCED WRITING FOR ACADEMIC & PROFESSIONAL SUCCESS (ELI-062-001)':
        lis2.append( 159)
    elif request.GET['titlen'] ==                                                                                'ENGLISH COMMUNICATION AND PUBLIC SPEAKING FOR POREFESSIONAL AND ACADEMIC SUCCESS (ELI-061-002)':
        lis2.append(1073)
    elif request.GET['titlen'] ==                                                                                'SOCIAL WELFARE/SOCIAL  POLICY':
        lis2.append(2640)
    elif request.GET['titlen'] ==                                                                                'ANATOMY AND PHYSIOLOGY LAB':
        lis2.append( 218)
    elif request.GET['titlen'] ==                                                                                'LAW 519-R TORTS I':
        lis2.append(1884)
    elif request.GET['titlen'] ==                                                                                'STRATEGIC PLANNING FOR DATABASE SYSTEMS':
        lis2.append(2727)
    elif request.GET['titlen'] ==                                                                                'HRMN 362 83980':
        lis2.append(1517)
    elif request.GET['titlen'] ==                                                                                 'SPCH 100':
        lis2.append(2691)
    elif request.GET['titlen'] ==                                                                                 'CONCEPTS AND APPLICATIONS OF INFORMATION TECHNOLOGY (IFSM 201)':
        lis2.append( 699)
    elif request.GET['titlen'] ==                                                                                  'INFORMATION SYSTEMS IN ORGANIZATIONS (IFSM 300)':
        lis2.append(1634)
    elif request.GET['titlen'] ==                                                                                 'FIRE INSTRUCTOR 1':
        lis2.append(1205)
    elif request.GET['titlen'] ==                                                                                 'FIRE OFFICER I':
        lis2.append(1211)
    elif request.GET['titlen'] ==                                                                                 'GLOBALIZATION IN AFRICA - AFST 234 - 01':
        lis2.append(1356)
    elif request.GET['titlen'] ==                                                                                 'INTERNAL AUDIT BASICS - ONLINE':
        lis2.append(1670)
    elif request.GET['titlen'] ==                                                                                 'INTERNAL AUDIT PRACTICE - ONLINE':
        lis2.append(1671)
    elif request.GET['titlen'] ==                                                                                 'RESEARCH METHOD':
        lis2.append(2554)
    elif request.GET['titlen'] ==                                                                                  'LEARNING STRATEGIES FOR SUCCESS':
        lis2.append(1922)
    elif request.GET['titlen'] ==                                                                                  'ACCT 612 AUDITING':
        lis2.append(80)
    elif request.GET['titlen'] ==                                                                                  'ISAS 610 INFORMATION SYSTEMS MANAGEMENT AND INTEGRATION':
        lis2.append(1816)
    elif request.GET['titlen'] ==                                                                                  'FIRE ASSESSMENT METHODS':
        lis2.append(1198)
    elif request.GET['titlen'] ==                                                                                  'CMRJ512 POLICE ADMINISTRATION':
        lis2.append( 611)
    elif request.GET['titlen'] ==                                                                                 'CRITICAL READING/WRITING/RESEARCH AT WORK':
        lis2.append( 807)
    elif request.GET['titlen'] ==                                                                                 'ELECTRICIAL TROUBLESHOOTING':
        lis2.append( 968)
    elif request.GET['titlen'] ==                                                                                  'CONTINUITY OF OPERATIONS PLANNING AND IMPLEMENTATION':
        lis2.append( 720)
    elif request.GET['titlen'] ==                                                                                  'TERRORISM ISSUES IN EMERGENCY MANAGEMENT':
        lis2.append(2782)
    elif request.GET['titlen'] ==                                                                                   'FIRE PROTECTION STRUCTURE AND SYSTEMS':
        lis2.append(1220)
    elif request.GET['titlen'] ==                                                                                    'ECONOMICS IN THE INFORMATION AGE':
        lis2.append( 928)
    elif request.GET['titlen'] ==                                                                                    'MEDICAL TERMINOLOGY':
        lis2.append(2064)
    elif request.GET['titlen'] ==                                                                                    'CLINICAL PRACTICUM':
        lis2.append( 578)
    elif request.GET['titlen'] ==                                                                                     'NEGOTITATION AND CONFLICT RESOLUTION':
        lis2.append(2161)
    elif request.GET['titlen'] ==                                                                                  'ESSENTIALS OF PROJECT MANAGEMENT':
        lis2.append(1101)
    elif request.GET['titlen'] ==                                                                                  'HISTORY364-AMERICA 1900-1945':
        lis2.append(1472)
    elif request.GET['titlen'] ==                                                                                   'HIST 336 EUROPE IN THE 19TH CENTURY: 1815 TO 1919 (3)':
        lis2.append(1443)
    elif request.GET['titlen'] ==                                                                                   'INTRODUCTION TO FORENSIC SCIENCE':
        lis2.append(1749)
    elif request.GET['titlen'] ==                                                                                   "HIST 337 EUROPE'S BLOODIEST CENTURY (3)":
        lis2.append(1444)
    elif request.GET['titlen'] ==                                                                                   'INTRO TO BUILDING TRADES - BU 130':
        lis2.append(1694)
    elif request.GET['titlen'] ==                                                                                   'FUNDAMENTAL OF CARPENTRY - BU 140':
        lis2.append(1284)
    elif request.GET['titlen'] ==                                                                                   'ARCGIS FOR CRIME & INTELLIGENCE ANALYSTS':
        lis2.append( 247)
    elif request.GET['titlen'] ==                                                                                   'AMERICAN GOVERNMENT':
        lis2.append( 198)
    elif request.GET['titlen'] ==                                                                                   'PHARMACOLOGY':
        lis2.append(2315)
    elif request.GET['titlen'] ==                                                                                    'AIRCRAFT RESCUE FIRE FIGHTER':
        lis2.append( 177)
    elif request.GET['titlen'] ==                                                                                    'EQUIVALENT STRUCTURAL COLLAPSE TECHNICIAN COURSE':
        lis2.append(1097)
    elif request.GET['titlen'] ==                                                                                    'PRINCIPLES OF MANAGEMENT':
        lis2.append(2387)
    elif request.GET['titlen'] ==                                                                                     'ENGLISH WRITING':
        lis2.append(1079)
    elif request.GET['titlen'] ==                                                                                      'MGMT 650 RESEARCH METHODS FOR MANAGERS':
        lis2.append(2100)
    elif request.GET['titlen'] ==                                                                                      'JAVASCRIPT FUNDAMENTALS':
        lis2.append(1854)
    elif request.GET['titlen'] ==                                                                                      'VISUAL PROGRAMMING':
        lis2.append(2860)
    elif request.GET['titlen'] ==                                                                                      'UNIX/LINUX OPERATING SYSTEM':
        lis2.append(2846)
    elif request.GET['titlen'] ==                                                                                      'CRIMINAL JUSTICE ADMINISTRATION':
        lis2.append( 783)
    elif request.GET['titlen'] ==                                                                                      'ADVANCE TREATMENT FAMILY SYSTEMS':
        lis2.append( 107)
    elif request.GET['titlen'] ==                                                                                       'NW 151 INTRODUCTION TO NETWORKING':
        lis2.append(2218)
    elif request.GET['titlen'] ==                                                                                      'MATH 107, COLLEGE ALGEBRA ':
        lis2.append(2031)
    elif request.GET['titlen'] ==                                                                                      'UNDERSTANDING MOVIES':
        lis2.append(2843)
    elif request.GET['titlen'] ==                                                                                      'RESEARCH METHODS':
        lis2.append(2556)
    elif request.GET['titlen'] ==                                                                                       'PARENTING TODAY':
        lis2.append(2268)
    elif request.GET['titlen'] ==                                                                                        'WATER BASED FIRE PROTECTION SYSTEMS':
        lis2.append(2863)
    elif request.GET['titlen'] ==                                                                                        'ADVANCE LIFE SAFETY ANALYSIS':
        lis2.append( 104)
    elif request.GET['titlen'] ==                                                                                        'DESIGNING WEBSITES FOR MOBILE DEVICES: HANDS-ON':
        lis2.append( 870)
    elif request.GET['titlen'] ==                                                                                        'FOUNDATIONS OF INFORMATION SYSTEM SECURITY':
        lis2.append(1255)
    elif request.GET['titlen'] ==                                                                                        'EVALUATING EMERGING TECHNOLOGIES':
        lis2.append(1124)
    elif request.GET['titlen'] ==                                                                                         'SECURITY POLICY ANALYSIS':
        lis2.append(2597)
    elif request.GET['titlen'] ==                                                                                        'CHANGE MANAGEMENT CERTIFICATE':
        lis2.append( 517)
    elif request.GET['titlen'] ==                                                                                         'MSSQL SERVER FOR DEVELOPERS 1':
        lis2.append(2143)
    elif request.GET['titlen'] ==                                                                                         'FUNDEMENTALS OF CHEMISTRY':
        lis2.append(1305)
    elif request.GET['titlen'] ==                                                                                         'HTML5;DESKTOP AND MOBILE LEVEL 1':
        lis2.append(1536)
    elif request.GET['titlen'] ==                                                                                         'MSSQL SERVER FOR DEVELOPERS II':
        lis2.append(2144)
    elif request.GET['titlen'] ==                                                                                          'SIOCIAL MEDIA NETWORKING  - CREATE AND EFFECTIVELY MANAGE A FACEBOOK SITE':
        lis2.append(2618)
    elif request.GET['titlen'] ==                                                                                          'COMPUTER PUBLISHING - INTRODUCTION TO PHOTOSHOP':
        lis2.append( 687)
    elif request.GET['titlen'] ==                                                                                          'GENERAL SUPERVISION FOR NEW SUPERVISORS':
        lis2.append(1327)
    elif request.GET['titlen'] ==                                                                                          'C++ PROGRAMMING':
        lis2.append( 446)
    elif request.GET['titlen'] ==                                                                                           'EMERGENCY HEALTH SERVICES EDUCATIONAL PROGRAM MANAGEMENT':
        lis2.append(1000)
    elif request.GET['titlen'] ==                                                                                         'INTRODUCTION TO DIGITIAL ARTS':
        lis2.append(1742)
    elif request.GET['titlen'] ==                                                                                         'SEMINAR IN SECURITY MANAGEMENT':
        lis2.append(2602)
    elif request.GET['titlen'] ==                                                                                         'HOW TO WRITE EFFECTIVE POLICIES AND PROCEDURES':
        lis2.append(1499)
    elif request.GET['titlen'] ==                                                                                         'INTRODUCTION TO SOCIAL ETHICS':
        lis2.append(1793)
    elif request.GET['titlen'] ==                                                                                         'INTRODUCTION TO FILM':
        lis2.append(1747)
    elif request.GET['titlen'] ==                                                                                         'INFORMATION  SYSTEMS IN ORGS':
        lis2.append(1624)
    elif request.GET['titlen'] ==                                                                                         'THE EFFECTS OF DRUGS ON HUMAN PERFORMANCE AND BEHAVIOR':
        lis2.append(2787)
    elif request.GET['titlen'] ==                                                                                         'CJUS 200':
        lis2.append( 565)
    elif request.GET['titlen'] ==                                                                                         'ADVANCED FIRE ADMINISTRATION':
        lis2.append( 130)
    elif request.GET['titlen'] ==                                                                                          'EMPLOYEE AND LABOR RELATIONS':
        lis2.append(1021)
    elif request.GET['titlen'] ==                                                                                          'INTRODUCTION TO ARTIFICIAL INTELLIGENCE':
        lis2.append(1729)
    elif request.GET['titlen'] ==                                                                                          'ENGIEERING PROBABILITY':
        lis2.append(1045)
    elif request.GET['titlen'] ==                                                                                           'DIGITAL SIGNAL PROCESSING':
        lis2.append( 885)
    elif request.GET['titlen'] ==                                                                                           'DIGITIAL COMPUTER DESIGN':
        lis2.append( 887)
    elif request.GET['titlen'] ==                                                                                           'SOWK: 622 LOSSES AND GRIEF':
        lis2.append(2675)
    elif request.GET['titlen'] ==                                                                                           'SOWK: 650 HLTH. PROMO & DISEASE':
        lis2.append(2676)
    elif request.GET['titlen'] ==                                                                                            'BIOLOGICAL ASPECTS OF AGING':
        lis2.append( 333)
    elif request.GET['titlen'] ==                                                                                            'DEATH, GRIEF, AND END OF LIFE PLANNING':
        lis2.append( 860)
    elif request.GET['titlen'] ==                                                                                             'YOGA, THERAPY,SPIRITUALTY, AND AGING':
        lis2.append(2922)
    elif request.GET['titlen'] ==                                                                                              'AGING, IDENTIFY, AND MORAL IMAGINATION (THE VIEW FROM HERE)':
        lis2.append( 166)
    elif request.GET['titlen'] ==                                                                                            'INTRODUCTION TO SECURITY MANAGEMENT':
        lis2.append(1792)
    elif request.GET['titlen'] ==                                                                                            'PRINCIPLES OF MARKETING':
        lis2.append(2389)
    elif request.GET['titlen'] ==                                                                                            'BUSINESS POLICY':
        lis2.append( 439)
    elif request.GET['titlen'] ==                                                                                             'JHU 3RD ANNUAL PLAY THERAPY INSTITUTE: PLAY THERAPY FOLLOWING TRAUMATIC VIOLENCE':
        lis2.append(1855)
    elif request.GET['titlen'] ==                                                                                              'FIN 331 BUSINESS FINANCE':
        lis2.append(1177)
    elif request.GET['titlen'] ==                                                                                               'FUNDEMENTAL OF CHEMISTRY LAB':
        lis2.append(1304)
    elif request.GET['titlen'] ==                                                                                               'AFRICAN AMERICAN LITERATURE':
        lis2.append( 162)
    elif request.GET['titlen'] ==                                                                                                'DVERSITY AND CULTURAL FACTORS IN PSYCHOLOGY':
        lis2.append( 908)
    elif request.GET['titlen'] ==                                                                                             'ENVIRONMENTSL PSYCHOLOGY':
        lis2.append(1092)
    elif request.GET['titlen'] ==                                                                                             'CRIMINAL JUSTICE 304 - SECURITY ADMINISTRATION':
        lis2.append( 782)
    elif request.GET['titlen'] ==                                                                                             'HUMANITIES - HUMN 100':
        lis2.append(1572)
    elif request.GET['titlen'] ==                                                                                             'WRTG 101 WRITING GEN ED':
        lis2.append(2911)
    elif request.GET['titlen'] ==                                                                                             'FIRE AND EMERGENCY SERVICE ADMINISTRATION':
        lis2.append(1196)
    elif request.GET['titlen'] ==                                                                                              'FRANCO ANGELINI DECOY SCHOOL':
        lis2.append(1259)
    elif request.GET['titlen'] ==                                                                                               'SWIFT WATER RESCUE TECHNICIAN ':
        lis2.append(2758)
    elif request.GET['titlen'] ==                                                                                               'DECOY SCHOOL':
        lis2.append( 862)
    elif request.GET['titlen'] ==                                                                                               'ORGANIZATIONAL DEVELOPMENT':
        lis2.append(2242)
    elif request.GET['titlen'] ==                                                                                               'LEGAL AND ETHICAL ENVIRONMENT OF PUBLIC ADMINISTRATION':
        lis2.append(1923)
    elif request.GET['titlen'] ==                                                                                               'INTRO TO COLLEGE WRITING':
        lis2.append(1696)
    elif request.GET['titlen'] ==                                                                                             'ED861.609 DIAGNOSIS IN COUNSELING':
        lis2.append( 933)
    elif request.GET['titlen'] ==                                                                                             'MGMT 551- MANAGEMENT THEORY':
        lis2.append(2083)
    elif request.GET['titlen'] ==                                                                                              'NUTRITION / FITNESS & WELLNESS':
        lis2.append(2212)
    elif request.GET['titlen'] ==                                                                                               'FOUNDATION OF GENERAL EDUCATION AND PROFESSIONAL SUCCESS':
        lis2.append(1245)
    elif request.GET['titlen'] ==                                                                                                'COLLEGE MATHEMATICS':
        lis2.append( 643)
    elif request.GET['titlen'] ==                                                                                                'SPANISH':
        lis2.append(2680)
    elif request.GET['titlen'] ==                                                                                                'APOLOGETICS 104':
        lis2.append( 230)
    elif request.GET['titlen'] ==                                                                                                 'BIOLOGY':
        lis2.append( 334)
    elif request.GET['titlen'] ==                                                                                                  'BIOLOGY LAB':
        lis2.append( 344)
    elif request.GET['titlen'] ==                                                                                                   "GLOCK ARMORER'S COURSE":
        lis2.append(1362)
    elif request.GET['titlen'] ==                                                                                                    'EN002':
        lis2.append(1033)
    elif request.GET['titlen'] ==                                                                                                     'INTRODUCTORY ALGEBRA':
        lis2.append(1806)
    elif request.GET['titlen'] ==                                                                                                     'CJ 602: CRIMINOLOGY':
        lis2.append( 553)
    elif request.GET['titlen'] ==                                                                                               'INTRO TO SOCIOCULTURAL ANTHRO':
        lis2.append(1715)
    elif request.GET['titlen'] ==                                                                                               'HUMAN ANAT & PHYS I BI':
        lis2.append(1541)
    elif request.GET['titlen'] ==                                                                                                'ELEMENTS OF STATISTICS':
        lis2.append( 987)
    elif request.GET['titlen'] ==                                                                                                 'CRIT READ/ WRITE/ RESEARCH':
        lis2.append( 803)
    elif request.GET['titlen'] ==                                                                                                 'PRINCIPLES OF EPIDEMIOLOGY':
        lis2.append(2385)
    elif request.GET['titlen'] ==                                                                                                  'SPAN111 - ELEMENTARY SPANISH I':
        lis2.append(2679)
    elif request.GET['titlen'] ==                                                                                                   'INTRODUCTION TO SOCIAL MEDIA':
        lis2.append(1794)
    elif request.GET['titlen'] ==                                                                                                    'CCJS432 - LAW OF CORRECTIONS':
        lis2.append( 480)
    elif request.GET['titlen'] ==                                                                                                     'PSYCHOLOGY 100- INTRODUCTION TO PSYCHOLOGY':
        lis2.append(2451)
    elif request.GET['titlen'] ==                                                                                                      'SPANISH CONVERSATION AND GRAMMAR':
        lis2.append(2685)
    elif request.GET['titlen'] ==                                                                                                      'LACTATION COUNSELOR TRAINING COURSE':
        lis2.append(1881)
    elif request.GET['titlen'] ==                                                                                                   'HUMAN ANATOMY AND PHYSIOLOGY':
        lis2.append(1543)
    elif request.GET['titlen'] ==                                                                                                    'U.S.GOVERN AND POLITICS':
        lis2.append(2839)
    elif request.GET['titlen'] ==                                                                                                     'ACCT 220- PRINCIPLES OF ACCOUNTING':
        lis2.append(74)
    elif request.GET['titlen'] ==                                                                                                    'IFSM 201- CONCEPTS AND APPLICATIONS OF INFORMATION TECHNOLOGY':
        lis2.append(1592)
    elif request.GET['titlen'] ==                                                                                                     'LIBS 150- INTRODUCTION TO RESEARCH':
        lis2.append(1949)
    elif request.GET['titlen'] ==                                                                                                      'COMPOSITION':
        lis2.append( 672)
    elif request.GET['titlen'] ==                                                                                                      'MOC PREP COURSE':
        lis2.append(2126)
    elif request.GET['titlen'] ==                                                                                                      '(MARYLAND SHRM)  FINANCE FOR STRATEGIC HR PARTNERS':
        lis2.append(0)
    elif request.GET['titlen'] ==                                                                                                      'MARRIAGE AND FAMILY THERAPY':
        lis2.append(2002)
    elif request.GET['titlen'] ==                                                                                                       'MGMT 610- ORGANIZATIONAL THEORY':
        lis2.append(2092)
    elif request.GET['titlen'] ==                                                                                                     'EMAN 620 INFORMATION TECHNOLOGY IN EMERGENCY MANAGEMENT':
        lis2.append( 995)
    elif request.GET['titlen'] ==                                                                                                      'HSMN 610 CONCEPTS IN HOMELAND SECURITY':
        lis2.append(1531)
    elif request.GET['titlen'] ==                                                                                                      'FIRE OFFICER 1':
        lis2.append(1210)
    elif request.GET['titlen'] ==                                                                                                       'INSTRUCTOR 1':
        lis2.append(1641)
    elif request.GET['titlen'] ==                                                                                                       'PRINCIPLES OF EMERGENCY SERVICE':
        lis2.append(2382)
    elif request.GET['titlen'] ==                                                                                                       'NURSING MANAGEMENT IN HEALTH & ILLNESS':
        lis2.append(2204)
    elif request.GET['titlen'] ==                                                                                                       'HUMAN GROWTH & DEVELOPMENT':
        lis2.append(1552)
    elif request.GET['titlen'] ==                                                                                                       'NURS FAMILY NEWBORN WOMANS HEALTH':
        lis2.append(2186)
    elif request.GET['titlen'] ==                                                                                                        'MHA 506 ECONOMICS FOR HEALTHCARE MANAGERS':
        lis2.append(2109)
    elif request.GET['titlen'] ==                                                                                                         'INTRO TO CRIMINOLOGY':
        lis2.append(1701)
    elif request.GET['titlen'] ==                                                                                                       'CRIMINAL JUSTICE RESEARCH METHODS':
        lis2.append( 788)
    elif request.GET['titlen'] ==                                                                                                        'ADMIN OF JUSTICE':
        lis2.append(93)
    elif request.GET['titlen'] ==                                                                                                         'PRLW 101':
        lis2.append(2395)
    elif request.GET['titlen'] ==                                                                                                         'MGMT  510 - LEADERSHIP AND ETHICS':
        lis2.append(2078)
    elif request.GET['titlen'] ==                                                                                                          'ACCT 540 - FINANCIAL ACCOUNTING':
        lis2.append(79)
    elif request.GET['titlen'] ==                                                                                                           'SOCIAL WORK LICENSE EXAM PREP COURCE':
        lis2.append(2646)
    elif request.GET['titlen'] ==                                                                                                           'IFMS 201 CONCEPTS AND APPLICATIONS OF INFORMATION TECHNOLOGY':
        lis2.append(1589)
    elif request.GET['titlen'] ==                                                                                                            'PCP 266 INTRODUCTION TO INDESIGN CS6':
        lis2.append(2284)
    elif request.GET['titlen'] ==                                                                                                             'PCA 578 INDESIGN CS6 ADVANCED':
        lis2.append(2276)
    elif request.GET['titlen'] ==                                                                                                              'JUDGMENT AND DECISION MAKING SEMINAR':
        lis2.append(1857)
    elif request.GET['titlen'] ==                                                                                                           'GFOA 18TH ANNUAL GOVERNMENTAL GAAP UPDATE - LIVE STREAMING':
        lis2.append(1345)
    elif request.GET['titlen'] ==                                                                                                            'CREATING WORDPRESS WEBSITES':
        lis2.append( 772)
    elif request.GET['titlen'] ==                                                                                                            'ADVANCED CERTIFICATE IN FORENSIC SOCIAL WORK':
        lis2.append( 123)
    elif request.GET['titlen'] ==                                                                                                            'PSYC 436, INTRODUCTION TO CLINICAL PSYCHOLOGY ':
        lis2.append(2443)
    elif request.GET['titlen'] ==                                                                                                            'TOPICS IN TRAUMA':
        lis2.append(2823)
    elif request.GET['titlen'] ==                                                                                                             'EMOTIONAL INTELLIGENCE: AN EDGE FOR LEADERS':
        lis2.append(1020)
    elif request.GET['titlen'] ==                                                                                                              'PLANS EXAMINER I/II':
        lis2.append(2334)
    elif request.GET['titlen'] ==                                                                                                               'ENV 5001 - ENVIRONMENTAL INFLUENCES ON HUMAN HEALTH':
        lis2.append(1084)
    elif request.GET['titlen'] ==                                                                                                                'HEALTH CARE IN THE UNITED STATES - HPM 5001':
        lis2.append(1407)
    elif request.GET['titlen'] ==                                                                                                             'CPPB ONLINE ASSESSMENT':
        lis2.append( 760)
    elif request.GET['titlen'] ==                                                                                                             'ADVANCED BUILDING POWER SYSTEM DESIGN':
        lis2.append( 118)
    elif request.GET['titlen'] ==                                                                                                             'ADVANCED CARBINE-RSS LEVEL 3':
        lis2.append( 122)
    elif request.GET['titlen'] ==                                                                                                             'NW 173 NETWORK SECURITY':
        lis2.append(2219)
    elif request.GET['titlen'] ==                                                                                                             'AUDITING':
        lis2.append( 280)
    elif request.GET['titlen'] ==                                                                                                             'CCJS 320 INTRODUCTION TO CRIMINALISTICS':
        lis2.append( 465)
    elif request.GET['titlen'] ==                                                                                                             'BUSINESS ETHICS':
        lis2.append( 423)
    elif request.GET['titlen'] ==                                                                                                             'HIS 104 WORLD CIVILIZATIONS II':
        lis2.append(1434)
    elif request.GET['titlen'] ==                                                                                                             'HIST.OF WORLD CIVILIZATION II':
        lis2.append(1446)
    elif request.GET['titlen'] ==                                                                                                             'PADM612 PUBLIC FINANCE':
        lis2.append(2265)
    elif request.GET['titlen'] ==                                                                                                              'HOMICIDE AND QUESTIONED DEATH SCENE DETERMINATION AND RECONSTRUCTION':
        lis2.append(1494)
    elif request.GET['titlen'] ==                                                                                                              'BASIC ECONOMICS':
        lis2.append( 289)
    elif request.GET['titlen'] ==                                                                                                              'MATHMATICAL IDEAS':
        lis2.append(2050)
    elif request.GET['titlen'] ==                                                                                                              'INTL 650 COUNTERTERRORISM':
        lis2.append(1688)
    elif request.GET['titlen'] ==                                                                                                              'BIO 203 - ANATOMY AND PHYSIOLOGY I':
        lis2.append( 325)
    elif request.GET['titlen'] ==                                                                                                               'PSYC 105 HUMAN RELATIONS IN A CULTURALLY DIVERSE SOCIETY':
        lis2.append(2440)
    elif request.GET['titlen'] ==                                                                                                               'PHIL 101 INTRODUCTION TO PHILOSOPHY':
        lis2.append(2319)
    elif request.GET['titlen'] ==                                                                                                                'PSYC 103  PRINCIPLES OF HUMAN GROWTH AND DEVELOPMENT':
        lis2.append(2439)
    elif request.GET['titlen'] ==                                                                                                                'PSYC 201':
        lis2.append(2441)
    elif request.GET['titlen'] ==                                                                                                                'CCJS 44: SECURITY ADMINISTRATION':
        lis2.append( 475)
    elif request.GET['titlen'] ==                                                                                                                'DYNAMICS-ES 221':
        lis2.append( 911)
    elif request.GET['titlen'] ==                                                                                                                 'MULTIVARIABLE CALCULUS- MA 280':
        lis2.append(2147)
    elif request.GET['titlen'] ==                                                                                                                  'INTRODUCTION TO COMPUTER APPLICATION':
        lis2.append(1735)
    elif request.GET['titlen'] ==                                                                                                                  'THE EMDR BASIC TRANING COURSE WEEKEND 1':
        lis2.append(2788)
    elif request.GET['titlen'] ==                                                                                                                  'INTRODUCTION TO SOCIOLOGY':
        lis2.append(1796)
    elif request.GET['titlen'] ==                                                                                                                   'MATH 012 23879 HYBRID COURSE - SATURDAY MORNINGS/ONLINE':
        lis2.append(2023)
    elif request.GET['titlen'] ==                                                                                                                    'CONTRUCTION SAFETY':
        lis2.append( 726)
    elif request.GET['titlen'] ==                                                                                                                    'PRIN HEALTH LIVING':
        lis2.append(2365)
    elif request.GET['titlen'] ==                                                                                                                     'ELEC 146 LOWVOLTAGE AND SPECIALIZED SYSTEMS':
        lis2.append( 967)
    elif request.GET['titlen'] ==                                                                                                                      'INTRODUCTION TO PROGRAMMING':
        lis2.append(1783)
    elif request.GET['titlen'] ==                                                                                                                  'INVESTMENT ANALYSIS':
        lis2.append(1811)
    elif request.GET['titlen'] ==                                                                                                                   'SURVEILLANCE DETECTION TACTICS AND TECHNIQUES':
        lis2.append(2744)
    elif request.GET['titlen'] ==                                                                                                                   'PUBLIC RELATIONS TECHNIQUES (PRPA602)':
        lis2.append(2497)
    elif request.GET['titlen'] ==                                                                                                                    'SNIPER SUSTAINMENT PROGRAM-QUARTER 1':
        lis2.append(2625)
    elif request.GET['titlen'] ==                                                                                                                     'SNIPER SUSTAINMENT PROGRAM QUARTER 1':
        lis2.append(2624)
    elif request.GET['titlen'] ==                                                                                                                      'MGMT  610 ORGANIZATIONAL THEORY':
        lis2.append(2080)
    elif request.GET['titlen'] ==                                                                                                                      'INTRODUCTION TO COUNSELING AND INTERVIEWING':
        lis2.append(1738)
    elif request.GET['titlen'] ==                                                                                                                       'ADVANCED ACTIVE THREAT RESPOSE FOR LAW ENFORCEMENT(CUSTOM)':
        lis2.append( 112)
    elif request.GET['titlen'] ==                                                                                                                       'ADVANCED ACTIVE THREAT FOR LAW ENFORCEMENT (CUSTOM COURSE)':
        lis2.append( 110)
    elif request.GET['titlen'] ==                                                                                                                     'ADVANCED ACTIVE THREAT FOR LAW ENFORCEMENT':
        lis2.append( 109)
    elif request.GET['titlen'] ==                                                                                                                      'GLOCK HANDGUN ARMORER COURSE':
        lis2.append(1364)
    elif request.GET['titlen'] ==                                                                                                                      'ADVANCED ACTIVE THREAT RESPONSE FOR LAW ENFORCEMENT':
        lis2.append( 111)
    elif request.GET['titlen'] ==                                                                                                                      'SEC401 - SANS SECURITY ESSENTIALS BOOTCAMP':
        lis2.append(2593)
    elif request.GET['titlen'] ==                                                                                                                      'THEMIS BAR REVIEW - BAR EXAM PREPARATION COURSE':
        lis2.append(2803)
    elif request.GET['titlen'] ==                                                                                                                       'FOUNDATIONS IN MANAGEMENT AND TECHNOLOGY':
        lis2.append(1250)
    elif request.GET['titlen'] ==                                                                                                                       'COMBAT PISTOL':
        lis2.append( 649)
    elif request.GET['titlen'] ==                                                                                                                       'COMBAT CARBINE':
        lis2.append( 648)
    elif request.GET['titlen'] ==                                                                                                                       'CDL B P&S---24 HOURS BASIC SKILLS AND REFRESHER COURSE':
        lis2.append( 484)
    elif request.GET['titlen'] ==                                                                                                                       'EFFECTIVE CONTRACT WRITING':
        lis2.append( 957)
    elif request.GET['titlen'] ==                                                                                                                        'FOUNDATIONS FOR GRADUATE STUDY IN PYSCHOLOGY':
        lis2.append(1249)
    elif request.GET['titlen'] ==                                                                                                                        'SFT025: BEGINNERS MOTORCYCLE SAFETY':
        lis2.append(2609)
    elif request.GET['titlen'] ==                                                                                                                         'CRIMINAL JUSTICE SYSTEM AND SOCIETY':
        lis2.append( 789)
    elif request.GET['titlen'] ==                                                                                                                          'MA81- INTRODUCTORY ALGEBRA':
        lis2.append(1971)
    elif request.GET['titlen'] ==                                                                                                                          '4-DAY INTERVIEW AND INTERROGATION TECHNIQUE':
        lis2.append(27)
    elif request.GET['titlen'] ==                                                                                                                           'TRND & PROJECT DIGITAL MEDIA & WEB TECHNOLOGY':
        lis2.append(2835)
    elif request.GET['titlen'] ==                                                                                                                            'CRIMINAL JUSTICE INTELLIGENCE SYSTEMS AND APPROACHES':
        lis2.append( 785)
    elif request.GET['titlen'] ==                                                                                                                          'ACCOUNTING 326':
        lis2.append(59)
    elif request.GET['titlen'] ==                                                                                                                           'BEGINNERS MOTORCYCLE SAFETY SFT025 CRN # 35388':
        lis2.append( 302)
    elif request.GET['titlen'] ==                                                                                                                            'PSL 8002 COLLABRATION, COMMUNICATION AND CASE ANALYSIS FOR DOCTORAL LEARNERS':
        lis2.append(2432)
    elif request.GET['titlen'] ==                                                                                                                             'COMPTIA A +, NETWORK +, AND SECURITY + BUNDLE ONLINE COURSE':
        lis2.append( 676)
    elif request.GET['titlen'] ==                                                                                                                              'EDTC 600---FOUNDATION TECH TEACH LEARN':
        lis2.append( 947)
    elif request.GET['titlen'] ==                                                                                                                              'CLOSE QUARTERS BATTLE - OFFENSIVE STRONGHOLD CLEARANCE TACTICS':
        lis2.append( 581)
    elif request.GET['titlen'] ==                                                                                                                              'CLOSE QUARTERS BATTLE/OFFENSIVE STRONGHOLD CLEARANCE':
        lis2.append( 582)
    elif request.GET['titlen'] ==                                                                                                                             'MBU 674- M.S.M. CAPSTONE: RESEARCH/SYN/APP':
        lis2.append(2057)
    elif request.GET['titlen'] ==                                                                                                                              'ADVANCED REASEARCH METHODS: EVIDENCE-BASED PRACTICE':
        lis2.append( 143)
    elif request.GET['titlen'] ==                                                                                                                              'FUNDAMENTALS OF NURSING INFORMATICS':
        lis2.append(1301)
    elif request.GET['titlen'] ==                                                                                                                               'COGNITIVE BEHAVIORAL THERAPIES':
        lis2.append( 633)
    elif request.GET['titlen'] ==                                                                                                                               'ADVANCED CLINICAL FIELD PRACTICUM':
        lis2.append( 124)
    elif request.GET['titlen'] ==                                                                                                                                'CRASH DATA RETRIEVAL SPECIALIST (ANALYST)':
        lis2.append( 771)
    elif request.GET['titlen'] ==                                                                                                                                 'CORRECTIONAL LAW':
        lis2.append( 733)
    elif request.GET['titlen'] ==                                                                                                                                 'LEARNING STRATEGIES   -  PF 321':
        lis2.append(1921)
    elif request.GET['titlen'] ==                                                                                                                                  'MANAGEMENT & LEADERSHIP IN DISTANCE EDUCATION AND ELEARNING DEPM 604':
        lis2.append(1975)
    elif request.GET['titlen'] ==                                                                                                                               'INTERNET MULTIMEDIA APPLICATION IMAT639':
        lis2.append(1678)
    elif request.GET['titlen'] ==                                                                                                                                'INTRODUCTION TO DIGITAL PHOTOGRAPHY - PG161':
        lis2.append(1741)
    elif request.GET['titlen'] ==                                                                                                                                'INTRODUCTION TO HOMELAND SECURITY':
        lis2.append(1763)
    elif request.GET['titlen'] ==                                                                                                                                'NURS  215 - 002   NUTRITION IN HEALTH & DI':
        lis2.append(2178)
    elif request.GET['titlen'] ==                                                                                                                                 'NURS  302 - 005   HEALTH ASSESSMENT':
        lis2.append(2179)
    elif request.GET['titlen'] ==                                                                                                                                  'DIFFERENTIAL EQUATIONS-MA282':
        lis2.append( 879)
    elif request.GET['titlen'] ==                                                                                                                                  'BSS/483 WORLD VIEW OF HOMELAND SECURITY':
        lis2.append( 389)
    elif request.GET['titlen'] ==                                                                                                                                   'BUSINESS LAW':
        lis2.append( 427)
    elif request.GET['titlen'] ==                                                                                                                                   'MATH012-6980':
        lis2.append(2041)
    elif request.GET['titlen'] ==                                                                                                                                'LEADING AND MANAGING PEOPLE':
        lis2.append(1915)
    elif request.GET['titlen'] ==                                                                                                                                 'BASIC RIDER MOTORCYCLE SAFETY COURSE':
        lis2.append( 296)
    elif request.GET['titlen'] ==                                                                                                                                  'LIBS 150':
        lis2.append(1946)
    elif request.GET['titlen'] ==                                                                                                                                   'HISTORICAL STUDIES':
        lis2.append(1450)
    elif request.GET['titlen'] ==                                                                                                                                    'JUVENILE JUSTICE':
        lis2.append(1866)
    elif request.GET['titlen'] ==                                                                                                                                     'RACE AND ETHNIC AND CRIME':
        lis2.append(2519)
    elif request.GET['titlen'] ==                                                                                                                                     'OFFSETS/HIGHLINE WORKSHOP':
        lis2.append(2225)
    elif request.GET['titlen'] ==                                                                                                                                     'HUMAN SERVICE ETHICS':
        lis2.append(1569)
    elif request.GET['titlen'] ==                                                                                                                                     'INTRO TO CRIMINAL JUSTICE':
        lis2.append(1700)
    elif request.GET['titlen'] ==                                                                                                                                     '2015 IAAI INTERNATIONAL TRAINING CONFRENCE':
        lis2.append(13)
    elif request.GET['titlen'] ==                                                                                                                                      'CRIMINALISTICS I: THE COMPARATIVE DISCIPLINES':
        lis2.append( 796)
    elif request.GET['titlen'] ==                                                                                                                                       'CRIMINALISTICS II: THE SCIENTIFIC DISCIPLINES':
        lis2.append( 797)
    elif request.GET['titlen'] ==                                                                                                                                      'FIRE INSPECTOR II':
        lis2.append(1203)
    elif request.GET['titlen'] ==                                                                                                                                       'UNDERSTANDING TRAUMA AND RECOVERY I':
        lis2.append(2844)
    elif request.GET['titlen'] ==                                                                                                                                        'MARKETING AND STRATEGY MANAGEMENT IN THE GLOBAL MARKETPLACE':
        lis2.append(1998)
    elif request.GET['titlen'] ==                                                                                                                                        'SOCIOLOGY: FAMILY DEMOGRAPHY':
        lis2.append(2661)
    elif request.GET['titlen'] =='INTRO TO THE PSYCHOLOGY OF PARENTING':
        lis2.append(1720)
    elif request.GET['titlen'] ==                                                                                                                                        'AFRICAN AMERICAN AUTHORS':
        lis2.append( 160)
    elif request.GET['titlen'] ==                                                                                                                                         'ADV TECH WRITING':
        lis2.append( 101)
    elif request.GET['titlen'] ==                                                                                                                                         'WF ED 573 - NEEDS ASSESSMENT FOR INDUSTRIAL TRAINERS':
        lis2.append(2879)
    elif request.GET['titlen'] ==                                                                                                                                          'GLOBAL SECURITY EXCHANGE CONFERENCE':
        lis2.append(1354)
    elif request.GET['titlen'] ==                                                                                                                                         'ANTH 346 ANTHROPOLOGY OF LANGUAGE AND COMMUNICATION':
        lis2.append( 225)
    elif request.GET['titlen'] ==                                                                                                                                         'COGNITIVE BEHAVIORAL THERAPY FOR DEPRESSION AND SUICIDALITY- CORE I':
        lis2.append( 635)
    elif request.GET['titlen'] ==                                                                                                                                          'INFECTIOUS DISEASES BOARD REVIEW COURSE':
        lis2.append(1619)
    elif request.GET['titlen'] ==                                                                                                                                          'ISSUES IN CORRECTIONAL ADMINISTRATION':
        lis2.append(1825)
    elif request.GET['titlen'] ==                                                                                                                                          'FEDERAL INCOME TAX I':
        lis2.append(1155)
    elif request.GET['titlen'] ==                                                                                                                                          'ETHICS AND PROFESSIONALISM IN ACCOUNTING':
        lis2.append(1116)
    elif request.GET['titlen'] ==                                                                                                                                           'FINANCIAL MANAGEMENT FOR PUBLIC AND NONPROFIT ORGANIZATIONS':
        lis2.append(1185)
    elif request.GET['titlen'] ==                                                                                                                                            'CONTRACT PRICING':
        lis2.append( 723)
    elif request.GET['titlen'] ==                                                                                                                                           "REMINGTON 700 RIFLE ARMORER'S COURSE":
        lis2.append(2543)
    elif request.GET['titlen'] ==                                                                                                                                            'FISHERIES MANAGEMENT':
        lis2.append(1224)
    elif request.GET['titlen'] ==                                                                                                                                             'METEOROLOGY':
        lis2.append(2073)
    elif request.GET['titlen'] ==                                                                                                                                              'HOME QUALITY STANDARDS':
        lis2.append(1486)
    elif request.GET['titlen'] ==                                                                                                                                               'ETHICS IN GOVERNMENT':
        lis2.append(1121)
    elif request.GET['titlen'] ==                                                                                                                                               'MATHEMATICAL FUNDAMENTALS':
        lis2.append(2043)
    elif request.GET['titlen'] ==                                                                                                                                               'GERO 100, INTRODUCTION TO GERONTOLOGY ':
        lis2.append(1334)
    elif request.GET['titlen'] ==                                                                                                                                                'UPDATES IN ILLNESS AND DISEASE MANAGEMENT':
        lis2.append(2848)
    elif request.GET['titlen'] ==                                                                                                                                                'HEALTH PROMOTION CONCEPTS':
        lis2.append(1418)
    elif request.GET['titlen'] ==                                                                                                                                                'HISTORY 465 (WORLD WAR II)':
        lis2.append(1456)
    elif request.GET['titlen'] ==                                                                                                                                                 '2015 INTERNATIONAL TRAINING CONFERENCE':
        lis2.append(14)
    elif request.GET['titlen'] ==                                                                                                                                                'HISTORY 462 U.S. CIVIL WAR':
        lis2.append(1455)
    elif request.GET['titlen'] ==                                                                                                                                                'PROGRAMMING LOGIC AND DESIGN':
        lis2.append(2409)
    elif request.GET['titlen'] ==                                                                                                                                                 'INTRODUCTION TO NETWORK':
        lis2.append(1772)
    elif request.GET['titlen'] ==                                                                                                                                                  'CMST  301 - 6980   DIGITAL MEDIA AND SOCIETY':
        lis2.append( 625)
    elif request.GET['titlen'] ==                                                                                                                                                   "REMINGTON 870 SHOTGUN ARMORER'S COURSE":
        lis2.append(2547)
    elif request.GET['titlen'] ==                                                                                                                                                   'WRTG  391 - 7981   ADVANCED RESEARCH WRITING':
        lis2.append(2908)
    elif request.GET['titlen'] ==                                                                                                                                                   'PUBLIC SAFETY HIRING BACKGROUND INVESTIGATIONS':
        lis2.append(2501)
    elif request.GET['titlen'] ==                                                                                                                                                   'STAT 225 - INTRODUCTION TO STATISTICAL METHODS FOR THE BEHAVIORAL SCIENCES':
        lis2.append(2710)
    elif request.GET['titlen'] ==                                                                                                                                                    'WRTG 393 - ADVANCED TECHNICAL WRITING':
        lis2.append(2917)
    elif request.GET['titlen'] ==                                                                                                                                                     'FINC 351 - RISK MANAGEMENT':
        lis2.append(1190)
    elif request.GET['titlen'] ==                                                                                                                                                     'HSMN 610 - CONCEPTS IN HOMELAND SECURITY':
        lis2.append(1530)
    elif request.GET['titlen'] ==                                                                                                                                                      'MGMT 650 - STAT MANAGERIAL DEC MAKING':
        lis2.append(2099)
    elif request.GET['titlen'] ==                                                                                                                                                       'REC443 INTEGRATED RISK MANAGEMENT FOR LEISURE SERVICES':
        lis2.append(2528)
    elif request.GET['titlen'] ==                                                                                                                                                       'THE EMDR BASIC TRANING COURSE: WEEKEND 2':
        lis2.append(2789)
    elif request.GET['titlen'] ==                                                                                                                                                        'HCAD 670, HEALTH CARE ADMINISTRATION CAPSTON':
        lis2.append(1397)
    elif request.GET['titlen'] ==                                                                                                                                                         'CURRENT PERSPECTIVES TRAINING':
        lis2.append( 836)
    elif request.GET['titlen'] ==                                                                                                                                                         'PHA 6935  APPLIED STATISTICS FOR DATA ANALYSIS':
        lis2.append(2310)
    elif request.GET['titlen'] ==                                                                                                                                                          'INTERMEDIATE ACCOUNTING I':
        lis2.append(1657)
    elif request.GET['titlen'] ==                                                                                                                                                           'BUSINESS LAW I':
        lis2.append( 429)
    elif request.GET['titlen'] ==                                                                                                                                                           'INTRODUCTION TO RESEARCH':
        lis2.append(1787)
    elif request.GET['titlen'] ==                                                                                                                                                         'TERRORISM':
        lis2.append(2780)
    elif request.GET['titlen'] ==                                                                                                                                                         'INTERCULTURAL COMMUNICATION COMM 240':
        lis2.append(1653)
    elif request.GET['titlen'] ==                                                                                                                                                         'INTROUDUCTION TO THE COURTS':
        lis2.append(1807)
    elif request.GET['titlen'] ==                                                                                                                                                         'HEALTH CARE INSTITUTIONAL ORGANIZATION AND MANAGEMENT':
        lis2.append(1408)
    elif request.GET['titlen'] ==                                                                                                                                                          'BORKENSTEIN COURSE ON ALCOHOL AND HIGHWAY SAFETY':
        lis2.append( 381)
    elif request.GET['titlen'] ==                                                                                                                                                          'OMDE 606: COST & ECONOMICS OF DISTANCE EDUCATION AND E-LEARNING':
        lis2.append(2229)
    elif request.GET['titlen'] ==                                                                                                                                                          'DETC 630 EMERGING TECHNOLOGY TRENDS & ISSUES IN DISTANCE EDUCATION & E-LEARNING':
        lis2.append( 871)
    elif request.GET['titlen'] ==                                                                                                                                                           'THEOLOGY 104':
        lis2.append(2805)
    elif request.GET['titlen'] ==                                                                                                                                                            'INTRO TO SOCIOLOGY':
        lis2.append(1716)
    elif request.GET['titlen'] ==                                                                                                                                                             'CJUS300':
        lis2.append( 572)
    elif request.GET['titlen'] ==                                                                                                                                                              'INTRODUCTION TO PUBLIC ADMINISTRATION':
        lis2.append(1785)
    elif request.GET['titlen'] ==                                                                                                                                                               'HAZARDOUS MATERIALS':
        lis2.append(1393)
    elif request.GET['titlen'] ==                                                                                                                                                                'PUBLIC PERSONAL ADMINISTRATION':
        lis2.append(2489)
    elif request.GET['titlen'] ==                                                                                                                                                                 'FAMILY COUNSELING':
        lis2.append(1143)
    elif request.GET['titlen'] ==                                                                                                                                                                 'ROPES THAT RESCUE':
        lis2.append(2573)
    elif request.GET['titlen'] ==                                                                                                                                                                 'AGING BODY, AGING MIND':
        lis2.append( 165)
    elif request.GET['titlen'] ==                                                                                                                                                                 'MENTAL HEALTH AND SOCIAL POLICY':
        lis2.append(2069)
    elif request.GET['titlen'] ==                                                                                                                                                                'SECURITY IN EAST ASIA':
        lis2.append(2596)
    elif request.GET['titlen'] ==                                                                                                                                                                'HRMD650, ORGANIZATIONAL DEVELOPMENT':
        lis2.append(1511)
    elif request.GET['titlen'] ==                                                                                                                                                                 'FE EXAM':
        lis2.append(1154)
    elif request.GET['titlen'] ==                                                                                                                                                                 'SOC 120 INTRODUCTION TO ETHICS & SOCIAL RESPONSIBILITY':
        lis2.append(2627)
    elif request.GET['titlen'] ==                                                                                                                                                                 'STRATEGIC MANAGEMENT CAPSTONE - MGMT 670':
        lis2.append(2724)
    elif request.GET['titlen'] ==                                                                                                                                                                 'SEMINAR IN EMERGENCY MANAGEMENT LEADERSHIP - EMAN 670':
        lis2.append(2600)
    elif request.GET['titlen'] ==                                                                                                                                                                 'INTRODUCTION TO VETERINARY TECHNOLOGY':
        lis2.append(1802)
    elif request.GET['titlen'] ==                                                                                                                                                                 'ORGANIZATIONAL THEORY':
        lis2.append(2248)
    elif request.GET['titlen'] ==                                                                                                                                                                  'AMERICAN POLITICAL THEORY':
        lis2.append( 205)
    elif request.GET['titlen'] ==                                                                                                                                                                 'TRAUMA CERTIFICATE PROGRAM':
        lis2.append(2832)
    elif request.GET['titlen'] ==                                                                                                                                                                  'INTRO TO COLLEGE WRITING - ENGL 101A - 400':
        lis2.append(1697)
    elif request.GET['titlen'] ==                                                                                                                                                                  'INFA 660 SECURITY POLICY, ETHICS, AND THE LEGAL ENVIRONMENT':
        lis2.append(1618)
    elif request.GET['titlen'] ==                                                                                                                                                                  'BEGINNING WORD PROCESSING CMSY 102':
        lis2.append( 303)
    elif request.GET['titlen'] ==                                                                                                                                                                  'SMALL BUSINESS MANAGEMENT - BSAD 3000 -':
        lis2.append(2622)
    elif request.GET['titlen'] ==                                                                                                                                                                   'ETHICAL SALES AND SERVICE - PS 4203 - 0':
        lis2.append(1108)
    elif request.GET['titlen'] ==                                                                                                                                                                   'SS/DV SOCIAL PROBLEMS - SOC 1020 - 0':
        lis2.append(2705)
    elif request.GET['titlen'] ==                                                                                                                                                                    'EMERGENCY MANAGEMENT':
        lis2.append(1001)
    elif request.GET['titlen'] ==                                                                                                                                                                     'MUS 305 MUSIC HISTORY':
        lis2.append(2148)
    elif request.GET['titlen'] ==                                                                                                                                                                      'AMERICAN FOREIGN RELATIONS':
        lis2.append( 197)
    elif request.GET['titlen'] ==                                                                                                                                                                       'ELEMENTS OF NUTRITION':
        lis2.append( 986)
    elif request.GET['titlen'] ==                                                                                                                                                                       'MATH 117':
        lis2.append(2035)
    elif request.GET['titlen'] ==                                                                                                                                                                       'COGNITIVE THERAPY FOR ANXIETY':
        lis2.append( 638)
    elif request.GET['titlen'] ==                                                                                                                                                                       'HUMAN SERVICES IN THE UNITED STATES':
        lis2.append(1570)
    elif request.GET['titlen'] ==                                                                                                                                                                       'MORAL AND ETHICAL DIMENSIONS OF PUBLIC POLICY AND LEADERSHIP':
        lis2.append(2130)
    elif request.GET['titlen'] ==                                                                                                                                                                        'GEOG200 1001 FUNDAMENTALS OF GEOGRAPHIC INFORMATION SYSTEMS':
        lis2.append(1330)
    elif request.GET['titlen'] ==                                                                                                                                                                         'MAT106: FINITE MATHEMATICS':
        lis2.append(2016)
    elif request.GET['titlen'] ==                                                                                                                                                                          'CERTIFIED NURSING ASSISTANT':
        lis2.append( 505)
    elif request.GET['titlen'] ==                                                                                                                                                                           'PROGRAM APPRAISAL':
        lis2.append(2406)
    elif request.GET['titlen'] ==                                                                                                                                                                            'HEALTH POLICY':
        lis2.append(1417)
    elif request.GET['titlen'] ==                                                                                                                                                                             'MANAGING VIRTUAL AND GLOBAL TEAMS':
        lis2.append(1992)
    elif request.GET['titlen'] ==                                                                                                                                                                              'MATHEMATICS BASIC FUNDAMENTALS MA1100':
        lis2.append(2047)
    elif request.GET['titlen'] ==                                                                                                                                                                              'ENGLISH COMPOSITION 1010':
        lis2.append(1075)
    elif request.GET['titlen'] ==                                                                                                                                                                              'ENGLISH 2070':
        lis2.append(1065)
    elif request.GET['titlen'] ==                                                                                                                                                                             'SPEECH 1050':
        lis2.append(2696)
    elif request.GET['titlen'] ==                                                                                                                                                                              'PHYS-262- PHYSICS II':
        lis2.append(2328)
    elif request.GET['titlen'] ==                                                                                                                                                                               'PHYS-263-PHYSICS III':
        lis2.append(2329)
    elif request.GET['titlen'] ==                                                                                                                                                                                'SOCY 100 -INTRODUCTION TO SOCIOLOGY':
        lis2.append(2662)
    elif request.GET['titlen'] ==                                                                                                                                                                                 'CRITICAL THINKING':
        lis2.append( 808)
    elif request.GET['titlen'] ==                                                                                                                                                                                 'EEC 4030  SUPPORTING EXCEPTIONAL CHILDREN AND FAMILIES.':
        lis2.append( 956)
    elif request.GET['titlen'] ==                                                                                                                                                                                 'EEC 3020 POSITIVE BEHAVIOR GUIDANCE FOR YOUNG CHILDREN':
        lis2.append( 955)
    elif request.GET['titlen'] ==                                                                                                                                                                                  'OFFSET / HIGHLINE RESCUE WORKSHOP':
        lis2.append(2223)
    elif request.GET['titlen'] ==                                                                                                                                                                                   'INTRODUCTION TO PUBLIC SAFETY ADNMINSTRATION  PSAD-302':
        lis2.append(1786)
    elif request.GET['titlen'] ==                                                                                                                                                                                  'HOMELAND SECURITY 495 - PUBLIC POLICY':
        lis2.append(1489)
    elif request.GET['titlen'] ==                                                                                                                                                                                   'OFFSET/HIGHLINE RESCUE WORKSHOP':
        lis2.append(2224)
    elif request.GET['titlen'] ==                                                                                                                                                                                    'NATIONAL ELECTRICAL CODE (NEC) GUIDED ONLINE COURSE':
        lis2.append(2152)
    elif request.GET['titlen'] ==                                                                                                                                                                                     'NATIONAL FIRE ALARM AND SIGNALING CODE SELF-GUIDED ONLINE COURSE SERIES':
        lis2.append(2153)
    elif request.GET['titlen'] ==                                                                                                                                                                                      'SPANISH INDIVIDUAL INSTRUCTION LEVEL II':
        lis2.append(2688)
    elif request.GET['titlen'] ==                                                                                                                                                                                       'BUILDING CONSTRUCTION FOR FIRE PROTECTION FS112':
        lis2.append( 392)
    elif request.GET['titlen'] ==                                                                                                                                                                                     'EXTERNSHIP SEMINAR':
        lis2.append(1140)
    elif request.GET['titlen'] ==                                                                                                                                                                                      'LEADERSHIP DEVELOPMENT IN CRIMINAL JUSTICE':
        lis2.append(1906)
    elif request.GET['titlen'] ==                                                                                                                                                                                       'CJMS  610 - PERS LAW ENFORCEMENT MGMT':
        lis2.append( 559)
    elif request.GET['titlen'] ==                                                                                                                                                                                       'HUMAN GROWTH & DFEVELOPMENT':
        lis2.append(1553)
    elif request.GET['titlen'] ==                                                                                                                                                                                       'ANATOMY & PHYSIOLOGY I':
        lis2.append( 215)
    elif request.GET['titlen'] ==                                                                                                                                                                                       'CHEMISTRY AND LAB':
        lis2.append( 530)
    elif request.GET['titlen'] ==                                                                                                                                                                                       'LEGAL AND ETHICAL ISSUES':
        lis2.append(1924)
    elif request.GET['titlen'] ==                                                                                                                                                                                       'EMGT 306 POLITICAL AND POLICY ISSUES IN EMERGENCY MANAGEMENT':
        lis2.append(1016)
    elif request.GET['titlen'] ==                                                                                                                                                                                        'BMGT- BUSINESS LAW':
        lis2.append( 369)
    elif request.GET['titlen'] ==                                                                                                                                                                                         'SPANISH 116':
        lis2.append(2683)
    elif request.GET['titlen'] ==                                                                                                                                                                                          'SEMINAR IN POLICING':
        lis2.append(2601)
    elif request.GET['titlen'] ==                                                                                                                                                                                           'AIR CONDITIONING AND HEAT PUMP - BLDG 273 AND 273L':
        lis2.append( 175)
    elif request.GET['titlen'] ==                                                                                                                                                                                           'HEATING SYSTEMS BLDG 271 AND 271L':
        lis2.append(1426)
    elif request.GET['titlen'] ==                                                                                                                                                                                           'HVAC TECHNICIAN DEVELOPMENT BLDG 174':
        lis2.append(1580)
    elif request.GET['titlen'] ==                                                                                                                                                                                            'EDD 7212 ORGANIZATIONAL LEARNING & PROFESSIONAL GROWTH':
        lis2.append( 939)
    elif request.GET['titlen'] ==                                                                                                                                                                                            'EDD 7200 SUPERVISORY BEHAVIOR':
        lis2.append( 937)
    elif request.GET['titlen'] ==                                                                                                                                                                                            'FOUNDATIONS OF EDUCATION/FIELD EXPERIENCE IN EDUCATION':
        lis2.append(1252)
    elif request.GET['titlen'] ==                                                                                                                                                                                             'PRINCIPLES OF ENGLISH GRAMMAR':
        lis2.append(2383)
    elif request.GET['titlen'] ==                                                                                                                                                                                              '2-DAY TRAUMA COMPETENCY CONFERENCE: THE 10 CORE COMPETENCIES OF TRAUMA, PTSD, GRIEF & LOSS':
        lis2.append(7)
    elif request.GET['titlen'] ==                                                                                                                                                                                              'SANE TRAINING':
        lis2.append(2583)
    elif request.GET['titlen'] ==                                                                                                                                                                                               'DISSERTATION 9001':
        lis2.append( 893)
    elif request.GET['titlen'] ==                                                                                                                                                                                                'ORGANIZATIONAL BEHAVIOR - BMGT 464':
        lis2.append(2240)
    elif request.GET['titlen'] ==                                                                                                                                                                                                'BUSINESS ETHICS - BMGT 496':
        lis2.append( 424)
    elif request.GET['titlen'] ==                                                                                                                                                                                               'ART 101- INTRODUCTION TO DRAWING':
        lis2.append( 254)
    elif request.GET['titlen'] ==                                                                                                                                                                                                'BUSINESS FINANCE - FIN 330':
        lis2.append( 426)
    elif request.GET['titlen'] ==                                                                                                                                                                                                 'UNDERSTANDING DEPRESSION AND BIPOLAR DISORDER':
        lis2.append(2842)
    elif request.GET['titlen'] ==                                                                                                                                                                                                  'PSSL 6240 POLITICAL VIOLENCE AND TERRORISM':
        lis2.append(2433)
    elif request.GET['titlen'] ==                                                                                                                                                                                                  'BUILDING TECH AND DOCUMENTATION':
        lis2.append( 393)
    elif request.GET['titlen'] ==                                                                                                                                                                                                   'FIN  620 - LONG-TERM FINANCIAL MANAGEMENT':
        lis2.append(1174)
    elif request.GET['titlen'] ==                                                                                                                                                                                                   'ACCT  625 - GOVERNMENT AND NOT-FOR-PROFIT ACCOUNTING':
        lis2.append(72)
    elif request.GET['titlen'] ==                                                                                                                                                                                                    'AMERICAN ENG LANGUAGE III':
        lis2.append( 195)
    elif request.GET['titlen'] ==                                                                                                                                                                                                   'INTERMEDIATE CHINESE I':
        lis2.append(1663)
    elif request.GET['titlen'] ==                                                                                                                                                                                                    'ED.861.713 ADVANCED TREATMENT APPROACHES':
        lis2.append( 931)
    elif request.GET['titlen'] ==                                                                                                                                                                                                    'FIRE ALARM NICET PREP LEVEL 1 & 2 CLASS':
        lis2.append(1194)
    elif request.GET['titlen'] ==                                                                                                                                                                                                     'MASTER ELECTRICIAN PREPARATION COURSE':
        lis2.append(2006)
    elif request.GET['titlen'] ==                                                                                                                                                                                                     'COGNITIVE BEHAVIORAL THERAPY FOR DEPRESSION AND SUICIDALITY':
        lis2.append( 634)
    elif request.GET['titlen'] ==                                                                                                                                                                                                      'STRESS MANAGEMENT':
        lis2.append(2733)
    elif request.GET['titlen'] ==                                                                                                                                                                                                      'SYSTEMS ANALYSIS AND DESIGN':
        lis2.append(2763)
    elif request.GET['titlen'] ==                                                                                                                                                                                                       'ISAS 650 INFORMATION TECHNOLOGY, THE CIO AND ORGGANIZATIONAL TRANSFORMATION':
        lis2.append(1817)
    elif request.GET['titlen'] ==                                                                                                                                                                                                      'LOCAL AREA NETWORK (ISYS 302U - 01)':
        lis2.append(1957)
    elif request.GET['titlen'] ==                                                                                                                                                                                                       'RAPID INTERVENTION TEAMS: TRAIN-THE-TRAINER':
        lis2.append(2522)
    elif request.GET['titlen'] ==                                                                                                                                                                                                        'COLLECTION DEVELOPMENT':
        lis2.append( 640)
    elif request.GET['titlen'] ==                                                                                                                                                                                                         'MANAGERIAL ECONOMICS ':
        lis2.append(1987)
    elif request.GET['titlen'] ==                                                                                                                                                                                                          'SUCESSFUL PROJECT MANAGEMENT':
        lis2.append(2740)
    elif request.GET['titlen'] ==                                                                                                                                                                                                           'BUSINESS AND PROFESSIONAL ETHICS':
        lis2.append( 419)
    elif request.GET['titlen'] ==                                                                                                                                                                                                            'PSF8106 EPISTOMOLOGY OF PRATICE KNOWLEDGE':
        lis2.append(2431)
    elif request.GET['titlen'] ==                                                                                                                                                                                                            '498 STRATEGIC MANAGEMENT IN HEALTH CARE':
        lis2.append(32)
    elif request.GET['titlen'] ==                                                                                                                                                                                                            'AMERICAN MILITARY HISTORY':
        lis2.append( 203)
    elif request.GET['titlen'] ==                                                                                                                                                                                                            'BASIC FRENCH':
        lis2.append( 291)
    elif request.GET['titlen'] == 'SWAHILI':
        lis2.append(2749)
    elif request.GET['titlen'] ==                                                                                                                                                                                                            'TRAUMA AND CRITICAL CARE':
        lis2.append(2831)
    elif request.GET['titlen'] ==                                                                                                                                                                                                             'MATH-096-INTERMEDIATE ALGEBRA':
        lis2.append(2039)
    elif request.GET['titlen'] ==                                                                                                                                                                                                              'PROJECT MANAGEMENT':
        lis2.append(2412)
    elif request.GET['titlen'] ==                                                                                                                                                                                                               'ESSENTIALS OF COMMERCIAL CONTRACT MANAGEMENT':
        lis2.append(1100)
    elif request.GET['titlen'] ==                                                                                                                                                                                                               'NUTRITION':
        lis2.append(2211)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                'CULTURAL PSYCHOLOGY':
        lis2.append( 835)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                "INTRO TO WOMEN'S STUDIES":
        lis2.append(1722)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                'THE LIVING SOIL':
        lis2.append(2794)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                'SENIOR SEMINAR: INTEGRATIVE EXPERIENCE':
        lis2.append(2605)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                 'MANAGEMENT OF HUMAN RESOURCES ':
        lis2.append(1984)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                  'GLOBAL HEALTH SYSTEMS':
        lis2.append(1349)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                   'FISCAL MANAGEMENT IN HEALTHCARE SERVICES':
        lis2.append(1223)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                    'DIVERSITY AWARENESS':
        lis2.append( 897)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                     'MEDICAL GENERAL CHEMISTRY I':
        lis2.append(2062)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                     'LEADERSHIP STUDIES':
        lis2.append(1913)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                     'CONSTITUTIONAL LAW':
        lis2.append( 708)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                     'LAW IN CONTEXT-AMERICAN LEGAL HISTORY':
        lis2.append(1888)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                     'INTRO TO LEGAL STUDIES':
        lis2.append(1708)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                      'ISSUES AND PROBLEMS':
        lis2.append(1824)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                      'THE TOTAL REWARDS APPROACH TO COMPENSATION MANAGEMENT':
        lis2.append(2801)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                       'SHRM SCP OVERVIEW':
        lis2.append(2615)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                        'INTEGRATED TALENT MANAGEMENT: ALIGNING TALENT WITH ORGANIZATIONAL DEMANDS':
        lis2.append(1643)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                        'PROTECTIVE/EVASIVE DRIVING RECERTIFICATION':
        lis2.append(2424)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                         'ENGLISH 303 CRITICAL APPROACH TO LITERATURE':
        lis2.append(1068)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                          'ENGLISH 309':
        lis2.append(1069)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                           'LEADERSHIP MONTGOMERY ':
        lis2.append(1912)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                            'MRKT 601':
        lis2.append(2139)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                             'MRKT 602':
        lis2.append(2140)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                              'SOWK 631 SOCIAL WORK PRACTICE W/COMMUNITY & ORG.':
        lis2.append(2671)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                              'INTRODUCTION TO HEALTHCARE ADMINISTRATION':
        lis2.append(1762)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                              'PUBLIC SAFETY PRACTICES':
        lis2.append(2506)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                               'WRTG  391 - ADVANCED RESEARCH WRITING':
        lis2.append(2909)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                'ADMINISTRATION OF JUSTICE':
        lis2.append(95)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                 'HR MANAGEMENT':
        lis2.append(1500)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                  'ILPA INSTITUTE LEVEL I':
        lis2.append(1603)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                   'ENME 462 VIBRATIONS, CONTROLS, AND OPTIMIZATION (2)':
        lis2.append(1081)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                    'ENME 472 INTEGRATED PRODUCT AND PROCESSING DEVELOPMENT':
        lis2.append(1082)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                     'CYBER SECURITY AND INFORMATION PROTECTION ':
        lis2.append( 842)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                   'KEYBOARDING FUNDAMENTALS ':
        lis2.append(1871)
    elif request.GET['titlen'] == 'INTRODUCTION TO PARALEGAL STUDIES':
        lis2.append(1777)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                    'MANAGEMENT 310':
        lis2.append(1978)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                    'MANAGEMENT 615 INTERCULTURAL COMMUNICATION AND LEADERSHIP':
        lis2.append(1979)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                     'HOMELAND SECURITY MANAGEMENT 625 CRITICAL INFRUSTRUCTURE':
        lis2.append(1491)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                      'INTERMEDIATE ACCOUNTING II':
        lis2.append(1658)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                     'FOUNDATIONS OF LAW':
        lis2.append(1256)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                     'PUBH-770 SCIENTIFIC WRITING IN PUBLIC HEALTH':
        lis2.append(2479)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                      'PSYCHOPHARMOCOLOGY':
        lis2.append(2461)
    elif request.GET['titlen'] =='INTERVIEWING AND INTERROGATION':
        lis2.append(1685)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                       'CONCEPTS & APPS OF INFO TECH':
        lis2.append( 697)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                        'ENVM650-9040 ENVIRONMENTAL AND NATURAL RESOURCES ECONOMICS':
        lis2.append(1094)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                         'ONE-ON-ONE SPANISH':
        lis2.append(2232)
    elif request.GET['titlen'] =='HRMN 300, HUMAN RESOURCE MANAGEMENT (':
        lis2.append(1514)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                        'MARKETING PRINCIPLES':
        lis2.append(2000)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                         'INTO TO SOCIAL WORK AND THE HUMAN SERVICES':
        lis2.append(1690)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                          'BLUE CARD CERTIFICATION':
        lis2.append( 349)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                           'COMPUTING AND INFORMATION TECHNOLOGY':
        lis2.append( 695)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                           'THE NATURE OF MATHEMATICS':
        lis2.append(2797)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                            'ETHICS AND INTEGRITY':
        lis2.append(1113)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                             'ACCT 215 MICRO ACCOUNTING APPLICATIONS':
        lis2.append(73)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                              'MGMT 204 - HUMAN RELATIONS IN BUSINESS':
        lis2.append(2081)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                               'RECR  641 - MANAGING OPEN SPACE RESOURCES':
        lis2.append(2531)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                            'RECR  653 - COMMUNICATIONS AND ORGANIZATIONAL DECISION MAKING IN RPM':
        lis2.append(2532)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                            'DMBA 630 MARKETING & STRATEGY MANAGEMENT':
        lis2.append( 900)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                            'HUMAN RESOURCES MANAGEMENT':
        lis2.append(1564)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                            'ELECTRICITY':
        lis2.append( 970)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                            'LEGAL RESEARCH WORKSHOP':
        lis2.append(1934)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                             'CMRJ500 CRIMINAL JUSTICE ETHICS':
        lis2.append( 608)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                              'ORGAZATIONAL COMMUNICATION':
        lis2.append(2252)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                               'MCJ ORIENTATION - MJ600':
        lis2.append(2058)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                'MJ601 SURVEY OF CRIMINAL JUSTICE':
        lis2.append(2118)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                 'MJ650 CRIMINAL LAW AND PROCEDURE':
        lis2.append(2121)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                 'ORIENTATION TO GRADUATE STUDIES AT UMUC':
        lis2.append(2253)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                 'AMBA600':
        lis2.append( 191)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                 'SOCIAL WORK AND THE LAW':
        lis2.append(2644)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                  'ADVANCED BUSINESS WRITING':
        lis2.append( 120)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                   'GENERAL STUDIES 127 - UNIVERSAL STUDIES FOR SUCCESS':
        lis2.append(1326)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                    'HIST 303 - SECOND WORLD WAR':
        lis2.append(1441)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                     'POLI 325 - POLITICL PARTIES/ELECTNS':
        lis2.append(2337)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                      'PETER LEVINE PHD ON TRAUMA: HOW THE BODY RELEASES TRAUMA AND RESTORES GOODNESS SEMINAR':
        lis2.append(2307)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                      'ISSUES OF DRUG/ALCOHOL ABUSE':
        lis2.append(1829)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                       'FUNDAMENTALS OF ADDICTIONS':
        lis2.append(1287)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                       '100: KIDS CHARGED AS ADULTS: AT THE CROSSROADS OF PSYCHOLOGY, HUMAN DEVELOPMENT AND THE LAW':
        lis2.append(3)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                        'ORGANIC CHEMISTRY II':
        lis2.append(2236)
    elif request.GET['titlen'] =='ELEMENTARY CALCULUS':
        lis2.append(974)
    elif request.GET['titlen'] =='MATHEMATICS PREP/ MATH-080':
        lis2.append(2049)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                        'PERSONALIZED HEALTH FITNESS/ HLTH125':
        lis2.append(2303)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                         'GOTTMAN CLINICIAL TRAINING LEVEL 1':
        lis2.append(1367)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                          'GOTTMAN CLINICIAL TRAINING LEVEL 2':
        lis2.append(1368)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                           'GOTTMAN CLINICIAL TRAINING LEVEL 3':
        lis2.append(1369)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                            'WRITING A QUALITY PROSPECTUS PPPA8115':
        lis2.append( 290)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                             'K9 DECOY SCHOOL':
        lis2.append(1868)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                              'NUTRITION 100':
        lis2.append(2213)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                              'DOCUMENTARY THEORY AND PRACTICE':
        lis2.append( 903)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                             'STRATEGIC MANAGEMENT':
        lis2.append(2722)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                              'ROBERT F. BORKENSTEIN COURSE ON DUID: THE EFFECTS OF DRUGS ON HUMAN PERFORMANCE AND BEHAVIOR':
        lis2.append(2571)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                               'POLICE ADMINISTRATION':
        lis2.append(2341)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                               'LAW OF CORRECTIONS':
        lis2.append(1889)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                'SOSC-499-P02 GUIDED INDEPENDENT RESEARCH PROJECT':
        lis2.append(2669)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                'INTRODUCTION TO WRITING 101':
        lis2.append(1804)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                'AMERICAN ENGLISH LANGUAGE READING 930 - READ/NON-NATIVE SPEAKERS III':
        lis2.append( 196)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                 'THE ENRICHED LACTATION CONSULTANT TRAINING PROGRAM':
        lis2.append(2790)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                 'MJ620 CRIMINOLOGY':
        lis2.append(2120)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                 'ENVIRONMENTAL CHANGE SUSTAINABILITY':
        lis2.append(1088)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                  'GOVERNMENT 406 , GLOBAL TERRORISM':
        lis2.append(1372)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                   'GOVERNMET 457. AMERICAN FOREIGN RELATIONS':
        lis2.append(1377)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                  'SOCIOLOGY 322 - GANGS AND DRUGS':
        lis2.append(2656)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                   'CRJ598  SEMINAR IN FORENSICS':
        lis2.append( 818)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                    'ROBERT F.  BORKENSTEIN COURSE ON ALCOHOL AND HIGHWAY SAFETY: TESTING, RESEARCH AND LITIGATION':
        lis2.append(2570)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                    'ACTIVE ASSAILANT RESPONSE (CUSTOM COURSE)':
        lis2.append(88)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                     'ACTIVE ASSAILANT RESPONSE CUSTOM COURSE':
        lis2.append(90)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                     'ACTIVE ASSAILANT RESPONSE':
        lis2.append(87)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                      'ACTIVE ASSAILANT RESPONSE (CUSTOM)':
        lis2.append(89)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                       'SCIENCE, TECHNOLOGY, AND PROCEDURES IN FORENSIC INVESTIGATIONS':
        lis2.append(2587)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                        'CMRJ522 FORENSICS':
        lis2.append( 612)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                         'INTRO TO SECURITY MANAGEMENT':
        lis2.append(1714)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                          'ADVANCED ALICE TRAINING':
        lis2.append( 113)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                           'FI 823-601 DERIVATIVES AND RISK MANAGEMENT':
        lis2.append(1170)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                          'MGMT650- STAT MANAGERIAL DECISION MAKING':
        lis2.append(2103)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                           'NURS  348 - 001   ADULT PRACTICE':
        lis2.append(2181)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                            'NURS  308 - 001   PHARMACOLOGY':
        lis2.append(2180)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                             'JURIS DOCTOR DEGREE':
        lis2.append(1861)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                             'HIST-123 WES CIV & MODERN WORLD':
        lis2.append(1445)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                             'ENGL-210 INTRO TO FICTION POETRY DRAMA':
        lis2.append(1053)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                             'MGMT 564 PRODUCTIONS AND OPERATIONS MANAGEMENT':
        lis2.append(2088)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                              'SNIPER SUSTAINMENT COURSE/WINTER':
        lis2.append(2623)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                               'COUNTER SNIPER SUSTAINMENT COURSE/ WINTER':
        lis2.append( 751)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                               'POLICE  INTERROGATION':
        lis2.append(2340)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                'TOPICS AND TRENDS IN CRIMINAL JUSTICE':
        lis2.append(2822)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                 'CRJ598 SEX OFFENDERS AND SEX CRIMES':
        lis2.append( 819)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                  'LA 300: FOUNDATIONS FOR PROFESSIONAL SUCCESS':
        lis2.append(1873)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                 'THEORY AND PRACTICE OF LAW ENFORCEMENT, JUVENILE JUSTICE SYSTEM':
        lis2.append(2813)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                  'CJUS 315: THE AMERICAN CRIMINAL & CIVIL JUSTICE SYSTEMS':
        lis2.append( 568)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                   'ECONOMICS MANAGEMENT DECISIONS':
        lis2.append( 929)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                    '2015 NATIONAL INTERDICTION CONFERENCE':
        lis2.append(16)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                    '2015 NATION INTERDICTION CONFERENCE':
        lis2.append(15)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                     'CYBER SECURITY':
        lis2.append( 841)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                     'HOMELAND SECURITY TECHNOLOGY':
        lis2.append(1493)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                     'COACHING FOR MANAGERS':
        lis2.append( 632)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                     'MOTORCYCLE OPERATOR COURSE':
        lis2.append(2133)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                     'DYNAMIC CQC':
        lis2.append( 909)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                      'MJ675 INVESTIGATING DIFFERENCE':
        lis2.append(2124)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                      'INFORMATION SYSTEMS MANAGERS ISAS 600-9020 51413':
        lis2.append(1635)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                      'REDBACK ONE DYNAMIC CQC COURSE':
        lis2.append(2538)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                       'SCIENTIFIC EVIDENCE AND THE RIGHT TO CONFRONTATION':
        lis2.append(2588)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                      'BASIC EXPLOSIVE K9 HANDLERS COURSE WITH ODOR RECOGNITION TEST':
        lis2.append( 290)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                       'CISCO ROUTING & SWITCHING':
        lis2.append( 548)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                       'ADVANCED VEHICLE CONTRABAND CONCEALMENT':
        lis2.append( 156)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                        'CELLULAR RECORDS REVIEW AND ANALYSIS - 4 PARTS':
        lis2.append( 491)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                         'MAPPING CELL TOWERS':
        lis2.append(1995)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                          'SOCIOLOGY 101 INTRODUCTION TO SOCIOLOGY':
        lis2.append(2654)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                         'INFO SYSTEMS MGMT INTEGRATION ISAS 610 9021 51416':
        lis2.append(1620)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                          'BIOSTATISTICAL APPLICATION FOR PUBLIC HEALTH':
        lis2.append( 346)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                          'FOR585 ADVANCED SMARTPHONE FORENSICS':
        lis2.append(1230)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                           'HEALTH 100,  PRINCIPLE  HEALTH  LIVING':
        lis2.append(1402)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                           'CJMS 620 ISSUES IN CORRECTIONAL ADMINISTRATION':
        lis2.append( 560)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                            'PAD 530 PUBLIC PERSONNAL MANAGEMENT':
        lis2.append(2264)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                            'INTRODUCTION TO STATISTICS':
        lis2.append(1799)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                             'CRIMINOLOGY':
        lis2.append( 799)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                             'MULTI-SECTOR FINAL COURSE':
        lis2.append(2145)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                              'MOTORCYCLE NEW RIDER COURSE':
        lis2.append(2132)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                              'CJS/221 CULTURAL DIVERSITY IN CRIMINAL JUSTICE':
        lis2.append( 563)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                               'MOTORCYCLE SAFETY PROGRAM BEGINNERS MOTOR COURSE':
        lis2.append(2134)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                               'CCJS 370 RACE, CRIME, AND CRIMINAL JUSTICE':
        lis2.append( 472)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                               'CMST 301 DIGITAL MEDIA AND SOCIETY':
        lis2.append( 628)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                'CCJS 340 LAW ENFORCEMENT ADMINISTRATION':
        lis2.append( 466)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                'WRTG 101S INTRODUCTION TO WRITING':
        lis2.append(2912)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                 'INTRODUCTION TO SPEECH COMMUNICATION':
        lis2.append(1798)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                 "HE201-STRESS MANG'T":
        lis2.append(1399)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                 'BEHS 210 - INTRODUCTION TO SOCIAL SCIENCES':
        lis2.append( 307)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                  'PS 2703 INTERNET SALES AND SERVICE':
        lis2.append(2426)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                  'ATTC 4830 DIRECTED READINGS':
        lis2.append( 277)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                   'PS 3363 CONTRACT & SALES NEGOTIATION':
        lis2.append(2427)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                    'HRER 894: RESEARCH TOPICS':
        lis2.append(1504)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                     'COGNITIVE BEHAVIORAL THERAPY FOR POSTTRAUMATIC STRESS DISORDER':
        lis2.append( 636)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                      'PSAD302 INTRODUCTION TO PUBLIC SAFETY ADMINISTRATION':
        lis2.append(2430)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                       'NSCI362 ENVIRONMENTAL CHANGE AND SUSTAINABILITY':
        lis2.append(2177)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                      'LABOR RELATIONS HRMN 362':
        lis2.append(1878)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                       'PUBLIC SAFETY ISSUES PSAD 495':
        lis2.append(2503)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                        'BIOL 102 - BIOLOGY LAB':
        lis2.append( 331)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                         'INFORMATION SYSTEM DECISION MAKING':
        lis2.append(1627)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                          'CPB 24000 PUBLIC AND OCCUPATIONAL HEALTH FOR VETERINARY TECHNICIANS':
        lis2.append( 759)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                          'CONCEPTS OF EMERGENCY MANAGEMENT':
        lis2.append( 701)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                          'LS-515 LEADERSHIP IN THE PUBLIC SECTOR':
        lis2.append(1960)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                           'CHRONIC CARE PROFESSIONAL (CCP) CERTIFICATION':
        lis2.append( 537)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                          'ENVM647 ENVIRONMENTAL RISK ASSESSMENT':
        lis2.append(1093)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                           'CRIMINOLOGICAL THEORIES':
        lis2.append( 798)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                           'EFFECTIVE FINANCIAL AND OPERATIONAL DECISION MAKING':
        lis2.append( 958)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                            'INTRODUCTION TO PLANT SCIENCES':
        lis2.append(1779)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                            'EMGT 312\tSOCIAL DIMENSIONS OF DISASTER':
        lis2.append(1017)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                             'PERSONAL AND FAMILY FINANCE':
        lis2.append(2294)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                              'STRESS MANAGEMENT IN PUBLIC SAFETY ORGANIZATIONS':
        lis2.append(2734)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                               'PRACTICAL REASONING PHIL 110':
        lis2.append(2357)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                'CONCEPTS OF METEOROLOGY':
        lis2.append( 702)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                 'MGMT 561- FINANCIAL MANAGEMENT':
        lis2.append(2085)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                 'ANNUAL WEBCAST PASS':
        lis2.append( 220)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                'HUMAN BEHAVIOR AND SOCIAL':
        lis2.append(1545)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                'EFFECTIVE TREATMENT FOR CLUSTER B PERSONALITY DISORDERS':
        lis2.append( 961)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                'CMM103 - INTRODUCTION TO FILM':
        lis2.append( 605)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                 'GOVERNAMENTAL ACCOUNTING AND AUDITING UPDATE':
        lis2.append(1370)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                  'MAT 540 STATISTICAL CONCEPTS FOR RESEARCH':
        lis2.append(2014)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                   'BIOLOGY 103':
        lis2.append( 338)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                   'COST ACCOUNTING':
        lis2.append( 736)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                   'FEDERAL INCOME TAXATION I':
        lis2.append(1157)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                   'CONTROL STRESS/TENSION':
        lis2.append( 725)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                    'TORT LAW':
        lis2.append(2824)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                     'CRIMINAL INVESTIGATION':
        lis2.append( 780)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                     'INTRODUCTION TO THE CHANGE PROCESS':
        lis2.append(1801)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                      'INTRODUCTION TO ELECTRONIC MEDIA':
        lis2.append(1745)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                       'CMIS 111 7380 SOCIAL NETWORKING AND CYBERSECURITY BEST PRACTICES (2158)':
        lis2.append( 588)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                        'PUBLIC RELATIONS':
        lis2.append(2496)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                      'NHM 340 - COMMUNITY NUTRITION':
        lis2.append(2168)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                      'TRANSFORMATIVE LEADERSHIP IN DISRUPTIVE TIMES':
        lis2.append(2827)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                       'CQB-OFFENSIVE STRONGHOLD CLEARANCE':
        lis2.append( 769)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                        'PHA 6936 LITERATURE SURVEY (FORENSIC SCIENCE)':
        lis2.append(2313)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                        'AICPA - FOUNDATIONS IN GOVERNMENTAL ACCOUNTING:':
        lis2.append( 167)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                        '2-DAY TRAUMA CONFERENCE: THE BODY KEEPS SCORE-TRAUMA HEALING WITH BESSEL VAN DER KOLK, MD SEMINAR':
        lis2.append(8)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                         'GET WHAT YOU NEED THROUGH SUCCESSFUL NEGOTIATION STRATEGIES':
        lis2.append(1339)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                          'AMERICAN SIGN LANGUAGE III':
        lis2.append( 210)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                          '2015 CORE CONCEPTS COURSE':
        lis2.append(12)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                          'SHRMR PHR/SPHR CERTIFICATION PREP':
        lis2.append(2616)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                          'CRIMINAL JUSTICE ETHICS':
        lis2.append( 784)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                           'INFO TECH PROJECT MANAGEMENT':
        lis2.append(1622)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                           'POLICY AND ADVOCACY FOR IMPROVING POPULATION HEALTH':
        lis2.append(2343)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                            'MJ602  - PUBLIC POLICY AND CRIMINAL JUSTICE':
        lis2.append(2119)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                             'LABORTORY IN METEOROLOGY':
        lis2.append(1880)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                              'AICPA - PROFESSIONAL ETHICS':
        lis2.append( 169)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                               'FSA 103- FIRE INVESTIGATIONS & ANALYSIS':
        lis2.append(1271)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                               'CHEM 135 - GENERAL CHEMISTRY FOR ENGINEERS':
        lis2.append( 528)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                               'FI 827-601 VALUATION':
        lis2.append(1171)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                'BIO 130 INTRO TO ENVIRONMENTAL SCIENCE':
        lis2.append( 322)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                 '***NOT APPLICABLE***':
        lis2.append(2)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                  'HIST 101. AMERICAN HISTORY SINCE 1877':
        lis2.append(1436)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                  'ANATOMY FOR VETERINARY TECHNICIANS':
        lis2.append( 219)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                   'HISTORY 157':
        lis2.append(1452)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                   'INTERMEDIATE SPANISH I- SN 201':
        lis2.append(1666)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                    'CJMS 630 SEMINAR IN SECURITY MANAGEMENT':
        lis2.append( 561)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'ORIENTATION TO GRADUATE STUDIES UCSP615':
        lis2.append(2255)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'FAMILY NURSE PRACTITIONER 3':
        lis2.append(1144)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'SWIFT PROGRAMMING INTRODUCTION':
        lis2.append(2757)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'PRINCIPLES OF ACCOUNTING 2':
        lis2.append(2376)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'CMRJ 295':
        lis2.append( 606)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'ROPES THAT RESCUE  ADVANCED ANCHORING WORKSHOP':
        lis2.append(2574)
    elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                      'HES 310 - ISSUES HUMAN ENVIORNMENT SCIENCE':
        lis2.append(1427)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                       'FUNDAMENTALS OF LEADERSHIP AND MANAGEMENT IN PUBLIC PROCUREMENT': 1295, 'IT 111 INFORMATION LIT. FOR IT PROFESSIONALS': 1830,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                        'INVESTMENT VALUATION': 1812,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                        'FUNDAMENTAL OF LIBRARY RESEARCH': 1285,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                         'LOGIC FOR LEADERS': 1958,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                         'LEGAL WRITING': 1936,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                          'INTRODUCTION TO HOMELAND SECURITY HMLS 302': 1764,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                           'HANDLER INSTRUCTION AND TRAINING SEMINAR': 1390,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                            'ACADEMIC ELAW980': 40,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                            'SOWK7366- HISPANICS IN THE US: POLICY AND PROGRAMS': 2673,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                             'CJUS 325: PROFESSIONAL RESPONSE & ETHICS IN CRIMINAL JUSTICE': 569,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                             'THREAT ANALYSIS': 2817,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                              'QBUS 215: BUSINESS STATISTICS': 2513,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                              'CORECTIONAL ADMINISTRATION - 497': 730,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                               'HUMAN ANAT & PHYS 2': 1539,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                'HIST 289': 1440,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                 'COMPUTER AIDED DESIGN IN BIOENGINEERING': 678,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                  "CLASS: ARMORER'S COURSE - 103510": 573,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                   'NURSING ADMINISTRATION FIELD STUDY': 2191,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                   'LEGAL RESEARCH': 1933,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                   'LEADERSHIP IN A MULTICULTURAL SOCIETY': 1908,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                    'MEDIATION SKILLS': 2060,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                     'CQB OFFENSIVE STRONGHOLD CLEARANCE': 768,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                      'SENSATION AND PERCEPTION': 2606,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                       'MSAS 670 - ACCOUNTING AND INFORMATION SYSTEMS CAPSTONE': 2142,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                       'PUBLIC HEALTH AND WATER QUALITY': 2486,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                        'AMBA600 - MBA FUNDAMENTALS': 192,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                         'CONTEMPORARY LEGAL POLICY ISSUES': 716,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                         'PAYROLL ACCOUNTING': 2273,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                          'GLOCK ARMORERS COURSE': 1363,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                          'THIRD SEMESTER J.D. PROGRAM - CRIMINAL LAW; CONSTITUTIONAL LAW; LAW IN CONTEXT': 2816,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                           'PRINCIPLES OF FINANCIAL MANAGEMENT': 2386,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                            'MANAGING HEALTH CARE PERSONNEL': 1989,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                            'EDUCATION SEMINAR II': 953,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                            'LEGAL ASPECTS HEALTH CARE ADMINISTRATION': 1926,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                            "ID225-DISASTER, CRISIS AND EMERGENCY MANG'T": 1585,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                             'FIN 330 BUSINESS FINANCE': 1176, 'THEORECTICAL FRAMEWORKS AND ADVANCED LEADERSHIP': 2806,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                              'CRIMINAL PRACTICE & PROCEDURE': 793,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                              'BMGT 364 MANAGEMENT AND ORGANIZATION THEROY': 361,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                              'MGMT 790 - STRATEGIC MANAGEMENT CAPSTONE': 2102,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                              'MOUNTY SEMINAR GE200-2': 2136,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                               'GENERAL PHYSICS': 1319,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                               'COMMUNITY BASED NURSING': 665,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                'BCOM 321: BUSINESS COMMUNICATION': 300, 'MACHINE DESIGN': 1972,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                 'EFFECTIVE FINANCIAL AND OPERATIONAL DECISION MAKING (DMBA 620)': 959,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                 'PROJECT MANAGEMENT PMP (PROJECT MANGEMENT CERTIFICATION)': 2418,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                  'AICPA - GOVERNMENTAL ACCOUNTING AND REPORTING': 168,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                  'ILPA PRIVATE CREDIT SPECIALIST SERIES': 1608,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                  'EARTH SCIENCE': 915,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                   'ELEMENTARY SPANISH 101': 980,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                    'SYMPOSIUM IN THE SUN 2015': 2759,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                     'CRIME SCENE INVESTIGATION': 775,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                     'LEGAL AND ETHICAL PRINCIPLES IN HEALTH CARE': 1925,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                      'COMPUTER BASICS': 680
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                      , 'SCMT529 INTERNATIONAL TERRORISM': 2591,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                       'PARAMEDIC CERTIFICATE PROGRAM': 2267, 'PPPA9000': 2356,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                        'ACCOUNTING AND INFORMATION SYSTEMS CAPSTONE': 63,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                        'ENGLISH 281 - STANDARD ENGLISH AND GRAMMAR': 1067,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                         'AUTISM AND SENSORY PROCESSING DISORDERS': 282,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                          'ADVANCED ANCHORING ANALYSIS SEMINAR AND  BEYOND THE BARN FLOOR  TRIG AND PHYSICS COURSE': 114,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                          'WATERSHED PLANNING MANAGEMENT': 2866,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                          'CONSTITUTIONAL CRIMINAL PROCEDURE I': 705,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                          'INTRO TO COMPUTING SCIENCES - 54429 - CSIS 110 - D01': 1699,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                           'GES 220 - LAB AND FIELD TECHNIQUES FOR ENVIRONMENTAL SCIENCE': 1337,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                            'HUM/115 CRITICAL THINKING IN EVERYDAY LIFE': 1538,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                             'FIRE ALARM PREP': 1195,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                              'GENERAL PSYCHOLOGY - PSYC 102 - 407': 1323,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                               'OPTIVIEW CONTROL PANEL': 2234,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                'GRE PREPARATION': 1381,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                 'HOMELAND SECURITY MANAGEMENT (HSMN) SPECIALIZATION': 1490,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                  'STRATEGIC MANAGEMENT CAPTSTONE': 2725,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                   'MATH302 STATISISTICS': 2042,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                    'MJ661 - ORGANIZATIONAL MANAGEMENT': 2122,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                     "ELECTRICIAN'S EXAM PREP COURSE": 969,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                      'MGMT 566 INFORMATION MGMT & TECH': 2089,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                      'VEHICLE FIRE INVESTIGATION': 2854,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                       'HISTORY OF U.S. TO 1865': 1469,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                        'NURSING IN HEALTH AND ILLNESS': 2199,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                        'ENES 232 - THERMODYNAMICS': 1039,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                         'CYBER CRIME INVESTIGATION AND DIGITAL FORENSICS': 839,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                          'CYBERSPACE AND CYBERSECURITY (CSEC 610)': 846,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                          'GEN201 FOUNDATIONS FOR UNIVERSITY SUCCESS': 1313,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                           'APPLIED PSYCHOLOGY: JOB ANALYSIS': 235,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                            'EXPERT WITNESS TESTIMONY COURSE': 1138,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                             'WRITING 291': 2899,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                             'SWCL 755  ASSESSMENT OF COMMON CHILD MH DISORDERS': 2755,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                              'EMERGENCY RESPONSE & RECOVERY: EMGT 103': 1005,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                               'NEC ELECTRICAL CALCULATION AND MASTER EXAM PREP COURSE': 2157,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                'PHA 6936 SPECIAL TOPICS IN FORENSIC SCIENCE': 2314,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                 'MINDFULNESS STRESS REDUCTION': 2116,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                  'ENES 240 - SCIENTIFIC AND ENGINEERING COMPUTATION': 1040,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                  '12TH ANNUAL AUTISM CONFERENCE': 4,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                  'ORGANIZATION COMMUNICATIONS': 2237,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                   'CJUS 335: CRIME IN AMERICA': 570,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                    'DEVELOPING AND MANAGING RFPS IN THE PUBLIC SECTOR': 874,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                     'CJUS 345: CRIMINAL BEHAVIOR AND VICTIMOLOGY': 571,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                      '3-DAY CQB OFFENSIVE STRONGHOLD CLEARANCE COURSE': 24,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                      'TERRORISM & EMERGENCY MGMT: EMGT 202': 2781,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                       'INTRODUCTION TO WEB DESIGN': 1803,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                       'WILDLIFE MANAGEMENT': 2884,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                        'HUMAN ANAT & PHYS I - BIOL 212 - 406': 1540,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                        'PEDIATRIC/COMMUNITY NURSING': 2289,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                         'MGMT670- STRATEGIC MANAGEMENT CAPSTONE': 2104,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                         'CROSS CULTURAL PSYCHOLOGY': 821,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                         'ISSUES IN CRIMIAL JUSTICE LEADERSHIP': 1826,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                         'BEHAVORIAL FINANCE': 304,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                          'HSM 497 HOMELAND SECURITY & EMERGENCY MANAGEMENT CAPSTONE': 1528,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                           'NURSING CARE OF SPECIFIC POPULATIONS II: MATERNAL/CHILD NURSING': 2194,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                            'MASTER EXAM PREP': 2007,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                             'ENGLISH 112 TECHNICAL WRITING': 1062,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                              'FRANCES GLESSNER LEE HOMICIDE INVESTIGATION SEMINAR': 1258,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                               'SECURITY ASSESSMENT': 2594,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                'EARLY CHILDHOOD EDUCATION': 914,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                'ISSUES IN CRIMINAL JUSTICE LEADERSHIP': 1828,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                 'AMBA610 - THE MANAGER IN  ORGANIZATIONS AND SOCIETY': 193,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                  'STAT MANAGERIAL DECISION MAKING': 2711,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                  'EDD 9002 DISSERTATION PROJECT': 941,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                   'INTRODUCTION TO GEOGRAPHY (SS111)': 1754,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                    'FIRE OFFICER II': 1212,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                    'INDUSTRIAL HYGIENE': 1616,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                     'BSCOM/100': 386,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                      'FINANCIAL MANAGEMENT FOR HEALTHCARE ORGANIZATIONS': 1184,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                       'POLI 327-INTEREST GROUPS AND LOBBY': 2338,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                        'FDIC FULL CONFERENCE': 1153,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                        'FEMALE ENFORCERS': 1164,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                        'ROPES THAT RESCUE TEAM SKILLS RESCUE WORKSHOP': 2575,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                         'BMGT  365 - ORGANIZATIONAL LEADERSHIP': 354,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                          'ECON 203, PRINCIPLES OF MICROECONOMICS': 918,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                          'PROJECT MANAGEMENT PROFESSIONAL (PMP) CERTIFICATION PREP - PMC004': 2419,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                          'READING 095': 2523,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                           'COUNSELING TECHNIQUES': 746,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                            'PERSONAL SKILLS RESCUE WORKSHOP': 2298,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                            'SPANISH BEGINNER 1': 2684,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                             'FIREHOUSE EXPO  FIREHOUSE CONFERENCE': 1222,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                              'AICPA ANNUAL WEBCAST PASS': 170,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                              'NEGOTIATIONS AND CONFLICT MANAGEMENT': 2160,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                               'SOCIAL WORK EXAM PREP COURSE': 2645,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                'CRJU 777 CAPSTONE': 820,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                'BUSINESS ORGANIZATIONS': 438,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                 'CONCEPTS IN HOMELAND SECURITY (HSMN610)': 700,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                  'BUSINESS WRITING': 442,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                  'SAFETY INVESTMENT AND PARTNERING': 2582,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                'COUN 8660 - SOCIAL CHANGE LEADERSHIP AND ADVOCACY FOR COUNSELING PROFESSIONALS': 740,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                            'ISE5200-HACKING TECHNIQUES AND INCIDENT RESPONSE': 1818,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                  'FSCS 601 LEGAL ISSUES IN HIGH TECHNOLOGY CRIME': 1278,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                    'NATIONAL ELECTRICAL CODE (BLDG256)': 2151,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                             'EMPLOYEE TRAINING AND DEVELOPMENT HRMN406': 1024,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                      'MANAGEMENT AND ORGANIZATION THEORY': 1982,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                     'MARRIAGE AND FAMILY COUNSELING': 2001,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                      'GENERATORS&EMERGENCY SYSTEMS': 1329,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                       'ROLLING SURVEILLANCE': 2572,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                       'BUSINESS STATISTICS': 440,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                        'REMINGTON ARMORERS CERTIFICATION': 2548,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                         'AICPA GOVERNMENTAL ACCOUNTING AND AUDITING UPDATE CONFERENCE EAST':173,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                 'AMBA 650, MARKETING MANAGEMENT AND INNOVATION': 190,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                    "HISTORY 377- US WOMEN'S HISTORY 1870-2000": 1453,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                         'CASES IN EXECUTIVE DECISION MAKING': 457,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                            'FINITE MATH 106': 1191,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                            'FUNDAMENTALS OF ELECTRICAL WIRING, BLDG150 & BLDG150L': 1291,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                              'PRINCIPLES OF SUSTAINABILITY': 2392,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                               'INTERMEDIATE SPANISH II': 1667,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                             'PCN-662A PRACTICUM/INTERNSHIP 1': 2283,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                          'VM 22300 PHARMACY CLINICAL MENTORSHIP': 2862,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                       'CJA/385 - CRIMINAL JUSTICE POLICY ANALYSIS & PROGRAM EVALUATION': 556,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                     'MUSIC APPRECIATION': 2149,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                      'INTL 631 CRIMINAL INTELLIGENCE ANALYSIS': 1687,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                      'INTRODUCTION TO THE BUILDING TRADES, BLDG130': 1800,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                 'ENGLISH 102 - CRIT READ/WRITE/RESEARCH': 1058,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                       'INTL613 INTELLIGENCE AND HOMELAND SECURITY': 1689,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                             'MOUNTAIN RESCUE WORKSHOP': 2135,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                  'INDIVIDUAL ASSESSMENT': 1613,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                           'INVESTIGATIVE STATEMENT ANALYSIS': 1810,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                  'CRIMINAL INTERDICTION SEMINAR': 779,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                             'ACCOUNTING INFORMATION SYSTEMS': 68,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                   'SPANISH 102': 2682,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                          'HOSTAGE NEGOTIATION PHASE I AND II': 1496,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                     'CRIMINAL JUSTICE PROCESS': 787,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                            'HEALTHCARE ADMINISTRATION CAPSTONE': 1421,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                'BMGT 495 STRATEGIC MANAGEMENT': 367,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                            'PHL 1010 CRITICAL THINKING': 2324,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                            'MBA 630: THE ECONOMICS OF MANAGEMENT DECISIONS': 2053,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                           'ORGANIZATIONAL LEADERSHIP': 2245,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                             'THEORIES OF CRIMINAL BEHAVIOR': 2808,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                        'PSYCHOLOGY AND THE LEGAL SYSTEM I': 2455,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                          'RESIDENTIAL ELECTRICAL WIRING (BLDG250) AND (BLDG250L)': 2564,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                             'POLI 334-JUDICIAL PROCESS': 2339,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                            'GOVERNMENTAL FINANCIAL MANAGEMENT AND CONTROL': 1376,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                           'CCJS 380 ETHICAL BEHAVIOR IN CRIMINAL JUSTIE': 474,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                        'INVESTIGATING TRAINING SEMINAR': 1808,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                      'ETHICS AND STANDARDS OF CONDUCT FOR VIRGINIA CPAS - 2012 EDITION (CPE)': 1117,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                    'HEALTH STRESS/TENSION': 1419,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                   'EMGT 106 TECHNOLOGY IN EMGT': 1013,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                               'AICPA GOVERNMENTAL ACCOUNTING AND AUDITING UPDATE CONFERENCE (GAAC) EAST': 172,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                              'PHI - 210  CRITICAL THINKING': 2317,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'RECENT AMERICA: 1945 TO THE PRESENT': 2529,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                              'ACC-620 FINANCIAL REPORTING II': 43,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                          'INTRO TO EPIDEMIOLOGY': 1703,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                             'ORGANIZATIONAL CULTURE': 2241,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                           'CERTIFIED NURSING ASSISTANT CLASSROOOM': 507,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                   'ENGLISH 110': 1061,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                         'INVESTMENTS': 1813,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                            'INTRODUCTION TO GRADUATE LIBERAL STUDIES': 1757,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                            'HUMAN RESOURCE MANAGEMENT HRMN 300': 1561,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                             'ETHICS AND STANDARDS OF CONDUCT FOR VIRGINIA CPAS - 2014 EDITION (CPE)': 1119,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                             'RELATIONAL DATABASE': 2541,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                              'THE CORRECTIONAL PROCESS': 2785,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                              'CRIMINAL PATROL WORKSHOP': 791,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                               'POLS 612 ADMINISTRATIVE PROCESS': 2351,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                               'ACCOUNTING 221': 51,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                               'GLOBAL HEALTH DIPLOMACY': 1348,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                               'BUSINESS COMMUNICATION': 420,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                'HISTORICAL AND PHILOSOPHICAL PERSPECTIVES ON EDUCATION': 1448,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                'LIFE SPAN DEVELOPEMENT': 1953, 'ANTHROPOLOGY': 227,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                 'CORRECTIONS AND INCARCERATION': 735,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                  'BUSINESS 530 MANAGERIAL FINANCE': 416,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                   'ENCE320 INTRODUCTION TO PROJECT MANAGEMENT': 1037,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                    'CONTACT AND CONTROL TECHNIQUES & TACTICS': 711,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                     'CHILD DEATH INVESTIGATION': 532,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                     'SO 201 - CRIMINOLOGY': 2626,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                      'HEALTH CARE QUALITY MANAGEMENT AND OUTCOMES ANALYSIS': 1410,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                       'RHM 303 - MGN QUALITY IN HOSPITALITY INDUSTRY': 2565,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                        'ENGLISH 364 AFRICAN AMERICAN AUTHORS FROM 1900 TO PRESENT': 1072,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                         'WEB DESIGN TECHNOLOGY': 2876,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                          'GFOA 108TH ANNUAL CONFERENCE': 1340,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                           'DISSERTATION COURSE': 894,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                           'DATABASE APPLICATIONS': 853,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                           'HUMAN BEHAVIOR SND THE SOCIAL ENVIRONMENT': 1547,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                           'SHRM CERTIFICATION PREP COURSE': 2611,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                            'TRAUMA, PTSD, GRIEF & LOSS  TRAUMA TREATMENTS & INTERVENTIONS': 2834,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                           'HEALTH ILLNESS AND HEALING': 1413,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                           'ACCT 305: INTERMEDIATE ACCOUNTING': 76,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                            'CSEC 661 DIGITAL FORENSIC INVESTIGATIONS': 826,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                            'PROFESSIONAL DEVELOPMENT': 2401,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                             '2017 AMERICAN PAYROLL CONGRESS': 17,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                             'MGMT 630 ORGANIZATIONAL THEORY AND BEHAVIOR': 2095,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                             'ADVANCED LEGAL PRACTICES': 138,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                             'ECONOMICS ECON 203': 924,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                             'CERTIFIED NURSING ASSISTANT CLINICAL': 508,
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                              'NET 3250 BUSINESS COMMUNICATION':
   #     lis2.append(2162)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                              'PUBLIC MANAGEMENT':
   #     lis2.append(2488)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                              'BUSINESS 600':
   #     lis2.append( 417)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                               'ETHICS AND STANDARDS OF CONDUCT FOR VIRGINIA CPAS - 2013 EDITION (CPE)':
   #     lis2.append(1118)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                               'MJ665 SURVEY RESEARCH: VICTIMS AND THE COMMUNITY':
   #     lis2.append(2123)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                'ORIENTATION TO GRADUATE STUDIES AT UMUC (UCSP 615)':
   #     lis2.append(2254)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                 'FAMILY THERAY':
   #     lis2.append(1146)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                  'COMPUTER IDES120  IDES 120L':
   #     lis2.append( 683)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                   'LEADERSHIP & HUMAN BEHAVIOR':
   #     lis2.append(1901)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                    'PSY 105 INTRO TO PSYCHOLGY':
   #     lis2.append(2435)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                     'IFSM 300  (INFORMATION SYSTEMS IN ORGANIZATIONS)':
   #     lis2.append(1593)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                      'SOCIAL PROBLEMS AND ISSUES': 2634, 'CMRJ524 ORGANIZED CRIME':
   #     lis2.append( 613)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                       'COMPUTERS /APPLICATIONS /CONSTRUCTION':
   #     lis2.append( 692)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                       'NURS 350 GLOBAL HEALTH ISSUES':
   #     lis2.append(2182)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                        'EMGT 304 EMERGENCY RESPONSE PREPARDNESS':
   #     lis2.append(1015)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                         'ADDICTIONS COUNSELING'
   #     lis2.append(: 91)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                          'CRIMINAL PRACTICE CLINICE':
   #     lis2.append( 794)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                          'CYB 610  CYBERSPACE AND  CYBERSECURITY FOUNDATIONS':
   #     lis2.append( 838)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                           'ILPA LEVEL II':
   #     lis2.append(1604)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                           'CRJ - 220  ETHICS AND LEADERSHP IN CRIMINAL JUSTICE':
   #     lis2.append( 810)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                           'EMGT 105 HAZARD MITIGATION AND PREP':
   #     lis2.append(1012)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                            'BIO-101-301':
   #     lis2.append( 328)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                             'GENERAL PHYSICS: ELECTRICITY AND MAGNETISM':
   #     lis2.append(1321)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                              'GFOA 109TH ANNUAL CONFERENCE':
   #     lis2.append(1341)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                               'WEB 3070 ADVANCED SPREADSHEET APPLICATIONS':
   #     lis2.append(2869)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                    'MS640 SECURITY: HOME AND COUNTRY':
   #     lis2.append(2141)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'GFOA 120 TH ANNUAL CONFERENCE':
   #     lis2.append(1344)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                      'COMPUTER SYSTEMS ARCHITECTURE (ITEC 625)':
   #     lis2.append( 690)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                       'GFOA 18TH ANNUAL GOVERNMENTAL GAAP UPDATE LIVE STREAMING SEMINAR':
   #     lis2.append(1346)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                        'COUNTER AMBUSH TACITCS FOR LAW ENFORCEMENT':
   #     lis2.append( 749)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                         'HEALTH INFORMATION ADMIN CAPSTONE':
   #     lis2.append(1415)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                         'ITMG 516 INTRODUCTION TO DATA ANALYTICS/BUSINESS DATA MINING':
   #     lis2.append(1849)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                          'CMRJ 303 CRIMINOLOGY':
   #     lis2.append( 607)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                           'COMM 2010 MASS MEDIA AND SOCIETY':
   #     lis2.append( 650)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                            'BUS 100 INTRO TO BUISNESS':
   #     lis2.append( 395)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                            'CELLEBRITE CERTIFIED PHYSICAL ANALYST (CCPA) COURSE - ADVANCED':
   #     lis2.append( 489)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                             'PATTERN ANAYLSIS': 2272, 'COUNTER AMBUSH TACTICS FOR LAW ENFORCEMENT':
   #     lis2.append( 750)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                              'BASIC COURSE FOR GENERAL INDUSTRY':
   #     lis2.append( 288)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                               'LGST 340 - CONTRACT LAW':
   #     lis2.append(1943)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                'THE INDIVIDUAL AND SOCIETY':
   #     lis2.append(2793)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                 'WORLD HISTORY: A COMPARATIVE SURVEY FROM A.D TO 1500 TO THE PRESENT':
   #     lis2.append(2896)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                  'NURS 360 HEALTH ASSESSMENTS':
   #     lis2.append(2183)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                  'FARSI BEGINNER 2':
   #     lis2.append(1149)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                   'WEB 3090 DIGITAL PRESENTATIONS':
   #     lis2.append(2870)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                    'HEALTH ASSESSMENT WITH LAB':
   #     lis2.append(1404)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                     'ELEMENTARY KOREAN 101':
   #     lis2.append( 977)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                     'CONTEMPORY BUBINESS':
   #     lis2.append( 718)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                      'ENG 103 - CRIT READ/WRITE/RESEARCH AT WORK':
   #     lis2.append(1043)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                       'TEACHING AND LEARNING ABOUT CULTURAL DIVERSITY THROUGH INTERGROUP DIALOGUE; SEXUAL IDENTITY':
   #     lis2.append(2769)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                        'CPB 15001 CLINICAL PATHOLOGY FOR VETERINARY TECHNICIANS':
   #     lis2.append( 758)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                         'COUN 8551 - PREPARING FOR DISSERTATION': 739, 'WORLD PREHISTORY AND ARCHAEOLOGY':
   #     lis2.append(2897)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                         'SOFTWARE ENGINEERING':
   #     lis2.append(2665)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                          'TECH 274 - WEB CMS AND CONTENT STRATEGY':
   #     lis2.append(2774)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                           'MANAGEMENT PHILOSOPHY AND PRACTICE':
   #     lis2.append(1985)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                            'INFO TECH IN SOCIAL WORK SOWK 240':
   #     lis2.append(1621)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                             'INFORMATION SYSTEMS ANALYSIS, MODELING, AND DESIGN (ITEC 630)':
   #     lis2.append(1631)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                              'EMPLOYEE TRAINING AND DEVELOPMENT':
   #     lis2.append(1023)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                               'ENCE215 ENGINEERING FOR SUSTAINABILITY':
   #     lis2.append(1036)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                'INTERMEDIATE PROGRAMMING':
   #     lis2.append(1665)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                 'ADVANCED APPLICATIONS OF RESEARCH FOR EVIDENCE-BASED PRACTICE':
   #     lis2.append( 115)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                  'LEGAL ASPECTS OF PUBLIC PROCUREMENT ONLINE':
   #     lis2.append(1929)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                   'PRINCIPLES OF AIR QUALITY MANAGEMENT':
   #     lis2.append(2378)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                    'FRENCH 102':
   #     lis2.append(1264)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                     'INTRODUCTION TO MENTAL HEALTH':
   #     lis2.append(1771)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                      'PHYSICAL GEOLOGY WITH LAB':
   #     lis2.append(2330)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                       'EYE MOVEMENT DESENSITIZATION AND REPROCESSING PART 2':
   #     lis2.append(1142)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                        'LGST 495 - ADVANCED LEGAL PRACTICES':
   #     lis2.append(1944)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                         'BMGT 110 INTRODUCTION TO BUSINESS AND MANAGEMENT':
   #     lis2.append( 356)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                          'BSBD 641 BIOSECURITY AND BIOTERRORISM':
   #     lis2.append( 384)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                           'EMERGING LEADERS':
   #     lis2.append(1010)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                            'RESEARCH METHODS IN EMERGENCY AND DISASTER MANAGEMENT':
   #     lis2.append(2559)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                             'CHANGE MANAGEMENT: LEADING SUCCESSFUL TRANSFORMATION':
   #     lis2.append( 518)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                              'LEADERSHIP IN THE PUBLIC SECTOR':
   #     lis2.append(1910)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                              'EXCEL PIVOT TABLES IN DEPHT, POWERPIVOT, AND DATA ANALYSIS FUCTIONS AND TIPS':
   #     lis2.append(1132)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                               'BUSINESS 502 SERVANT LEADERSHIP':
   #     lis2.append(415)
   # elif request.GET['titlen'] =='CLINICAL THINKING':
   #     lis2.append( 580)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                'ISE6440: ADVANCED NETWORK FORENSIC ANALYSIS':
   #     lis2.append(1819)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                 'CMSP105 - SMALL GROUP COMMUNICATION':
   #     lis2.append( 624)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                  'NURSING RESEARCH AND EVIDENCE BASED PRACTICE':
   #     lis2.append(2205)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                   'HISTORY AFRICAN AMERICAN TO 1865':
   #     lis2.append(1459)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                    'GENERAL PHYSICS II - PHYS 262':
   #     lis2.append(1320)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                    'TEAM DYNAMICS AND RESEARCH METHODOLOGY':
   #     lis2.append(2771)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                     'ENVIRONMENTAL BIOLOGY':
   #     lis2.append(1086)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                     'SOWK8257- ADVANCED SOCIAL WORK FIELD EDUCATION':
   #     lis2.append(2674)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                      'CBT FOR ANXIETY- CORE 2':
   #     lis2.append( 460)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                       'LE STREET SURVIVAL / TACTICAL MEDICINE INSTRUCTOR COURSE � PENSACOLA, FL':
   #     lis2.append(1898)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                        'INTRODUCTION TO NETWORKING':
   #     lis2.append(1773)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                         'METHODS OF TEACHING ENGLISH TO SPEAKERS OF OTHER LANGUAGE':
   #     lis2.append(2075)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                          'STRATEGIC FINANCIAL MANAGEMENT':
   #     lis2.append(2720)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                           'STATISTICS FOR MANAGERIAL DECISION MAKING':
   #     lis2.append(2715)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                            'ARH 151- INTRO TO VISUAL ARTS':
   #     lis2.append( 248)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                             'HEALTH DATA MANAGEMENT':
   #     lis2.append(1411)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                              'DATABASE MANAGEMENT SYSTEMS - 54510 - CSIS 325 - D01':
   #     lis2.append( 856)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                               'INTRODUCTION TO COLLEGE WRITING':
   #     lis2.append(1734)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                               'COMM 390 - WRITING FOR MANAGERS':
   #     lis2.append( 652)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                'LGST 320 - CRIMINAL LAW AND PROCEDURES':
   #     lis2.append(1942)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                'SOWK7159- ADVANCED INTEGRATIVE SEMINAR III':
   #     lis2.append(2672)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                 'HEALTH FITNESS/NUTRITION WEIGHT MANAGEMENT':
   #     lis2.append(1412)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                  'GOVERNMENTAL ACCOUNTING, FINANCIAL REPORTING AND BUDGETING':
   #     lis2.append(1375)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                   'BIOLOGY 102':
   #     lis2.append( 337)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                               'AICPA NATIONAL GOVERNMENTAL ACCOUNTING AND AUDITING UPDATE CONFERENCE (GAAC) EAST':
   #     lis2.append( 174)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                    'GREAT MILITARY PHILOSOPHERS':
   #     lis2.append(1382)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                     'AR-15 CARBINE ARMORER':
   #     lis2.append( 239)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                      'ART APPRECIATION':
   #     lis2.append( 255)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                      'LA 400 AMERICAN VISION AND VALUES':
   #     lis2.append(1874)
   # elif request.GET['titlen'] == 'ADVANCED PHYSIOLOGY AND PATHOPHYSIOLOGY':
   #     lis2.append( 140)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                       'FRAUD EXAMINATION':
   #     lis2.append(1261)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                       'PRINCIPLES OF ECONOMICS I':
   #     lis2.append(2380)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                        'PUBLIC POLICY ANALYSIS AND PLANNING':
   #     lis2.append(2494)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                        'EMST 105 - EMERGENCY MEDICAL TECHNICIAN BASIC':
   #     lis2.append(1026)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                        'ACCOUNTING 320-0 FEDERAL INCOME TAX I':
   #     lis2.append( 57)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                               'ALCOHOL AND DRUG COUNSELING':
   #     lis2.append(181)
   # elif request.GET['titlen'] == 'FUNDAMENTALS OF MICROBIOLOGY':
   #     lis2.append(1297)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                          'DESIGN IDES221 IDES 221L':
   #     lis2.append(869)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                           'IDS 804 INFORMATION LITERACY':
   #     lis2.append(1588)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                           'RADIATION HAZARDS AND PROTECTION':
   #     lis2.append(2521)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                            'TRANSFORMING TRAUMA WITH EMDR':
   #     lis2.append(2828)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                             'ASSESSMENT AND EVALUATION IN ESOL CLASSROOM':
   #     lis2.append( 270)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                              'ENGLISH 311 17TH- AND 18TH- CENTURY BRITISH LITERATURE':
   #     lis2.append(1071)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                               'DYNAMICS':
   #     lis2.append( 910)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                'BECKER CPA REVIEW COURSE':
   #     lis2.append( 301)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                 'EN 101-ENGLISH COMPOSITION':
   #     lis2.append(1029)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                  'EYE MOVEMENT DESENSITIZATION AND REPROCESSING':
   #     lis2.append(1141)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                   'RECOVERY PRACTICES IN EMERGENCY MANAGEMENT':
   #     lis2.append(2530)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                    'MANAGEMENT 307':
   #     lis2.append(1977)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                     'HUMAN RESOURCES':
   #     lis2.append(1562)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                     'BUILDING CONSTRUCTION FOR FIRE PRETECTION':
   #     lis2.append( 391)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                      'PRE ALEGBRA/STATICS':
   #     lis2.append(2358)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                       'HUMAN RESOURCES 300':
   #     lis2.append(1563)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                        'INTRODUCTION TO SECURITY FUNDAMENTALS':
   #     lis2.append(1791)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                         'BEHS 220 - DIVERSITY AWARENESS':
   #     lis2.append( 309)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                          'INTERVIEWING/INVESTIGATING':
   #     lis2.append(1686)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                          'EMGT 210  HEALTH CARE FOR EMGT':
   #     lis2.append(1014)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                           'INTRO TO AFRICAN AMERICAN STUDIES':
   #     lis2.append(1692)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                            'MH683 INFORMATION MANAGEMENT':
   #     lis2.append(2106)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                             'CRITICAL CARE EMERGENCY MEDICAL TRANSPORT PROGRAM':
   #     lis2.append(805)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                              'BASIC TACTICAL OPERATIONS MEDICAL SUPPORT COURSE':
   #     lis2.append( 297)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                               'DIGITAL CIRCUITS & SYSTEM LAB - ENEE 245':
   #     lis2.append( 880)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                'INTRO TO THE DEAF COMMUNITY - ASLS106':
   #     lis2.append(1719)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                'NATIONAL INTERDICTION CONFERENCE':
   #     lis2.append(2154)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                 'FRENCH II, PART II':
   #     lis2.append(1266)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                  'LEADERSHIP AND QUALITY AND SAFETY':
   #     lis2.append(1903)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                  'EXCL 301 - LEARNING ANALYSIS':
   #     lis2.append(1133)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                   'INFRASTRUCTURE IN HOMELAND SECURITY':
   #     lis2.append(1638)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                    'ETHICS AND CULTURAL DIVERSITY IN MENTAL HEALTH AND WELLNESS':
   #     lis2.append(1112)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                     'HCAD 8518':
   #     lis2.append(1398)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                     'POLS 611 POLICY ANALYSIS':
   #     lis2.append(2350)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                      'SOCIAL AND BEHAVIORIAL SCIENCES':
   #     lis2.append(2629)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                      'BMGT 339 INTRODUCTION TO FEDERAL CONTRACTING':
   #     lis2.append( 359)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                       'LETTERS THAT WORK: EFFECTIVE BUSINESS CORESPONDENCE':
   #     lis2.append(1938)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                        'CMIS 111 SOCIAL NETWORK AND CYBERSECURITY BEST PRACTICE.':
   #     lis2.append( 589)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                         'WRTG 394 - ADVANCED BUSINESS WRITING':
   #     lis2.append(2919)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                          'CULTURAL GEOGRAPHY 102':
   #     lis2.append( 834)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                           'ADVANCE SKILLS COURSE':
   #     lis2.append( 106)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                            'FIRE INVESTIGATION AND ANALYSIS':
   #     lis2.append(1207)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                            'GLOBAL PUBLIC RELATIONS':
   #     lis2.append(1352)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                             'RESEARCH METHOD IN CRIMINAL JUSTICE':
   #     lis2.append(2555)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                              'NCEA ADVANCED CRIMINAL PATROL SEMINAR':
   #     lis2.append(2156)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                               'MATH 083, INTERMEDIATE ALGEBRA':
   #     lis2.append(2025)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                'EDUC625 INSTRUCTIONAL DESIGN IN ONLINE LEARNING':
   #     lis2.append( 952)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                'EXPLORING ETHICAL CHALLENGES IN THE THERAPEUTIC RELATIONSHIP AND COUNSELING ENVIRONMENT':
   #     lis2.append(1139)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                'MATH 107 - COLLEGE ALGEBRA':
   #     lis2.append(2030)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                 'COMPUTATIONAL METHODS':
   #     lis2.append( 677)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                  'CDL 019 24 HR CDL BASIC SKILLS AND REFRESHER COURSE':
   #     lis2.append( 482)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                   'GROUP COUNSELING':
   #     lis2.append(1384)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                    'MVA APPROVED MOTORCYCLE SAFETY COURSE: RIDING ACADEMY':
   #     lis2.append(2150)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'ADVANCED TEAM SKILLS WORKSHOP':
   #     lis2.append( 152)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                     'CRISIS ACTION PLANNING':
   #     lis2.append( 800)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                      'PUBLIC SAFETY PLANNING':
   #     lis2.append(2505)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                       'INTRODUCTION TO GRAD LIBRARY RESEARCH SKILLS':
   #     lis2.append(1756)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                        'FSE 350 - FIRE ARSON & EXPLOSION INVESTIGATION I':
   #     lis2.append(1280)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                        'FSE 230 - FIRE PREVENTION ORGINIZATION & MANAGEMENT':
   #     lis2.append(1279)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                        'ADVANCED ROADSIDE INTERVIEW TECHNUIQUES':
   #     lis2.append( 148)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                         'ADVANCED UNDERCOVER TECHNIQUES AND SURVIVAL':
   #     lis2.append( 155)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                          'CDL-DIL REFRESHER COURSE':
   #     lis2.append( 485)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                         'RESEARCH METHODS IN HOMELAND SECURITY':
   #     lis2.append(2560)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                          'BLDG 252/252L COMMERCIAL ELECTRICAL WIRING':
   #     lis2.append( 348)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                           'ETHIC IN INFORMATION TECHNOLOGY':
   #     lis2.append(1102)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                            'MENTAL HEALTH, WELLNESS, AND HEALTH CARE INTEGRATION':
   #     lis2.append(2071)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                             'INTRODUCTION TO KEYBOARDING':
   #     lis2.append(1767)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                              'ENGLISH COMPOSITION':
   #     lis2.append(1074)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                              'ELEMENTRAY SANISH 101':
   #     lis2.append(l985)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                               'MATH 082, INTRODUCTORY ALGEBRA':
   #     lis2.append(2024)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                              'GFOA 111TH ANNUAL CONFERENCE':
   #     lis2.append(1342)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                               'HAZARD RISK AND VULNERABILITY ASSESMENT':
   #     lis2.append(1392)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                               'LAW OFFICE ADMIN':
   #     lis2.append(1890)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                               'INTERACTIVE AUTHORING 1':
   #     lis2.append(1650)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                'CONSTITUTIONAL GOVERNMENT AND FREE ENTERPRISE':
   #     lis2.append( 707)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                'LISTENING TO MUSIC':
   #     lis2.append(1955)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                'HSMN 630 RESILIENCE PLANNING AND PREPAREDNESS FOR DIASTER RESPONSE AND RECOVERY':
   #     lis2.append(1533)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                 'RULES AND TIMING OF DEATH DISTRIBUTIONS':
   #     lis2.append(2578)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                'FIRE INSPECTOR III':
   #     lis2.append(1204)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                 'GVPT 408 COUNTERTERRORISM':
   #     lis2.append(1388)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                  'AASP201 INTRODUCTION TO AFRICAN AMERICAN STUDIES':
   #     lis2.append( 36)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                   'HEALTH':
   #     lis2.append(1401)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                  'COURSE:CDL014- CDL- DIL REFESHER COURSE':
   #     lis2.append( 756)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                    'DOMESTIC RELATIONS':
   #     lis2.append( 905)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                     'ADVANCED ROADSIDE INTERVIEW COURSE':
   #     lis2.append( 145)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                     'FOUNDATIONS FOR GRADUATE STUDY  (NURS - 6001N - 25)':
   #     lis2.append(1248)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                      'BUILDING CODES AND STANDARDS':
   #     lis2.append( 390)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                      'HMLS 406 - LEGAL AND POLITICAL ISSUES OF HOMELAND SECURITY':
   #     lis2.append(1480)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                       'AMERICAN HISTORY 1865 - PRESENT':
   #     lis2.append( 200)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                       'FSA 201 FIRE & EMERGENCY SERVICE ADMINISTRATION':
   #     lis2.append(1272)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                        'CCJS 352 DRUGS AND CRIME':
   #     lis2.append( 471)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                         'CHEETAH CERTIFIED PROJECT MANAGER':
   #     lis2.append( 524)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                          'COMM 390 WRITING FOR MANAGERS':
   #     lis2.append( 653)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                           'BI 117 STUDY OF THE HUMAN BODY':
   #     lis2.append( 317)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                            'EDMG503 EMERGENCY AND DISASTER PLANNING AND MANAGEMENT':
   #     lis2.append( 945)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                             'GUN LAW IN MARYLAND':
   #     lis2.append(1387)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                              'COURSE: CDL112- CDL B P&S---24 HOURS BASIC SKILLS AND REFRESHER COURSE':
   #     lis2.append( 755)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                               'ECONOMICS FOR DECISION MAKING':
   #     lis2.append( 926)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                               'ETHICS AND PROFESSIONAL CONDUCT FOR VIRGINIA CPAS ONLINE-2016 EDITION':
   #     lis2.append(1114)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                 'PSYCH 320- PSYCHOLOGICAL ASSESSMENTS':
   #     lis2.append(2446)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                 'SFT064 BEGINNERS MOTORCYCLE SAFETY COURSE':
   #     lis2.append(2610)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                  'EMERGENCY AND DISASTER THEORY':
   #     lis2.append( 998)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                                  'WORKPLACE BULLYING, RELIGIOUS DIVERSITY, ABUSE REPORTING':
   #     lis2.append(2893)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                                   'CURRICULUM DESIGN AND ASSESSMENT':
   #     lis2.append( 837)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                                    'EDMG515 HAZARD MITIGATION AND RESILIENT COMMUNITIES':
   #     lis2.append( 946)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                                     'ENTREPRISE DESKTOP SUPPORT TECHNICIAN':
   #     lis2.append(1083)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                                      'SPANISH LESSONS':
   #     lis2.append(2690)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                        'FSA 101 FIRE PROTECTION SYSTEMS':
   #     lis2.append(1270)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                     '2017 NATIONAL INTERDICTION CONFERENCE':
   #     lis2.append(18)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                        'FSA109- GIS & TECHNOLOGY FOR FIRE SERVICE':
   #     lis2.append(1275)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                         'MENTAL HEALTH EMERGENCIES':
   #     lis2.append(2070)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                          'ANTH 351 ANTHROPOLOGY IN FORENSIC INVESTIGATIONS':
   #     lis2.append( 226)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                          'HOMELAND SECURITY':
   #     lis2.append(1487)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                          'HRMN 302 - ORGANIZATIONAL COMMUNICATION':
   #     lis2.append(1515)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                            'UMD MCAT PREPARATORY PROGRAM':
   #     lis2.append(2841)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                             'BUSI-561: LEGAL ISSUES IN BUSINESS':
   #     lis2.append( 412)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                               'STRATEGIC PURCHASING AND LOGISTICS':
   #     lis2.append(2730)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                'HUMAN RESOURCES MGMT IN PUBLIC':
   #     lis2.append(1566)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                'ADVANCED UNDERCOVER TECHNIQUES & SURVIVAL':
   #     lis2.append( 154)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                 'FIRE PROTECTION HYDRAULIC & WATERFLOW':
   #     lis2.append(1217)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                   'SPREADSHEET APPLICATIONS':
   #     lis2.append(2703)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                   'MATH PREP': 2038, 'COUN 8336 CRISIS TRAUMA':
   #     lis2.append( 738)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                   'REC 342 FACILITY DESIGN':
   #     lis2.append(2527)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                     'BUS 310':
   #     lis2.append( 397)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                     'BMGT 485 - LEADERSHIP FOR THE 21ST CENTURY':
   #     lis2.append( 365)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                     'FUNDAMENTALS OF NETWORKING':
   #     lis2.append(1298)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                       'GRIEF, LOSS AND TRANSITION':
   #     lis2.append(1383)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                       'PROJECT MANAGEMENT FOR FMP CERTIFICATION MGT-632-11366':
   #     lis2.append(2415)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                        'ADVANCED ROADSIDE INTERVIEW TECHNIQUES FOR PATROL OFFICERS':
   #     lis2.append( 147)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                         'IDENTIFYING ORGANIZATIONAL LIABILITIES AND CRIME':
   #     lis2.append(1587)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                          'CDL 020 24 HR CDL BASIC SKILLS AND REFRESHER COURSE':
   #     lis2.append( 483)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                           'MGMT 585 HUMAN RESOURSE MANAGEMENT':
   #     lis2.append(2090)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                                                           'SEMINAR ON VIOLENT CRIME':
   #     lis2.append(2604)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                            'FSA 205 EMS OPERATIONS':
   #     lis2.append(1273)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                             'EXECUTIVE PROTECTION TRAINING 2 DAY SEMINAR':
   #     lis2.append(1137)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                              'BIOLOGY 130':
   #     lis2.append( 341)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                              'ADVANACED ROAD SIDE INTERVIEW CLASS':
   #     lis2.append( 103)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                               'ADVANCED ROADSIDE INTERVIEW TECHNIQUES':
   #     lis2.append( 146)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                               'INTELLIGENCE AND HOMELAND SECURITY':
   #     lis2.append(1646)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                 'FIRE PROTECTION HYDRAULICS & WATERFLOW':
   #     lis2.append(1219)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                'STRATEGIC DECISION MAKING':
   #     lis2.append(2719)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                 'WORDS AT WORK: ENHANCE YOR VOCABULARY TO ADVANCE YOUR CAREER':
   #     lis2.append(2892)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                  'HOME INSPECTION PRE-LICENSURE (CPD323)':
   #     lis2.append(1484)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                    'BLDG 184 SOLAR PV DESIGN AND INSTALLATION':
   #     lis2.append( 347)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                    'ORGANIZATIONAL THEORY AND DEVELOPMENT':
   #     lis2.append(2251)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                     'INTRODUCTION TO POLITICAL SCIENCE':
   #     lis2.append(1780)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                      'EN 101A,TECH OF RDNG & WRTG':
   #     lis2.append(1030)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                         'USING THE BODY TO HEAL TRAUMA: INTEGRATING SELF-REGULATION AND SOMATIC EXPERIENCIN INTERVENTIONS':
   #     lis2.append(2851)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                        'SECURITY FUNDAMENTALS':
   #     lis2.append(2595)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                         'ETHICS':
   #     lis2.append(1110)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                          'LSAT PREP - IN PERSON':
   #     lis2.append(1961)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                           'CYBERSECURITY FUNDAMENTALS':
   #     lis2.append( 845)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                                                                           'INTRODUCTION TO PROBABILITY THEORY':
   #     lis2.append(1782)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                             'IT 514 CONTEMPORARY ISSUES IN INFORMATION TECHNOLOGY':
   #     lis2.append(1831)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                              'INTRO TO COMPUTERS AND INFO PROCESSING':
   #     lis2.append(1698)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                               'DEFENSIVE HANGUN I':
   #     lis2.append( 864)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                'SYSTEM INTEGRATION AND TEST':
   #     lis2.append(2761)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                  'INTRO TO MODERN EAST ASIA':
   #     lis2.append(1709)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                  'LABOR RELATIONS':
   #     lis2.append(1877)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                   'METHODS RESEARCH EVD BASED':
   #     lis2.append(2076)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                    'HISTORY AFRICAN AMERICAN SINCE 1865':
   #     lis2.append(1458)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                    'FIRE INVESTIGATION I':
   #     lis2.append(1208)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                    'WRTG 391 - ADVANCED RESEARCH WRITING':
   #     lis2.append(2915)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                      'POPULATION FOCUSED NURSING PRACTICE':
   #     lis2.append(2352)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                       'WORD 2016 - PART 1':
   #     lis2.append(2887)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                       'PROJECT COST ACCOUNTING AND ECONOMICS':
   #     lis2.append(2410)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                        'FORENSIC AND INVESTIGATIVE ACCOUNTING':
   #     lis2.append(1237)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                          'CERTIFIED SOCIAL MEDIA INTELLIGENCE EXPERT (CSMIE)':
   #     lis2.append( 510)
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                           'PRINCIPLES OF ACCOUNTING':
   #     lis2.append(2375)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                           'SAFETY IN THE WORK PLACE':
   #     lis2.append(2581)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                            'LATIN AMERICAN HISTORY':
   #     lis2.append(1882)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                             'INFORMATION TECHNOLOGY IN EMERGENCY MANAGEMENT':
   #     lis2.append(1637)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                           'FRESHMAN FIRST SEMESTER MECHANICAL ENGINEERING TRACK':
   #     lis2.append(1267)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                               'GDES 116 - DIGITAL TOOLS FOR VISUAL ARTS':
   #     lis2.append(1309)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                                                                                               'TRANSITION TO PRO NSG PRAC':
   #     lis2.append(2829)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                'FROM PRISON TO HOME: THE PSYCHOLOGICAL CHALLENGES OF RE-ENTRY':
   #     lis2.append(1268)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                                  'ACT FOR ADOLESCENTS':
   #     lis2.append(83)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                                                                                                                                   'SPEECH FUNDAMENTALS':
   #     lis2.append(2698)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                   'NURS 691: ORGANIZATION THEORY: APPLICATION TO HEALTH SERVICES MANAGEMENT':
   #     lis2.append(2185)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                    'HY 1120 AMERICAN HISTORYII':
   #     lis2.append(1582)
   # elif request.GET['titlen']  ==                                                                                                                                                                                                                                                                                                                    "SONS OF LIBERTY GUN WORKS 3 DAY AR15 ADVANCED ARMORER'S COURSE":
   #     lis2.append(2667)
   # elif request.GET['titlen']   ==                                                                                                                                                                                                                                                                                                                                                                                                                                    'HISTORY 395- HISTORICAL WRITING':
   #     lis2.append(1454)
   #
   # elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                  'EDU 599 EDUCATION CAPSTONE':
   #     lis2.append(949)
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                        'CAPSTONE PROJECT': 454,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                         'HVAC ELECTRICITY': 1575,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                         'SOCIAL SCIENCES ADVANCED COMPOSITION': 2637,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                         'EXCEL I': 1131,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                      'CFA DECEMBER LEVEL 1 REVIEW CLASS- PREMIUM PLUS IN PERSON CLASS & 3-DAY REVIEW': 514,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                          'ACCT 424 ADVANCED ACCOUNTING': 78,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                           'ADVANCED CALCULUS 2': 121,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                            'SHRM EMPLOYMENT LAW & LEGISLATIVE CONFERENCE': 2612,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                            'BMAL 501; STRATEGIC LEADERSHIP & MANAGEMENT': 350,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                             'BMGT 496, BUSINESS ETHICS AND SOCIETY': 368,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                              'HSMN 625 CRITICAL INFRASTRUCTURES': 1532,
# elif request.GET['titlen'] ==                                                                                                                                                                                                                                                                                                                                                                                                                                  "REMINGTON 870 ARMORER'S CLASS THROUGH TRITON TRAINING GROUP": 2545,
#
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'ITEC  610 - INFORMATION TECHNOLOGY FOUNDATIONS': 1838,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'CERAMICS': 496,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'ADOLESCENT DEVELOPMENT': 100,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'ELEMENTS OF STATISTICS MA 117': 989,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'NURSING HEALTH AND ILLNESS III': 2198,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'COMMUNICATING, PROBLEM SOLVING, AND LEADING IN PROFESSIONAL FIELDS': 659,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'GENERAL RIGGING AND TEAM SKILLS WORKSHOP': 1324,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                       'ELEM SPANISH I - SPAN 101': 973,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                       'WRITING 393': 2900,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                        'INTERPRETATION OF GEOGRAPHIC IMAGERY': 1683,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                        'MRKT 310 MARKETING PRINCIPLES': 2137,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                        'CMRJ698 COMPREHENSIVE EXAMINATION IN CRIMINAL JUSTICE': 614,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         'DIGITAL MEDIA & SOCIETY': 882,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                          'WATER BASED FIRE PROTECTION SYSTEMS DESIGN': 2864,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                           'POPULATION-FOCUSED NURSING PRACTICUM': 2354,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                            'ORGANIZATIONAL  RESEARCH AND THEORY': 2238,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'GDES 212 - PUBLICATION DESIGN W/IN DESIGN': 1310,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'ACT FOR MINDFULNESS AND TRAUMA': 85,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'MEDICAL AND LEGAL INVESTIGATIONS OF DEATH': 2061,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'BIOLOGY 107': 339,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'BUSINESS STRATEGY & POLICY': 441,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'MILH510 STUDIES IN U.S. MILITARY HISTORY': 2115,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                'NRSG 790: METHODS FOR RESEARCH AND EVIDENCE BASED PRACTICE': 2173,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                 'SEMINAR ON GANGS AND CRIME': 2603,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'LSTD 302': 1962,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'INFORMATION SYSTEMS': 1630,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                   'HVAC2': 1581,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'WORD 2016 - PART 2': 2888,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'HAZARDS GOVERNANCE': 1394,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'SWEN 603 � MODERN SOFTWARE METHODOLOGIES': 2756,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                     'MAT-097-15 - INTRODUCTORY ALGEBRA': 2015,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                      'INTRODUCTION TO FORENSICS': 1750,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'NRSG 780: HEALTH PROMOTION AND POPULATION HEALTH': 2171,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'CCJ2 421-PRINCIPLES OF DIGITAL ANALYSIS-COST-$867': 461,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                       'MA-206A ELEMENTRY STATISTICS': 1969,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                        'ORG THEORY  AND BEHAVIOR': 2235,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                         'PRINCIPLE OF ECONOMICS': 2370,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                          'QUANTITATIVE METHODS': 2516,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                           'FORENSICS': 1241,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                            'STANDARDS FOR GENERAL INDUSTRY': 2708,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                             'STRATEGIC PLANNING': 2726,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'CRJ 310 LAW ENFORCEMENT OPERATIONS AND MANAGEMENT': 813,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'BMAL-500: ORGANIZATIONAL BEHAVIOR': 353,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                'HVAC': 1574,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'DAP-159-A1P  UAS (DRONE) FLIGHT SCHOOL': 849,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'HRMN 367 - ORGANIZATIONAL CULTURE': 1518,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         'CFA LEVEL 2 WEEKLY ONLINE CLASS AND REVIEW': 515,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'WORD 2016 - PART 3': 2889,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   'COMPUTER LITERACY': 684,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'CAPL 398A CAREER PLANNING MANAGEMENT': 452,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'ETHICS IN THE INFORMATION AGE': 1122,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'SWCL 744 PSYCHOPATHOLOGY': 2753,
#                                                                                                                                                                                                                                                                                  'INTERNSHIP IN COUNSELING PSYCHOLOGY  (CPSY 699-D)': 1681,
#                                                                                                                                                                                                                                                                                   'CERTIFIED NURSING ASSISTANT (CNA)': 506,
#                                                                                                                                                                                                                                                                                    'MATH  106 - 6980   FINITE MATHEMATICS': 2019,
#                                                                                                                                                                                                                                                                                     'CSEC 662 CYBER INCIDENT ANALYSIS AND RESPONSE': 827,
#                                                                                                                                                                                                                                                                                     'RESCUE FROM VEHICLES IN WATER': 2550,
#                                                                                                                                                                                                                                                                                      'COUPLES AND FAMILY THERAPY': 754,
#                                                                                                                                                                                                                                                                                       'ACT FOR BEGINNERS': 84,
#                                                                                                                                                                                                                                                                                        'PUBLIC RELATIONS THEORY AND PRACTICE': 2498,
#                                                                                                                                                                                                                                                                                         'CONSTRUCTION SAFETY': 710,
#                                                                                                                                                                                                                                                                                          'ADVANCED ACCOUNTING': 108,
#                                                                                                                                                                                                                                                                                           'AB 520 - CONCEPTS AND PRINCIPLES IN BEHAVIOR ANALYSIS': 37,
#                                                                                                                                                                                                                                                                                           'IFSM 201 - CONCEPTS & APPS OF INFO TECH': 1591,
#                                                                                                                                                                                                                                                                                            'PRINCIPLE OF EMERGENCY SERVICES': 2371, 'INTRO TO GEOGRAPHIC INFO SYS': 1704,
#                                                                                                                                                                                                                                                                                            'SPEECH': 2695,
#                                                                                                                                                                                                                                                                                            'CMIT 291 INTRODUCTION TO LINUX': 594,
#                                                                                                                                                                                                                                                                                            'ITL 350 ADV. DIGITAL LITERACY SKILLS': 1848,
#                                                                                                                                                                                                                                                                                            'EM MODULE 2A: EMERGENCY MANAGEMENT COORDINATION': 992,
#                                                                                                                                                                                                                                                                                             'HI 201 HISTORY OF THE UNITED STATES': 1432,
#                                                                                                                                                                                                                                                                                              'FORENSIC SCIENCE I': 1239,
#                                                                                                                                                                                                                                                                                              'ISE6460: MALWARE ANALYSIS AND REVERSE ENGINEERING': 1820, 'ITEC  626 - 5121   INFORMATION SYSTEMS INFRASTRUCTURE': 1839,
#                                                                                                                                                                                                                                                                                               'BIOLOGY 398J THE ROLE OF NUTRITION IN CARE AND HEART DISEASE': 343,
#                                                                                                                                                                                                                                                                                               'FIRE BEHAVIOR AND COMBUSTION': 1199,
#                                                                                                                                                                                                                                                                                                'ACCOUNTING AND FINANCIAL REPORTING': 62,
#                                                                                                                                                                                                                                                                                                 'CCJS 341, CRIMINAL INVESTIGATION': 467,
#                                                                                                                                                                                                                                                                                                 'BUSI 504 LEADING ORGANIZATIONAL CHANGE': 407,
#                                                                                                                                                                                                                                                                                                  'THE HUMAN BODY': 2792,
#                                                                                                                                                                                                                                                                                                  'COMMUNICATIONS': 664,
#                                                                                                                                                                                                                                                                                                  'PERSONAL WEALTH MANAGEMENT': 2299, 'MATH 012 - INTERMEDIATE ALGEBRA': 2022,
#                                                                                                                                                                                                                                                                                                   'REMINGTON 870 PUMP SHOTGUN ARMORERS COURSE': 2546,
#                                                                                                                                                                                                                                                                                                    'TVRA 140 - VIDEO EDITING': 2836,
#                                                                                                                                                                                                                                                                                                     'CONTEMPORARY ISSUES IN SECURITY MANAGEMENT': 715,
#                                                                                                                                                                                                                                                                                                     'BMGT 487 PROJECT MANAGEMENT I (3)': 366, 'ELEMENTARY GERMAN I': 976,
#                                                                                                                                                                                                                                                                                                      'GEOL 101': 1331,
#                                                                                                                                                                                                                                                                                                       'ARTH 334 UNDERSTANDING MOVIES': 259,
#                                                                                                                                                                                                                                                                                                        'HUMAN BODY': 1549,
#                                                                                                                                                                                                                                                                                                        'WORLD CULTURES II': 2895,
#                                                                                                                                                                                                                                                                                                         'MA110- SURVEY OF COLLEGE MATH': 1970,
#                                                                                                                                                                                                                                                                                                          'VICTIMOLOGY (CCJS 360)': 2857,
#                                                                                                                                                                                                                                                                                                          'CIS 101 - INFORMATION SYSTEMS AND TECHNOLOGY': 538,
#                                                                                                                                                                                                                                                                                                           'EN 406 SHAKESPEARE STUDIES': 1032, 'HUMAN RELATIONS IN THE PUBLIC SECTOR': 1558,
#                                                                                                                                                                                                                                                                                                            'FUNDAMENTALS OF REFRIGERATION/LAB (BLDG 170 AND BLDG 170L)': 1302,
#                                                                                                                                                                                                                                                                                                             'PROJECT MANAGEMENT FUNDAMENTALS XCPD-480': 2416, 'CRITICAL THINKING AND CREATIVE PROBLEM SOLVING': 809, 'GDES 218 - GRAPHIC DESIGN FOR THE WEB': 1311,
#                                                                                                                                                                                                                                                                                                              'SYSTEMS & THEORIES OF PSYCHOTHERAPY': 2762,
#                                                                                                                                                                                                                                                                                                               'HVAC TECHNICIAN DEVELOPMENT': 1579,
#                                                                                                                                                                                                                                                                                                                'INTRODUCTION TO FIRE PREVENTION': 1748, 'SUBSTANCE USE DISORDER ASSESSMENT AND TREATMENT CERTIFICATE PROGRAM': 2738,
#                                                                                                                                                                                                                                                                                                                 'EM MODULE 1A: FOUNDATIONS OF EMERGENCY MANAGEMENT': 991,
#                                                                                                                                                                                                                                                                                                                  'BUSI 502 SERVANT LEADERSHIP': 406,
#                                                                                                                                                                                                                                                                                                                  'MGMT 590 STRATEGY AND COMPETITIVE ADVANTAGE': 2091, 'EN 101, TECH OF READING & WRITING': 1027,
#                                                                                                                                                                                                                                                                                                                  'LEGAL ASPECTS OF SAFETY AND HEALTH': 1930,
#                                                                                                                                                                                                                                                                                                                   'ADVANCED GEOGRAPHIC INFORMATION SYSTEMS': 132,
#                                                                                                                                                                                                                                                                                                                    'HHS 105 - PHARMACY TECH CERTIFICATE': 1429, 'PPPA-9000 - DISSETATION': 2355, 'FARSI BEGINNER 2.3': 1150,
#                                                                                                                                                                                                                                                                                                                    'SOCIAL PROBLEMS IN CONTEMPORARY SOCIETY': 2635,
#                                                                                                                                                                                                                                                                                                                     'MARKETING & STRATEGY MANAGEMENT IN THE GLOBAL WORKPLACE': 1997,
#                                                                                                                                                                                                                                                                                                                      'CIS 170 INFORMATION TECHNOLOGY IN CRIMINAL JUSTICE': 541, 'FRAUD DETECTION AND DETERRENCE': 1260,
#                                                                                                                                                                                                                                                                                                                      'PSYC 354 CROSS-CULTURAL PSYCHOLOGY': 2442,
#                                                                                                                                                                                                                                                                                                                       'ITEC 640 � INFORMATION TECHNOLOGY PROJECT MANAGEMENT': 1840,
#                                                                                                                                                                                                                                                                                                                        'SOLAR PV DESIGN AND INSTALLATION': 2666,
#                                                                                                                                                                                                                                                                                                                        'FUNDAMENTALS OF COMPUTER TROUBLESHOOTING': 1290,
#                                                                                                                                                                                                                                                                                                                        'DECISION MAKING': 861,
#                                                                                                                                                                                                                                                                                                                        'RESEARCH AND EVIDENCE BASED PRACTICE': 2551,
#                                                                                                                                                                                                                                                                                                                         'GENERALIST SOCIAL WORK PRACTICE II': 1328,
#                                                                                                                                                                                                                                                                                                                          'CMIT350 INTERCONNECTING CISCO DEVICES.': 604,
#                                                                                                                                                                                                                                                                                                                          'HISTORY 495- SENIOR THESIS IN HISTORY': 1457,
#                                                                                                                                                                                                                                                                                                                           'INFORMATION RESOURCES MANAGEMENT': 1625,
#                                                                                                                                                                                                                                                                                                                            'APPLIED DATA ANALYSIS IN CRIMINAL JUSTICE': 233, 'TEAM PROJECT SEMINAR III': 2772,
#                                                                                                                                                                                                                                                                                                                            'HVAC ELECTRICITY/LAB (BLDG 172 AND BLDG 172L)': 1577,
#                                                                                                                                                                                                                                                                                                                             'CMIT320 NETWORK SECURITY': 603,
#                                                                                                                                                                                                                                                                                                                              'CULTURAL DIVERSITY IN HEALTH CARE': 833,
#                                                                                                                                                                                                                                                                                                                               'FORP 6150:  INVESTIGATIVE PSYCHOLOGY': 1242,
#                                                                                                                                                                                                                                                                                                                               'INTRODUCTION TO MATLAB': 1770,
#                                                                                                                                                                                                                                                                                                                                'INTRODUCTION TO CORRECTIONS': 1737,
#                                                                                                                                                                                                                                                                                                                                'EN 363 AFRICAN AMERICAN AUTHORS FROM THE COLONIAL ERA TO 1900': 1031,
#                                                                                                                                                                                                                                                                                                                                 'EM MODULE 3A: LEADERSHIP AND MANAGEMENT': 993,
#                                                                                                                                                                                                                                                                                                                                  'E-COMMERCE MANAGEMENT': 912,
#                                                                                                                                                                                                                                                                                                                                  'ELEM FRENCH I - FREN 101': 972,
#                                                                                                                                                                                                                                                                                                                                   'HEAT AND MASS TRANSFER': 1425,
#                                                                                                                                                                                                                                                                                                                                    'THEORY AND PRACTICE IN CRIMINAL JUSTICE': 2812, 'ASSETS PROTECTION AND LOSS PREVENTION MANAGEMENT': 273,
#                                                                                                                                                                                                                                                                                                                                    'LAW AND RELIGION': 1887,
#                                                                                                                                                                                                                                                                                                                                     'DAP-158-B4': 848,
#                                                                                                                                                                                                                                                                                                                                      'MICRO MASTERS IN PROJECT MANAGEMENT & DATA SCIENCE (UC SAN DIEGO)': 2111,
#                                                                                                                                                                                                                                                                                                                                       'ENGLISH COMPOSITION II': 1077,
#                                                                                                                                                                                                                                                                                                                                        'LBSC 631 ACHEIVING ORGANIZATIONAL EXCELLENCE.': 1893,
#                                                                                                                                                                                                                                                                                                                                         'MATH 115 - PRE-CALCULUS': 2034,
#                                                                                                                                                                                                                                                                                                                                         'LICENSING EXAM PREP': 1951,
#                                                                                                                                                                                                                                                                                                                                         'FEM 138': 1162, 'FEM 144': 1163,
#                                                                                                                                                                                                                                                                                                                                          'INFA 610 COMPUTER SECURITY, SOFTWARE ASSURANCE, HARDWARE ASSURANCE, AND SECURITY MANAGEMENT': 1617,
#                                                                                                                                                                                                                                                                                                                                           'SKILLS AND PRACTICE IN HUMAN SERVICES': 2620,
#                                                                                                                                                                                                                                                                                                                                            'BUSX 301': 445,
#                                                                                                                                                                                                                                                                                                                                            'PEDIATRIC DYSPHAGIA': 2288,
#                                                                                                                                                                                                                                                                                                                                            'BUS 611-- PRINCIPLES AND PRACTICES OF LEADERSHIP I': 400,
#                                                                                                                                                                                                                                                                                                                                             'DFC640: ADVANCED FORENSICS': 875,
#                                                                                                                                                                                                                                                                                                                                             'OL539 PERSONALITY AND LIFE SPAN IN THE WORKPLACE': 2226,
#                                                                                                                                                                                                                                                                                                                                              'ADVANCED COUNTER AMBUSH FOR LAW ENFORCEMENT': 125,
#                                                                                                                                                                                                                                                                                                                                               'FEM 135': 1161,
#                                                                                                                                                                                                                                                                                                                                                'EMERGENCY MEDICAL TECHNICIAN CERTIFICATION COURSE': 1004,
#                                                                                                                                                                                                                                                                                                                                                 'LEAD 610 TEAM LEADERSHIP & CONFLICT RESOLUTION': 1899,
#                                                                                                                                                                                                                                                                                                                                                  'SC200-04: DISCOVERING SCIENCE-CURRENT ISSUES IN A CHANGING WORLD': 2585,
#                                                                                                                                                                                                                                                                                                                                                  'VALUES AND ETHICS': 2852,
#                                                                                                                                                                                                                                                                                                                                                   'PSYCOPHARMACOLOGY': 2463,
#                                                                                                                                                                                                                                                                                                                                                   'SOCIOLOGY OF GENDER': 2657,
#                                                                                                                                                                                                                                                                                                                                                    'FEM 104': 1158,
#                                                                                                                                                                                                                                                                                                                                                     'CMIS 102 - INTRODUCTION TO PROBLEM SOLVING AND ALGORITHM DESIGN': 587,
#                                                                                                                                                                                                                                                                                                                                                     'CYBR 556 ETHICAL HACKING': 847,
#                                                                                                                                                                                                                                                                                                                                                      'POPULATION HEALTH AND INTERPROFESSIONAL COLLABORATION PRACTICUM': 2353,
#                                                                                                                                                                                                                                                                                                                                                      'CMIT  369 INSTALLING AND CONFIGURING WONDOWS SERVER': 592,
#                                                                                                                                                                                                                                                                                                                                                       'LEADING ORGANIZATIONS AND PEOPLE': 1918,
#                                                                                                                                                                                                                                                                                                                                                        'ADVANCED COUNTER AMBUSH TACTICS FOR LAW ENFORCEMENT (CUSTOM COURSE)': 127,
#                                                                                                                                                                                                                                                                                                                                                         'STRATEGIC PLANNING IN HOMELAND SECURITY': 2728, 'ISSUES IN CRIMINAL JUSTICE': 1827,
#                                                                                                                                                                                                                                                                                                                                                         'FINANCIAL REPORTING & ANALYSIS': 1188,
#                                                                                                                                                                                                                                                                                                                                                         'INTRODUCTION TO LAW': 1768,
#                                                                                                                                                                                                                                                                                                                                                         'CERTIFICATE IN APPRECIATIVE INQUIRY FOR STRENGTHS-BASED LEADERSHIP AND INNOVATION IN PUBLIC AND NONPROFIT SECTORS': 498,
#                                                                                                                                                                                                                                                                                                                                                          'KNES 131 V - PHYSICAL EDUCATION ACTIVITIES: COED; BEGINNING JOGGING': 1872,
#                                                                                                                                                                                                                                                                                                                                                          'CCJS 380 - ETHICAL BEHAVIOR IN CRIMINAL JUSTICE': 473,
#                                                                                                                                                                                                                                                                                                                                                           'MBA 630: LEADING IN THE MULTICULTURAL GLOBAL ENVIRONMENT': 2052,
#                                                                                                                                                                                                                                                                                                                                                            'MAT 1301': 2012,
#                                                                                                                                                                                                                                                                                                                                                             'COLLEGE ALEGEBRA': 641,
#                                                                                                                                                                                                                                                                                                                                                             'METEROLOGY: INTRO WEATHER': 2074,
#                                                                                                                                                                                                                                                                                                                                                              'ECONOMICS OF DIASTER': 930,
#                                                                                                                                                                                                                                                                                                                                                              'SOCY325: THE SOCIOLOGY OF GENDER: STUDY OF GENDER INEQUALITY AND CULTURE IN CONTENPORARY AMERICA': 2663,
#                                                                                                                                                                                                                                                                                                                                                               'HIST 228 - WOMEN IN WESTERN WORLD': 1439,
#                                                                                                                                                                                                                                                                                                                                                               'RESEARCH METHODS - AB551': 2557,
#                                                                                                                                                                                                                                                                                                                                                                'FIRE SERVICE ADMINISTRATION': 1221,
#                                                                                                                                                                                                                                                                                                                                                                 'COMMUNICATION THEORY': 663,
#                                                                                                                                                                                                                                                                                                                                                                  'ART HISTORY': 256,
#                                                                                                                                                                                                                                                                                                                                                                   'CJS 211- ETHICS IN CRIMINAL JUSTICE': 562,
#                                                                                                                                                                                                                                                                                                                                                                    'FEM 115': 1159,
#                                                                                                                                                                                                                                                                                                                                                                     "ILPA MEMBER'S CONFERENCE WORKSHOPS": 1605,
#                                                                                                                                                                                                                                                                                                                                                                     'FIRE INVESTIGATION TECH': 1209,
#                                                                                                                                                                                                                                                                                                                                                                      'EMPLOYMENT LAW FOR BUSINESS': 1025,
#                                                                                                                                                                                                                                                                                                                                                                       'IT 530 APPLIED DATABASE SYSTEMS': 1834,
#                                                                                                                                                                                                                                                                                                                                                                        'DEMYSTIFYING RACE AND HEALING PROCESS': 867,
#                                                                                                                                                                                                                                                                                                                                                                         'FIELD EXPERIENCE': 1172,
#                                                                                                                                                                                                                                                                                                                                                                          'BUS 402': 398,
#                                                                                                                                                                                                                                                                                                                                                                           'DEVELOPING AND MANAGING REQUESTS FOR PROPOSALS': 872,
#                                                                                                                                                                                                                                                                                                                                                                            'ADVANCED COUNTER AMBUSH TACTICS FOR LAW ENFORCEMENT': 126,
#                                                                                                                                                                                                                                                                                                                                                                           'CJUS 310: JUVENILE JUSTICE': 567,
#                                                                                                                                                                                                                                                                                                                                                                            'FINC 321 - FUNDAMENTALS OF BUILDING WEALTH': 1189,
#                                                                                                                                                                                                                                                                                                                                                                             'ARTS - PHYSICS 110': 262,
#                                                                                                                                                                                                                                                                                                                                                                              'IT 518 SYSTEMS ENGINEERING AND INTEGRATION': 1832,
#                                                                                                                                                                                                                                                                                                                                                                               'PSYC  100 - INTRODUCTION TO PSYCHOLOGY': 2437,
#                                                                                                                                                                                                                                                                                                                                                                                'SOCIOLOGY 300 AMERICAN SOCIETY': 2655,
#                                                                                                                                                                                                                                                                                                                                                                                'PC OPERATING SYSTEMS': 2275,
#                                                                                                                                                                                                                                                                                                                                                                                 'ENVIRONMENTAL SCIENCE': 1091,
#                                                                                                                                                                                                                                                                                                                                                                                 'RTR PERSONAL SKILLS': 2577,
#                                                                                                                                                                                                                                                                                                                                                                                  'HRM 560 MANAGING ORGANIZATIONAL CHANGE': 1508,
#                                                                                                                                                                                                                                                                                                                                                                                 'THEORIES OF PERSONALITY': 2810,
#                                                                                                                                                                                                                                                                                                                                                                                  'LATINAMERICAN HISTORY': 1883,
#                                                                                                                                                                                                                                                                                                                                                                                   'FINANCIAL MODELING AND VALUATION': 1186,
#                                                                                                                                                                                                                                                                                                                                                                                    'AICPA CPEXPRESS': 171,
#                                                                                                                                                                                                                                                                                                                                                                                     'COMPUTERS USE AND MANAGEMENT / EXCEL III': 694,
#                                                                                                                                                                                                                                                                                                                                                                                      'ACCOUNTING 222': 52,
#                                                                                                                                                                                                                                                                                                                                                                                     'STUDIES IN MILITARY HISTORY': 2737,
#                                                                                                                                                                                                                                                                                                                                                                                     'OBJET DESIGN AND PROGRAMMING': 2221,
#                                                                                                                                                                                                                                                                                                                                                                                      'HISTORY OF THE U.S SINCE 1865': 1467,
#                                                                                                                                                                                                                                                                                                                                                                                      'NUTR 100 - ELEMENTS OF NUTRITION': 2209,
#                                                                                                                                                                                                                                                                                                                                                                                       'PERSONALITY INSIGHTS DISC CERTIFICATION LEVEL 3 SPEAKERS BOOT CAMP': 2301,
#                                                                                                                                                                                                                                                                                                                                                                                        'WRITING 394': 2901,
#                                                                                                                                                                                                                                                                                                                                                                                        'PERSONNEL SKILLS RESCUE WORKSHOP': 2304,
#                                                                                                                                                                                                                                                                                                                                                                                        'ETHICS IN AN AGE OF INFORMALITY: PROTECTING YOURSELF WHEN BOUNDARIES BLUR': 1120,
#                                                                                                                                                                                                                                                                                                                                                                                        'HIST 125 - TECHNOLOGICAL TRANSFORMATIONS': 1438,
#                                                                                                                                                                                                                                                                                                                                                                                        'INTERMEDIATE ALGEBRA MATH 093': 1660,
#                                                                                                                                                                                                                                                                                                                                                                                         'INTRO TO BUSINESS': 1695,
#                                                                                                                                                                                                                                                                                                                                                                                         'FAMILY PLAY THERAPY TO ENHANCE ATTACHMENT': 1145,
#                                                                                                                                                                                                                                                                                                                                                                                          'MATH 108': 2032,
#                                                                                                                                                                                                                                                                                                                                                                                           'PHIL 140 - CONTEMPORARY MORAL ISSUES': 2320,
#                                                                                                                                                                                                                                                                                                                                                                                           'EXCEL 301': 1130,
#                                                                                                                                                                                                                                                                                                                                                                                            'NUTRITION IN HEALTH AND DISEASE': 2216,
#                                                                                                                                                                                                                                                                                                                                                                                            'FEM 116': 1160,
#                                                                                                                                                                                                                                                                                                                                                                                            'NURSING ASSISTANCE CERTIFICATE': 2192,
#                                                                                                                                                                                                                                                                                                                                                                                             'GFOA 112TH ANNUAL CONFERENCE': 1343,
#                                                                                                                                                                                                                                                                                                                                                                                              'SPIRITUAL APPROACHES TO COUNSELING': 2699,
#                                                                                                                                                                                                                                                                                                                                                                                               'CCJS 345 INTRO TO SECURITY MANAGEMENT': 470,
#                                                                                                                                                                                                                                                                                                                                                                                                'CANINE SUPERVISOR ONLINE COURSE': 450,
#                                                                                                                                                                                                                                                                                                                                                                                                 'PERSONALITY DISORDERS: UNAVOIDABLE CHALLENGES AND PROVEN SOLUTIONS': 2300,
#                                                                                                                                                                                                                                                                                                                                                                                                  'ETHICS AND PROFESSIONAL CONDUCT FOR VIRGINIA CPAS ONLINE-2017 EDITION': 1115,
#                                                                                                                                                                                                                                                                                                                                                                                                  'HISTORY OF SOCIAL WELFARE': 1462,
#                                                                                                                                                                                                                                                                                                                                                                                                   'LBSC 602 SERVING INFORMATION NEEDS': 1892,
#                                                                                                                                                                                                                                                                                                                                                                                                    'CMSC 350 - DATA STRUCTURES AND ANALYSIS': 618,
#                                                                                                                                                                                                                                                                                                                                                                                                     'MARKETING': 1996,
#                                                                                                                                                                                                                                                                                                                                                                                                     'INTROCUCTION TO ASTRONOMY (PC 107)': 1724,
#                                                                                                                                                                                                                                                                                                                                                                                                      'DAP-850-A1P UAS (DRONE) FAA REMOTE PILOTS CERTIFICATION PREP': 850,
#                                                                                                                                                                                                                                                                                                                                                                                                       'BUS 612-- PRINCIPLES AND PRACTICES OF LEADERSHIP II': 401,
#                                                                                                                                                                                                                                                                                                                                                                                                       'STRENGTH TRAINING/CONDITION I': 2732,
#                                                                                                                                                                                                                                                                                                                                                                                                       'BMAL 560 CORPORATE RESPONSIBLITY': 351,
#                                                                                                                                                                                                                                                                              'GOVT 200: CONSTITUTIONAL GOVERNMENT AND FREE ENTERPRISE': 1379,
#                                                                                                                                                                                                                                                                               'SPRAT 1 - SOCIETY OF PROFRESSIONAL ROPE ACCESS TECHNICIANS': 2702,
#                                                                                                                                                                                                                                                                               'CMIS 310 COMPUTER SYSTEMS ARCHITECTURE': 590,
#                                                                                                                                                                                                                                                                               'ADVANCE RESEARCH WRITING': 105,
#                                                                                                                                                                                                                                                                               'PRINCIPLES OF ECONOMICS II': 2381,
#                                                                                                                                                                                                                                                                               'HUMAN BEHAVIOR-ORGANIZATIONS': 1548,
#                                                                                                                                                                                                                                                                               'MASS CASUALTY INCIDENT MANAGEMENT': 2004,
#                                                                                                                                                                                                                                                                               'FUNDAMENTALS OF ACCOUNTING': 1286,
#                                                                                                                                                                                                                                                                                "(ONLINE) PROFESSIONAL ETHICS: AICPA'S COMPREHENSIVE COURSE": 1,
#                                                                                                                                                                                                                                                                                'ASTRONOMY': 274,
#                                                                                                                                                                                                                                                                                 'LEARN TO SCUBA': 1919,
#                                                                                                                                                                                                                                                                                  'SERIAL KILLERS': 2607,
#                                                                                                                                                                                                                                                                                  'MICRO APPLICATION FOR ACCOUNTING': 2110,
#                                                                                                                                                                                                                                                                                  'INFORMATION SYSTEMS IN ENTERPRISE': 1632,
#                                                                                                                                                                                                                                                                                  'CJUS 300': 566,
#                                                                                                                                                                                                                                                                                   "CHILDREN'S ENVIRONMENTAL HEALTH": 536,
#                                                                                                                                                                                                                                                                                   'LABOR LAW AND LABOR ARBITRATION': 1875, 'VEHICLE TACTICS - PISTOL': 2855,
#                                                                                                                                                                                                                                                                                    'LSTD 400': 1963,
#                                                                                                                                                                                                                                                                                    'HUMN 100 INTRODUCTION TO HUMANITIES': 1573,
#                                                                                                                                                                                                                                                                                     'HCAD 600': 1396,
#                                                                                                                                                                                                                                                                                      'ACCT 303': 75,
#                                                                                                                                                                                                                                                                                      'LIBS 150: INTRODUCTION TO RESEARCH': 1950,
#                                                                                                                                                                                                                                                                                      'GROUP DYNAMICS': 1385,
#                                                                                                                                                                                                                                                                                      'CONTRACT ADMINISTRATION IN THE PUBLIC SECTOR': 721,
#                                                                                                                                                                                                                                                                                      'LOCAL ANESTHESIA CERTIFICATION FOR THE DENTAL HYGIENIST': 1956,
#                                                                                                                                                                                                                                                                                      'ADVANCED JAVA PROGRAMMING': 137,
#                                                                                                                                                                                                                                                                                      'SUICIDE AND SELF MUTILIATION': 2741,
#                                                                                                                                                                                                                                                                                      'BIO 101': 319,
#                                                                                                                                                                                                                                                                                      'BIO 101 LB': 320,
#                                                                                                                                                                                                                                                                                       'NURSING IN HEALTH AND ILLNESS II': 2200,
#                                                                                                                                                                                                                                                                                        'DBT FOR CHILREN AND ADOLESCENTS': 859,
#                                                                                                                                                                                                                                                                                         'PROGRAM ANALYSIS AND EVALUATION': 2405,
#                                                                                                                                                                                                                                                                                          'FIRE DYNAMICS': 1200,
#                                                                                                                                                                                                                                                                                         'PATHOPHYSIOLOGY': 2271,
#                                                                                                                                                                                                                                                                                          'CES 833 LEADERSHIP & ADVOCACY IN PROF COUNSELING': 512,
#                                                                                                                                                                                                                                                                                           'NURSING CARE OF SPECIAL POPULATIONS II: MATERNAL/CHILD NURSING': 2193,
#                                                                                                                                                                                                                                                                                            'CLOSE QUARTERS COMBAT SHOOTING': 583,
#                                                                                                                                                                                                                                                                                             'INTRODUCTION COMPUTERS & APPLICATIONS': 1726,
#                                                                                                                                                                                                                                                                                             'AUTOMOTIVE ELECTRICITY 1': 283,
#                                                                                                                                                                                                                                                                                             'INTEGRATED EMERGENCY MANAGMENT': 1642,
#                                                                                                                                                                                                                                                                                              'PUB HEALTH ADMIN & LEADERSHIP': 2478,
#                                                                                                                                                                                                                                                                                               'LEADERSHIP HEALTH CARE SYSTEM PRACTICE MANAGEMENT': 1907,
#                                                                                                                                                                                                                                                                                                'HIST111 WORLD CIVILIZATION BEFORE 1650': 1447,
#                                                                                                                                                                                                                                                                                                 'ECON 102, FORENSICS 100': 916,
#                                                                                                                                                                                                                                                                                               'COMMUNICATING, PROBLEM SOLVING AND LEADING IN CYBERSECURITY': 657,
#                                                                                                                                                                                                                                                                                                'INTRODUCTION TO DATA COMMUNICATION': 1740,
#                                                                                                                                                                                                                                                                                                 'DRUG IDENTIFICATION, PARAPHERNALIA, AND THE MOTOR VEHICLE STOP': 906,
#                                                                                                                                                                                                                                                                                                  'HVAC HEAT PUMP (BLDG273 AND BLDG273L)': 1578,
#                                                                                                                                                                                                                                                                                                   'NURSING, RN TO BSN BRIDGE': 2208,
#                                                                                                                                                                                                                                                                                                    'PUH 5305 CONCEPTS OF ENVIRONMENTAL HEALTH': 2510,
#                                                                                                                                                                                                                                                                                                     'COMPUTER AND INTERNET LITERACY': 679,
#                                                                                                                                                                                                                                                                                                      'INTRODUCTION TO SOCIAL WORK': 1795,
#                                                                                                                                                                                                                                                                                                       'CERTIFICATE IN INNOVATION AND CRITICAL THINKING': 499,
#                                                                                                                                                                                                                                                                                                       'IFSM 310 - SOFTWARE AND HARDWARE INFRASTRUCTURE CONCEPTS': 1599,
#                                                                                                                                                                                                                                                                                                       'ARTIFICIAL HIGH DIRECTIONAL WORKSHOP': 261,
#                                                                                                                                                                                                                                                                                                        'GOVERNMENTAL ACCOUNTING AND AUDITING UPDATE CONFERENCE': 1374,
#                                                                                                                                                                                                                                                                                                         'FUNDAMENTALS OF FACILITY MANAGEMENT': 1293,
#                                                                                                                                                                                                                                                                                                         'BUS 632 -- DATE-DRIVEN DECISION-MAKING II': 403,
#                                                                                                                                                                                                                                                                                                          'BIOLOGY 107 FUNDAMENTALS OF MICROBIOLOGY': 340,
#                                                                                                                                                                                                                                                                                                           'RESEARCH DESIGN AND METHODS': 2553,
#                                                                                                                                                                                                                                                                                                           'HRMN 362 5120 LABOR RELATIONS': 1516,
#                                                                                                                                                                                                                                                                                                            'EL 104 AMERICAN ENGLISH LANGUAGE IV': 964,
#                                                                                                                                                                                                                                                                                                            'HISTORY OF THE CIVIL WAR': 1465,
#                                                                                                                                                                                                                                                                                                             'HRMN 395 THE TOTAL REWARDS APPROACH TO COMPENSATION MANAGEMENT': 1519,
#                                                                                                                                                                                                                                                                                                              'BMGT 381 - BUSINESS LAW II': 363,
#                                                                                                                                                                                                                                                                                                               'INTERNATIONAL RELATIONS': 1676,
#                                                                                                                                                                                                                                                                                                                'CCJS 230 6380 CRIMINAL LAW IN ACTION (2222)': 464,
#                                                                                                                                                                                                                                                                                                                 'K9 HITS - HANDLER INSTRUCTION AND TRAINING SEMINAR': 1869,
#                                                                                                                                                                                                                                                                                                                  'CRIMINAL JUSTICE POLICY AND ADMINISTRATION': 786,
#                                                                                                                                                                                                                                                                                                                   'HEALTH CARE FINANCIAL MANAGEMENT': 1405,
#                                                                                                                                                                                                                                                                                                                    'K-9 COP MAGAZINE ANNUAL CONFERENCE': 1867,
#                                                                                                                                                                                                                                                                                                                     'CHDA DOMAIN 1- BUSINESS NEEDS ASSESSMENT': 520,
#                                                                                                                                                                                                                                                                                                                     'INTRO TO PLUMBING': 1710,
#                                                                                                                                                                                                                                                                                                                      'MAINTAINING MICROCOMPUTER SYSTEMS I': 1974,
#                                                                                                                                                                                                                                                                                                                       'CCJS 495 ISSUES IN CRIMINAL JUSTICE': 477,
#                                                                                                                                                                                                                                                                                                                        'WRITING FOR MANAGERS': 2906,
#                                                                                                                                                                                                                                                                                                                         'INTERNSHIP': 1679,
#                                                                                                                                                                                                                                                                                                                          'COMMUNITY LEADERSHIP DEVELOPMENT': 668,
#                                                                                                                                                                                                                                                                                                                           'GLOBAL TERRORISM': 1355,
#                                                                                                                                                                                                                                                                                                                            'EMERGENCY MANAGMENT 104 - DISASTER RESPONSE AND RECOVERY': 1003,
#                                                                                                                                                                                                                                                                                                                             'BUSINESS LAW - MANAGEMENT 201': 428,
#                                                                                                                                                                                                                                                                                                                              'BUS 631 -- DATA-DRIVEN DECISION-MAKING I': 402,
#                                                                                                                                                                                                                                                                                                                               'MATH 106 FINITE MATHEMATICS': 2029,
#                                                                                                                                                                                                                                                                                                                               'CMIT  321 - 7980   ETHICAL HACKING': 591,
#                                                                                                                                                                                                                                                                                                                                'CMIS - 102 -6980 INTRODUCTION TO PROBLEM SOLVING AND ALGORITHM DESIGN': 585,
#                                                                                                                                                                                                                                                                                                                                 'ART THERAPY FOR KIDS: CREATIVE INTERVENTIONS FOR TRAUMA': 258,
#                                                                                                                                                                                                                                                                                                                                 'CPSY-590 (26241) EVALUATION AND APPRAISAL': 765,
#                                                                                                                                                                                                                                                                                                                                 'DIAGNOSIS AND TREATMENT OF MENTAL AND EMOTIONAL DISORDERS IN FAMILY SYSTEMS': 876,
#                                                                                                                                                                                                                                                                                                                                  'IMMIGRATION AND JUSTICE': 1609,
#                                                                                                                                                                                                                                                                                                                                   'ADVANCED HEALTH CARE MANAGEMENT': 134,
#                                                                                                                                                                                                                                                                                                                                   'PACE111P': 2263,
#                                                                                                                                                                                                                                                                                                                                    'HMLS 302 INTRODUCTION TO HOMELAND SECURITY': 1479,
#                                                                                                                                                                                                                                                                                                                                     'CRISIS COMMUNICATIONS MANAGEMENT': 801,
#                                                                                                                                                                                                                                                                                                                                      '3 DAY ADVANCED ARMORERS COURSE': 21,
#                                                                                                                                                                                                                                                                                                                                      'NUTRITION 1010': 2214,
#                                                                                                                                                                                                                                                                                                                                       'CHDA DOMAIN 4- DATA INTERPRETATION AND REPORTING AND CHDA DOMAIN 5- DATA GOVERNANCE': 523,
#                                                                                                                                                                                                                                                                                                                                        'INTERNATIONAL ACCOUNTING': 1674,
#                                                                                                                                                                                                                                                                                                                                         'LEADERSHIP DEVELOPMENT': 1905,
#                                                                                                                                                                                                                                                                                                                                          'FOUNDATION OF GRADUATE STUDY': 1246,
#                                                                                                                                                                                                                                                                                                                                           'COLLEGIATE MATH': 644,
#                                                                                                                                                                                                                                                                                                                                           'HEALTHCARE POLICY: YESTERDAY, TODAY, AND TOMORROW': 1422,
#                                                                                                                                                                                                                                                                                                                                            'INTRO TO PROFESSIONAL WRITING': 1712,
#                                                                                                                                                                                                                                                                                                                                             'INFORMATION SYSTEM': 1626,
#                                                                                                                                                                                                                                                                                                                                              'NURS 690 MANAGERIAL HEALTH FINANCE': 2184, 'LGST 101 CR INTRO TO LEGAL SYSTEM': 1940,
#                                                                                                                                                                                                                                                                                                                                              'PLANNING TEAM MANAGER': 2333,
#                                                                                                                                                                                                                                                                                                                                               'TRAUMA CERTIFICATE PROGRAM LEVEL I': 2833,
#                                                                                                                                                                                                                                                                                                                                               'POLI 101 CR AMERICAN GOVERNMENT': 2336,
#                                                                                                                                                                                                                                                                                                                                               'ARTIFICAL HIGH DIRECTIONAL WORKSHOP': 260,
#                                                                                                                                                                                                                                                                                                                                                'EMDR THERAPY TRAINING PROGRAM': 997, 'CYBER INCIDENT ANALYSIS AND RESPONSE (CSEC 662)': 840,
#                                                                                                                                                                                                                                                                                                                                                'HRM 500 HUMAN RESOURCE MANAGEMENT FOUNDATIONS': 1505,
#                                                                                                                                                                                                                                                                                                                                                 'BMGT 364 - MANAGEMENT AND ORG THEORY': 360,
#                                                                                                                                                                                                                                                                                                                                                 'WORD PROCESSING APPLICATIONS': 2891,
#                                                                                                                                                                                                                                                                                                                                                 'HS8413 - SOCIAL INFLUENCES OF BEHAVIOR': 1524,
#                                                                                                                                                                                                                                                                                                                                                  'CCJS 495 - ISSUES IN CRIMINAL JUSTICE': 476,
#                                                                                                                                                                                                                                                                                                                                                   'PUAD  622 - PUBLIC BUDGETING AND FISCAL ADMINISTRATION': 2464,
#                                                                                                                                                                                                                                                                                                                                                    'ASPPA NATIONAL CONFERENCE': 267,
#                                                                                                                                                                                                                                                                                                                                                     'TECH OF RDNG & WRTG II - EN 102': 2776,
#                                                                                                                                                                                                                                                                                                                                                      'COMPOSITION AND LITERATURE': 673,
#                                                                                                                                                                                                                                                                                                                                                       '870 REMINGTON SHOTGUN ARMORER': 34
#                                                                                                                                                                                                                                                                                                                                                       , 'BUS 302 MANAGEMENT CONCEPTS': 396,
#                                                                                                                                                                                                                                                                                                                                                        'CHDA DOMAIN 3- DATA ANALYSIS': 522,
#                                                                                                                                                                                                                                                                                                                                                         'ORGANIZATIONAL LEADERSHIP BMGT 365': 2246,
#                                                                                                                                                                                                                                                                                                                                                          'INTRODUCTION TO PHILOSOPHY': 1778,
#                                                                                                                                                                                                                                                                                                                                                          'HUMAN RESOURCE MANAGEMENT & ISSUES': 1560,
#                                                                                                                                                                                                                                                                                                                                                           'LEADERSHIP AND CHANGE': 1902,
#                                                                                                                                                                                                                                                                                                                                                           'PSYCHOLOGY- CHILD PSYCHOLOGY': 2459,
#                                                                                                                                                                                                                                                                                                                                                            'WHY KIDS HATE THERAPY AND WHAT YOU CAN DO': 2882,
#                                                                                                                                                                                                                                                                                                                                                             'DEFENSIVE CARBINE FOR THE AR PLATFORM-II': 863,
#                                                                                                                                                                                                                                                                                                                                                             'CCJS 345 - INTRO TO SECURITY MANAGEMENT': 469,
#                                                                                                                                                                                                                                                                                                                                                              'EFFECTIVE GROUP COMMUNICATION': 960,
#                                                                                                                                                                                                                                                                                                                                                               'NRSG 790': 2172, 'MNGT-481  STRATEGIC MANAGEMENT': 2125,
#                                                                                                                                                                                                                                                                                                                                                                'FOUNDATIONS OF INFORMATION SYSTEM': 1254,
#                                                                                                                                                                                                                                                                                                                                                                 'MANAGING IN COMPLEX ENVIRONMENTS': 1990,
#                                                                                                                                                                                                                                                                                                                                                                 'WEST CIV. & MODERN WORLD': 2877,
#                                                                                                                                                                                                                                                                                                                                                                  'HUMAN RESPONSE TO FIRE': 1567, 'MANAGER IN A TECHNOLOGICAL SOCIETY': 1986,
#                                                                                                                                                                                                                                                                                                                                                                   'ANPS 8003 PSYCHOPATHOLOGICAL DISORDERS ACROSS THE LIFESPAN': 222,
#                                                                                                                                                                                                                                                                                                                                                                   'COMM 400 - MASS MEDIA LAW': 654,
#                                                                                                                                                                                                                                                                                                                                                                   'SWCL 727- CLINICAL PRACTICE WITH FAMILIES AND CHILDREN IN CHILD WELFARE (3 CREDITS)': 2752,
#                                                                                                                                                                                                                                                                                                                                                                    'DIGITAL MEDIA AND SOCIETY': 883,
#                                                                                                                                                                                                                                                                                                                                                                     'CAPSTONE SEMINAR IN CRIM JUST': 455,
#                                                                                                                                                                                                                                                                                                                                                                      'IUF- WHAT IS A GOOD LIFE': 1852,
#                                                                                                                                                                                                                                                                                                                                                                       'CMIT 391 LINUX SYSTEM ADMINISTRATION': 599,
#                                                                                                                                                                                                                                                                                                                                                                        'ANXIETY TREATMENT FOR CHILDREN AND ADOLESCENTS': 229,
#                                                                                                                                                                                                                                                                                                                                                                         'REPAIRING ATTACHMENT TRAUMA': 2549,
#                                                                                                                                                                                                                                                                                                                                                                         'INTRODUCTION TO EARTH SYSTEMS SCIENCE': 1744,
#                                                                                                                                                                                                                                                                                                                                                                         'THE AFRICAN EXPERIENCE': 2783,
#                                                                                                                                                                                                                                                                                                                                                                         'SOFTWARE DESIGN AND IMPLEMENTATION': 2664,
#                                                                                                                                                                                                                                                                                                                                                                          'PREPARING FOR THE AGE OF LICENSING LCEN 100418 GAITHERSBURG, MD': 2361,
#                                                                                                                                                                                                                                                                                                                                                                          'FUND. OF MICROBIOLOGY': 1283, 'PUAD 603 POLICY PROCESS': 2467,
#                                                                                                                                                                                                                                                                                                                                                                          'EPIDEMIOLOGY: DECODING THE SCI': 1096,
#                                                                                                                                                                                                                                                                                                                                                                          'HOSPITAL BASED CNA CLINICAL': 1495,
#                                                                                                                                                                                                                                                                                                                                                                          'BUSINESS MANAGEMENT317': 437,
#                                                                                                                                                                                                                                                                                                                                                                           'ENCLOSURE FIRE MODELING': 1038,
#                                                                                                                                                                                                                                                                                                                                                                            'DEVELOPING AND MANAGING REQUESTS FOR PROPOSALS DMRFP 110518 HAGERSTOWN, MD': 873,
#                                                                                                                                                                                                                                                                                                                                                                             'ELEMENTARY STATISTIC': 983, 'RESEARCH METHODS FOR HEALTHCARE MANAGERS': 2558,
#                                                                                                                                                                                                                                                                                                                                                                             'PRINC OF ECONOMICS II - ECON 202': 2368,
#                                                                                                                                                                                                                                                                                                                                                                             'HUMAN EVOLUTION': 1551,
#                                                                                                                                                                                                                                                                                                                                                                              'MANAGING THE POLITICS OF LEADERSHIP': 1991,
#                                                                                                                                                                                                                                                                                                                                                                              'CES 735 ADVANCED COUNSELING THEORIES & SKILLS': 511,
#                                                                                                                                                                                                                                                                                                                                                                               '37TH ANNUAL APA CONGRESS': 26,
#                                                                                                                                                                                                                                                                                                                                                                               'U.S. LAW, LEGAL METHODS, LEGAL RESEARCH, ETC.': 2838,
#                                                                                                                                                                                                                                                                                                                                                                               'PRINCIPLES OF MICROECONOMICS': 2390,
#                                                                                                                                                                                                                                                                                                                                                                                'BEHS 210 INTRO TO SOCIAL SCIENCE': 308,
#                                                                                                                                                                                                                                                                                                                                                                                'INTRO TO INFO SCIENC & SYSTEMS - 46785 - CSIS 100 - B02': 1707,
#                                                                                                                                                                                                                                                                                                                                                                                'IS HARDWARE & SOFTWARE - 53637 - CSIS 320 - D01': 1815,
#                                                                                                                                                                                                                                                                                                                                                                                'CORPORATE FINANCE': 731,
#                                                                                                                                                                                                                                                                                                                                                                                 'CMSC 335 OBJECT-ORIENT CONCURRENT PROGR': 617,
#                                                                                                                                                                                                                                                                                                                                                                                  'BIO 1120- ENVIRONMENTAL BIOLOGY LAB': 321,
#                                                                                                                                                                                                                                                                                                                                                                                   'PUBLIC BUDGETING AND FINANCE': 2483,
#                                                                                                                                                                                                                                                                                                                                                                                   'MGMT 630- ORGANIZATIONAL THEORY AND BEHAVIOR': 2096,
#                                                                                                                                                                                                                                                                                                                                                                                    'ENGL 101': 1048,
#                                                                                                                                                                                                                                                                                                                                                                                     'RISK ANALYSIS AND LOSS PREVENTION': 2566,
#                                                                                                                                                                                                                                                                                                                                                                                      'CONTEMPORARY PUBLIC SAFETY PRACTICES': 717,
#                                                                                                                                                                                                                                                                                                                                                                                      'ELEMENTARY SPANISH II': 982,
#                                                                                                                                                                                                                                                                                                                                                                                      'INTERIOR DESIGN I': 1655,
#                                                                                                                                                                                                                                                                                                                                                                                       'IT 521 INFORMATION ASSURANCE AND RISK ASSESSMENT': 1833,
#                                                                                                                                                                                                                                                                                                                                                                                       'STAFFING AND ORGANIZATION': 2706,
#                                                                                                                                                                                                                                                                                                                                                                                        'NURS-6640N-1, PSYCHOTHERAPY INDIVIDUAL': 2187,
#                                                                                                                                                                                                                                                                                                                                                                                         'SMALL BUSINESS FINANCE': 2621,
#                                                                                                                                                                                                                                                                                                                                                                                          'COMPOSITION FOR COMMUNICATION IN THE CRIMINAL JUSTICE SYSTEM': 674,
#                                                                                                                                                                                                                                                                                                                                                                                           'AMERICAN STATE AND LOCAL POLITICS': 213,
#                                                                                                                                                                                                                                                                                                                                                                                           'FSCI 500 SURVEY OF FORENSIC SCIENCE': 1276,
#                                                                                                                                                                                                                                                                                                                                                                                            'THE WORLD IN THE 20TH CENTURY': 2802,
#                                                                                                                                                                                                                                                                                                                                                                                             'INSTRUCTIONAL TECH FOR ONLINE LEARNING UNIV 104-D63': 1640,
#                                                                                                                                                                                                                                                                                                                                                                                              'PHI 208 ETHICS AND MORAL REASONING': 2318,
#                                                                                                                                                                                                                                                                                                                                                                                               'CMSC 350: DATA STRUCTURES AND ANALYSIS': 619,
#                                                                                                                                                                                                                                                                                                                                                                                               'CMIT 265 - FUNDAMENTALS OF NETWORKING': 593,
#                                                                                                                                                                                                                                                                                                                                                                                               'ARMORERS CERTIFICATION': 251,
#                                                                                                                                                                                                                                                                                                                                                                                               'PROJECT WRITING SEMINAR': 2422,
#                                                                                                                                                                                                                                                                                                                                                                                               'PUBLIC SAFETY GIS & TECHNOLOGY EM 201': 2499, 'PUBLIC FINANCE': 2484, 'TEACHING AND LEARNING STRATEGIES IN HEALTHCARE': 2770,
#                                                                                                                                                                                                                                                                                                                                                                                               'CMIT 321 ETHICAL HACKING': 595,
#                                                                                                                                                                                                                                                                                                                                                                                               'FIRE INVESTIGATION': 1206,
#                                                                                                                                                                                                                                                                                                                                                                                               'BIOL 101': 330,
#                                                                                                                                                                                                                                                                                                                                                                                                'ELEMENTARY FRENCH II': 975,
#                                                                                                                                                                                                                                                                                                                                                                                                'SPECIAL TOPICS IN LEADERSHIP': 2693,
#                                                                                                                                                                                                                                                                                                                                                                                                 'GOVERNMENT 403; LAW, MORALITY AND WAR': 1371,
#                                                                                                                                                                                                                                                                                                                                                                                                  'IFSM 300 - INFORMATIONS SYSTEMS IN ORGANIZATIONS': 1596,
#                                                                                                                                                                                                                                                                                                                                                                                                  'HALE TRAINING ACADEMY': 1389,
#                                                                                                                                                                                                                                                                                                                                                                                                  'AUDITING- ACCT 401': 281,
#                                                                                                                                                                                                                                                                                                                                                                                                   'FSA107 - DISASTER PLANNING AND RESPONSE': 1274,
#                                                                                                                                                                                                                                                                                                                                                                                                    'LEGAL ASPECTS OF PUBLIC PROCUREMENT LGL 100118 FREDERICK, MD': 1928,
#                                                                                                                                                                                                                                                                                                                                                                                                     'BIO-1110- ENVIRONMENTAL BIOLOGY': 329,
#                                                                                                                                                                                                                                                                                                                                                                                                      'HUM 381 CONTEMPORARY GLOBAL ISSUES': 1537,
#                                                                                                                                                                                                                                                                                                                                                                                                      'PHILOSOPHY 348 RELIGIONS OF THE EAST': 2323,
#                                                                                                                                                                                                                                                                                                                                                                                                      'CMIT 350 - INTERCONNECTING CISCO DEVICES': 598,
#                                                                                                                                                                                                                                                                                                                                                                                                       'FRENCH 201': 1265,
#                                                                                                                                                                                                                                                                                                                                                                                                       'FIRE AND EMERGENCY SERVICE ADMINISTRATION- FSA 201': 1197,
#                                                                                                                                                                                                                                                                                                                                                                                                        '2018 CRIMINAL PATROL STOP WORKSHOP': 19,
#                                                                                                                                                                                                                                                                                                                                                                                                        'GASB STATEMENT NO. 72 - HOW DO YOU MEASURE UP?': 1307,
#                                                                                                                                                                                                                                                                                                                                                                                                         'HOMELAND SECURITY RESPONSE TO CRITICAL INCIDENTS': 1492,
#                                                                                                                                                                                                                                                                                                                                                                                                          'SERVING INFORMATION NEEDS': 2608,
#                                                                                                                                                                                                                                                                                                                                                                                                           'CLINAL MEDICAL TECHNOLOGY': 574, 'WEB ARCHITECTURE & DEVELOPMENT - 53632 - CSIS 310 - D02': 2873,
#                                                                                                                                                                                                                                                                                                                                                                                                           'MANGEMENT 615 INTERCULTURAL COMMUNICATION AND LEADERSHIP': 1993,
#                                                                                                                                                                                                                                                                                                                                                                                                           'NAVIGATING THE ETHICAL CHALLENGES OF TELEMENTAL HEALTH': 2155,
#                                                                                                                                                                                                                                                                                                                                                                                                            'BUSI 730 STRATEGIC ALLOCATION OF FINANCIAL RESOURCES': 409,
#                                                                                                                                                                                                                                                                                                                                                                                                            'BUSINESS MANAGEMENT ORGANIZATIONAL LEADERSHIP': 436,
#                                                                                                                                                                                                                                                                                                                                                                                                             'COMMUNICATION SKILLS': 661,
#                                                                                                                                                                                                                                                                                                                                                                                                             'COMMUNITY RISK REDUCTION FOR THE FIRE AND EMERGENCY SERVICES  FIR 3307': 670,
#                                                                                                                                                                                                                                                                                                                                                                                                              'HEALTH- FITNESS/NUTRITION WEIGHT MANAGEMENT': 1420,
#                                                                                                                                                                                                                                                                                                                                                                                                              'SWCL 748 - CLINICAL SOCIAL WORK IN RELATION TO DEATH, DYING & BEREAVEMENT': 2754,
#                                                                                                                                                                                                                                                                                                                                                                                                              'HUMAN RESOURCES MANAGEMENT: ISSUES AND PROBLEMS': 1565,
#                                                                                                                                                                                                                                                                                                                                                                                                              'P2F2 2018 CONFERENCE': 2257,
#                                                                                                                                                                                                                                                                                                                                                                                                              'JAPANESE 111': 1853, 'CONSTITUTIONAL GOVERNMENT & FREE ENTERPRISE GOVT 200-D26': 706,
#                                                                                                                                                                                                                                                                                                                                                                                                              'MATH': 2018,
#                                                                                                                                                                                                                                                                                                                                                                                                               'HRMN 400 HUMAN RESOURCE MANAGEMENT: ISSUES AND PROBLEMS': 1520,
#                                                                                                                                                                                                                                                                                                                                                                                                                'BUSI 720 QUANTITATIVE RESAERCH METHODS': 408,
#                                                                                                                                                                                                                                                                                                                                                                                                                 'CSIS 320 - HARDWARE AND SOFTWARE': 829,
#                                                                                                                                                                                                                                                                                                                                                                                                                 'CSIT 534 NETWORK AND INTERNET SECURITY': 830,
#                                                                                                                                                                                                                                                                                                                                                                                                                  'CMIT 453 TROUBLESHOOTING AND MAINTAINING CISCO IP': 601,
#                                                                                                                                                                                                                                                                                                                                                                                                                   'INFORMATION SYSTEM ORGANIZATIONS': 1629,
#                                                                                                                                                                                                                                                                                                                                                                                                                    'INSTRUCTIONAL METHODOLOGY FOR EMERGENCY SERVICES': 1639,
#                                                                                                                                                                                                                                                                                                                                                                                                                     'EMOTIONAL INTELLIGENCE': 1019,
#                                                                                                                                                                                                                                                                                                                                                                                                                     'ODD BEHAVIORS IN KIDS': 2222,
#                                                                                                                                                                                                                                                                                                                                                                                                                     'CHDA DOMAIN 2- DATA ACQUISITION AND MANAGEMENT': 521, 'USABILITY ENGINEERING': 2849,
#                                                                                                                                                                                                                                                                                                                                                                                                                     'THEORY FOR EVIDENCE BASED PRACTICE': 2814,
#                                                                                                                                                                                                                                                                                                                                                                                                                     'ART 101 - INTRO TO ART': 253,
#                                                                                                                                                                                                                                                                                                                                                                                                                      'MOLECULAR BIOLOGY': 2129,
#                                                                                                                                                                                                                                                                                                                                                                                                                       'PSYCHOLOGY OF WOMEN': 2458,
#                                                                                                                                                                                                                                                                                                                                                                                                                       'CISCO NETWORK DEFENDING': 545,
#                                                                                                                                                                                                                                                                                                                                                                                                                        'CPSY 690 ADVANCE COUNSELING TECHNIQUES': 763,
#                                                                                                                                                                                                                                                                                                                                                                                                                         'COUNSELING': 741,
#                                                                                                                                                                                                                                                                                                                                                                                                                          'EMDR BASIC TRAINING': 996,
#                                                                                                                                                                                                                                                                                                                                                                                                                          'INTERPERSONAL COMMUNICATIONS': 1682,
#                                                                                                                                                                                                                                                                                                                                                                                                                           'LEVEL ONE DYADIC DEVELOPMENTAL PSYCHOTHERAPY: HEALING RELATIONAL TRAUMA': 1939,
#                                                                                                                                                                                                                                                                                                                                                                                                                           'ENVIRONMENTAL RISK ASSESMENT': 1090,
#                                                                                                                                                                                                                                                                                                                                                                                                                            'FES 3815- COMMAND AND CONTROL AT CATASTROPHIC FIRE -RESCUE INCIDENTS': 1168,
#                                                                                                                                                                                                                                                                                                                                                                                                                             'COMPUTER CONCEPTS - CMSC 110': 682,
#                                                                                                                                                                                                                                                                                                                                                                                                                              'INFORMATION SYSTEMS IN ORGANIZATIONS': 1633,
#                                                                                                                                                                                                                                                                                                                                                                                                                               'DNP PRACTICUM': 901,
#                                                                                                                                                                                                                                                                                                                                                                                                                                'CPSY 699D CLINICAL INTERNSHIP': 764,
#                                                                                                                                                                                                                                                                                                                                                                                                                                 'INTERMEDIATE ACCOUNTING': 1656,
#                                                                                                                                                                                                                                                                                                                                                                                                                                 'BMGT 392, GLOBAL BUSINESS MANAGEMENT': 364,
#                                                                                                                                                                                                                                                                                                                                                                                                                                 'CAPSTONE IN CYBERSECURITY': 453,
#                                                                                                                                                                                                                                                                                                                                                                                                                                  'INTRODUCTION TO RESEARCH LIBS150': 1788,
#                                                                                                                                                                                                                                                                                                                                                                                                                                  'PROJECT IMPLEMENTATION': 2411,
#                                                                                                                                                                                                                                                                                                                                                                                                                                   'EXECUTIVE DEVELOPMENT PROGRAM': 1135,
#                                                                                                                                                                                                                                                                                                                                                                                                                                    'ENGL 393 -TECHNICAL WRITING': 1052,
#                                                                                                                                                                                                                                                                                                                                                                                                                                    'P2F2 2019 CONFERENCE': 2258,
#                                                                                                                                                                                                                                                                                                                                                                                                                                    'CJ246: HUMAN RELATIONS IN A DIVERSE SOCIETY': 555,
#                                                                                                                                                                                                                                                                                                                                                                                                                                     'COLT ARMORERS COURSE': 647,
#                                                                                                                                                                                                                                                                                                                                                                                                                                      'ACADEMIC LEARNING PORTFOLIO': 41,
#                                                                                                                                                                                                                                                                                                                                                                                                                                       'IFSM450 TELECOMMUNICATION SYSTEMS IN MANAGEMENT': 1602,
#                                                                                                                                                                                                                                                                                                                                                                                                                                        'SPAN 203 - 0501': 2677,
#                                                                                                                                                                                                                                                                                                                                                                                                                                         'PUBLIC WRITING': 2509,
#                                                                                                                                                                                                                                                                                                                                                                                                                                          'PCN-545 SPOUSAL AND CHILD ABUSE, CRISIS AND TRAUMA COUNSELING': 2280,
#                                                                                                                                                                                                                                                                                                                                                                                                                                          'CONTENT AREA READING': 719,
#                                                                                                                                                                                                                                                                                                                                                                                                                                           'CRJ -301 JUVENILE JUSTICE': 811,
#                                                                                                                                                                                                                                                                                                                                                                                                                                           'GEOLOGY 101 WITH GEOLOGY 101 LAB': 1332,
#                                                                                                                                                                                                                                                                                                                                                                                                                                            'FUNDAMENTALS OF MATH': 1296,
#                                                                                                                                                                                                                                                                                                                                                                                                                                             'ETHICAL LEADERSHIP': 1106,
#                                                                                                                                                                                                                                                                                                                                                                                                                                             'GLOBALIZATION OF THREATS AND INTERNATIONAL SECURITY': 1357,
#                                                                                                                                                                                                                                                                                                                                                                                                                                              'IFSM 311 -  ENTERPRISE ARCHITECTURE': 1600,
#                                                                                                                                                                                                                                                                                                                                                                                                                                               'BUSINESS ETHICH AND SOCIETY': 422,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                'JUDICIAL PROCESS': 1858,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                'ILPA MODULE ONE - LEGAL DOCUMENTS': 1607,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                'INTEGRATING AUDIT DATA ANALYTICS INTO THE AUDIT PROCESS': 1644,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'CRIMINAL PATROL/DRUG INTERDICTION': 792,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                  'BEHS 343 PARENTING TODAY': 311,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                   'LEADERSHIP THEORY AND PRACTICE': 1914,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'SECURITY RISK MANAGEMENT': 2598,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'CISSP TRAINING': 549,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'SOCIAL WELFARE AND SOCIAL POLICY': 2639,
#                                                                                                                                                                                                                                                                                                 'EMERGING ENVIRONMENTAL TECHNOLOGIES': 1009,
#                                                                                                                                                                                                                                                                                                  'CFA DECEMBER LEVEL 1 REVIEW CLASS- PREMIUM INSTRUCTION PACKAGE': 513,
#                                                                                                                                                                                                                                                                                                   'PE CIVIL - ONDEMAND CLASSES - SPRING 19': 2285,
#                                                                                                                                                                                                                                                                                                    'ANNUAL WEBCAST PASS FOR GOVERNMENTAL ACCOUNTING AND AUDITING COURSES': 221,
#                                                                                                                                                                                                                                                                                                    'PCN-520 GROUP COUNSELING THEORY AND PRACTICE': 2278,
#                                                                                                                                                                                                                                                                                                     'SPCH 324 COMMUNICATION AND GENDER': 2692,
#                                                                                                                                                                                                                                                                                                      'DISCLSOURE, RELIGIOUS DIVERSITY, ETHICS AND CULTURAL COMPETENCE IN MENTAL HEALTH TREATMENT': 890,
#                                                                                                                                                                                                                                                                                                       'COUNSELING ETHIS': 744,
#                                                                                                                                                                                                                                                                                                        'SURVEY OF FORENSIC SCIENCE': 2747,
#                                                                                                                                                                                                                                                                                                         'CONTRACT LAW': 722,
#                                                                                                                                                                                                                                                                                                          'INTENSIVE INTERMEDIATE FRENCH': 1649,
#                                                                                                                                                                                                                                                                                                          'PERSONAL LEADERSHIP DEVELOPMENT': 2297,
#                                                                                                                                                                                                                                                                                                          'EMPLOYEE BENEFIT PLAN AUDIT CONFERENCE 2019': 1022,
#                                                                                                                                                                                                                                                                                                           'FOUNDATIONS IN PUBLIC HEALTH': 1251,
#                                                                                                                                                                                                                                                                                                            'LINUX/UNIX': 1954,
#                                                                                                                                                                                                                                                                                                            'GLOBAL HUMAN RESOURCE MANAGEMENT': 1350,
#                                                                                                                                                                                                                                                                                                            'BEHS 103 TECHNOLOGY AND CONTEMPORARY SOCIETY': 305, 'MAT 137': 2013,
#                                                                                                                                                                                                                                                                                                            'SAFETY AND SECURITY IN THE BUILT ENVIRONMENT': 2580,
#                                                                                                                                                                                                                                                                                                             'BMAL 570 ETHICAL LEADERSHIP': 352,
#                                                                                                                                                                                                                                                                                                             'SURVEY OF THE OLD AND NEW TESTAMENT,  BIBLE 104-076 LUO': 2748,
#                                                                                                                                                                                                                                                                                                              'PCN-509 SOCIAL AND CULTURAL DIVERSITY ISSUES IN COUNSELING': 2277,
#                                                                                                                                                                                                                                                                                                               'MBA 640: FINANCE, ECONOMICS AND DECISION': 2054,
#                                                                                                                                                                                                                                                                                                                'COUNSELOR IDENTITY/FUNCTION': 747,
#                                                                                                                                                                                                                                                                                                                'PCN-521 MARRIAGE AND FAMILY THERAPY': 2279,
#                                                                                                                                                                                                                                                                                                                'HIS 111': 1435,
#                                                                                                                                                                                                                                                                                                                'MATH 117 - ELEMENTS OF STATISTICS': 2036,
#                                                                                                                                                                                                                                                                                                                'ADVANCED INFORMATION SECURITY SYSTEM': 136,
#                                                                                                                                                                                                                                                                                                                 'HEALTH INFORMATICS AND SURVEILLANCE': 1414,
#                                                                                                                                                                                                                                                                                                                  'STRATEGIC LEADERSHIP LBSC 660': 2721,
#                                                                                                                                                                                                                                                                                                                   'DOCUMENTING YOUR EMPLOYEE BENEFIT PLAN AUDIT: WHAT YOU NEED TO KNOW': 904,
#                                                                                                                                                                                                                                                                                                                    'SCRIPTING': 2592,
#                                                                                                                                                                                                                                                                                                                    'BIOL 108 MARINE ENVIRONMENTAL SCIENCE': 332,
#                                                                                                                                                                                                                                                                                                                     'BUSINESS ADMINISTRATION': 418,
#                                                                                                                                                                                                                                                                                                                     'PSYCHIATRY MOC REVIEW - ONLINE': 2448,
#                                                                                                                                                                                                                                                                                                                      'CPSY665 G01 - PSYCHOTHERAPY ALCOHOL AND DRUG DISORDER': 767,
#                                                                                                                                                                                                                                                                                                                       'CIS316 TECHNICAL WRITING': 542,
#                                                                                                                                                                                                                                                                                                                       'PROFESSIONAL WEB DESIGN PRINCIPLES': 2403,
#                                                                                                                                                                                                                                                                                                                        'BIBL 104 OLD AND NEW TESTAMENT': 318,
#                                                                                                                                                                                                                                                                                                                         'ADVANCED INDUSTRIAL FIRE SAFETY': 135,
#                                                                                                                                                                                                                                                                                                                          "PUAD 710 - INTERGOV'T RELATIONS SEM": 2473,
#                                                                                                                                                                                                                                                                                                                          'SPANISH I PART 1': 2687,
#                                                                                                                                                                                                                                                                                                                           'CPSY-620-G01 (27421) MARRIAGE & FAMILY COUNSELING': 766,
#                                                                                                                                                                                                                                                                                                                            'PRE-ALG/ALGEBRA FAST TRCK': 2359,
#                                                                                                                                                                                                                                                                                                                             'EMGT221 PUBLIC SAFETY LEADERSHIP & ETHICS': 1018,
#                                                                                                                                                                                                                                                                                                                             'LIFE 220 - FUNDAMENTALS OF ECOLOGY': 1952,
#                                                                                                                                                                                                                                                                                                                              'MBA: 635 ETHICS, CORP. CULTURE AND SOC. RES.': 2056,
#                                                                                                                                                                                                                                                                                                                              'STATS FOR BUSINESS & ECONIMICS II': 2717,
#                                                                                                                                                                                                                                                                                                                               'CHANGING POPULATIONS IN HISTORICAL PERSPECTIVES': 519,
#                                                                                                                                                                                                                                                                                                                                'CYBER SECURITY FOUNDATION': 843,
#                                                                                                                                                                                                                                                                                                                                 'PUBLIC POLICY (PUAD 620)': 2491,
#                                                                                                                                                                                                                                                                                                                                 'LEGAL WRITING AND ANALYSIS': 1937,
#                                                                                                                                                                                                                                                                                                                                  'CPSY 655 G01 - ADDICTION COUNSELING THEORY AND APPROACH': 762,
#                                                                                                                                                                                                                                                                                                                                   'COMM110 INFORMATION & DIGITAL LITERACY': 655,
#                                                                                                                                                                                                                                                                                                                                    'EPIDEMIOLOGY FOR PUBLIC HEALTH PRACTICE': 1095,
#                                                                                                                                                                                                                                                                                                                                    'INTRODUCTION OF GRADUATE STUDIES': 1727,
#                                                                                                                                                                                                                                                                                                                                     'COMMUNITY RESILIENCE': 669,
#                                                                                                                                                                                                                                                                                                                                      'PSYCHOTHERAPY NETWORKER SYMPOSIUM': 2462,
#                                                                                                                                                                                                                                                                                                                                      'JURISPRUDENCE/LEGAL HISTORY': 1862,
#                                                                                                                                                                                                                                                                                                                                      'CCJS ADMIN OF JUSTICE - CCJS 110': 478,
#                                                                                                                                                                                                                                                                                                                                       'ALCOHOL IN THE US SOCIETY': 182,
#                                                                                                                                                                                                                                                                                                                                        'ECONOMICS FOR BUSINESS': 925,
#                                                                                                                                                                                                                                                                                                                                         'PRPA 620 GLOBAL PUBLIC RELATIONS': 2425,
#                                                                                                                                                                                                                                                                                                                                          'WEAPONS OF MASS DESTRUCTION AND THE NEW TERRORISM': 2868,
#                                                                                                                                                                                                                                                                                                                                           'GOVT 403: LAW MORALITY AND WAR': 1380,
#                                                                                                                                                                                                                                                                                                                                            'MANAGEMENT 630- ORGANIZATIONAL THEORY & BEHAVIOR': 1980,
#                                                                                                                                                                                                                                                                                                                                             'NETWORKING 2': 2165,
#                                                                                                                                                                                                                                                                                                                                             'PUBLIC AMINISTRATION IN SOCIETY': 2482,
#                                                                                                                                                                                                                                                                                                                                              'MARYLAND SUICIDAL CLIENTS AND SELF-HARM BEHAVIORS': 2003,
#                                                                                                                                                                                                                                                                                                                                              'POLITICAL VIOLENCE AND TERRORISM': 2347,
#                                                                                                                                                                                                                                                                                                                                               'SOCIAL WORK 250': 2641,
#                                                                                                                                                                                                                                                                                                                                                'ADMINISTRATIVE LEADERSHIP': 98,
#                                                                                                                                                                                                                                                                                                                                                 'DEMOCRACY AND EDUCATION: THREE PHILOSOPHICAL PERSPECTIVES': 866,
#                                                                                                                                                                                                                                                                                                                                                  'PREPARING STRONG GRANT WRITING APPLICATION': 2362,
#                                                                                                                                                                                                                                                                                                                                                  'HISTORY OF THE CONTEMPORARY WORLD': 1466,
#                                                                                                                                                                                                                                                                                                                                                   'INTERMEDIATE CARBINE COURSE': 1662,
#                                                                                                                                                                                                                                                                                                                                                    'COMPUTER PROGRAMMING': 686,
#                                                                                                                                                                                                                                                                                                                                                    'CMSC 495  TRENDS PROJECTS COMP SCIENCE': 622,
#                                                                                                                                                                                                                                                                                                                                                     'ACT IMMERSION RETREAT': 86,
#                                                                                                                                                                                                                                                                                                                                                      'EVENT PLANNING': 1129,
#                                                                                                                                                                                                                                                                                                                                                      'UNIX/LINUX SYSTEM ADMINISTRATION': 2847,
#                                                                                                                                                                                                                                                                                                                                                       'MATH 103, FOUNDATIONS OF MATHEMATICS': 2027,
#                                                                                                                                                                                                                                                                                                                                                        'THEORIES AND TECHNIQUES IN COUNSELING SUPERVISION': 2807,
#                                                                                                                                                                                                                                                                                                                                                         'NURSING CONCEPTS 1': 2196,
#                                                                                                                                                                                                                                                                                                                                                          'BOS 3001 FUNDAMENTALS OF OCCUPATIONAL SAFETY AND HEALTH': 383,
#                                                                                                                                                                                                                                                                                                                                                           'INTRO TO PROBABILITY & STATIST - 50259 - BUSI 230 - B11': 1711,
#                                                                                                                                                                                                                                                                                                                                                            'TLPL 488B - SPECIAL TOPICS IN EDUCATION': 2821,
#                                                                                                                                                                                                                                                                                                                                                             '40 HOUR BASIC MEDIATION TRAINING': 28
#                                                                                                                                                                                                                                                                                                                                                             , 'QSO-510-Q3373 QUANTITATIVE ANALYSIS': 2515,
#                                                                                                                                                                                                                                                                                                                                                              'SOWK 369- CONTEMPORARY ISSUES, CULTURES, AND SOCIAL WORK PRACTICES IN AGING': 2670,
#                                                                                                                                                                                                                                                                                                                                                              'CMST 325 IMAGE EDITING': 629,
#                                                                                                                                                                                                                                                                                                                                                               'MATERNAL CHILD NURSING': 2017,
#                                                                                                                                                                                                                                                                                                                                                               'THE DIFFICULT AIRWAY COURSE: EMS': 2786,
#                                                                                                                                                                                                                                                                                                                                                                'JURI 570 - AMERICAN BUSINESS LAW': 1860,
#                                                                                                                                                                                                                                                                                                                                                                 'CRIME SCENE INVESTIGATIONS': 776,
#                                                                                                                                                                                                                                                                                                                                                                 'CS 204 - PROFESSIONAL PRESENCE': 822,
#                                                                                                                                                                                                                                                                                                                                                                  'CENTER FOR EXECUTIVE COACHING EXECUTIVE COACH CERTIFICATION SEMINAR': 493,
#                                                                                                                                                                                                                                                                                                                                                                  'SPM 3012- SPORTS AND SOCIETY': 2701,
#                                                                                                                                                                                                                                                                                                                                                                  'TELECOMMUNICATIONS INDUSTRY, STRUCTURE AND ENVIRONMENT.': 2777,
#                                                                                                                                                                                                                                                                                                                                                                  'PUBLIC PROGRAM EVALUATION  PUAD-629': 2495,
#                                                                                                                                                                                                                                                                                                                                                                   'BUS 679 - MBA PROJECT PROPOSAL': 404,
#                                                                                                                                                                                                                                                                                                                                                                    'CLINICAL PSYCHIATRIC DIAGNOSTICS AND MANAGEMENT OF ADULTS': 579,
#                                                                                                                                                                                                                                                                                                                                                                     "GLOCK OPERATOR'S COURSE": 1365,
#                                                                                                                                                                                                                                                                                                                                                                      'ASPPA NATINAL CONFERENCE': 266,
#                                                                                                                                                                                                                                                                                                                                                                      'PUAD 524 - PUBLIC BUDGETING': 2466,
#                                                                                                                                                                                                                                                                                                                                                                       'BMGT350 MARKETING PRINCIPLES AND ORGANIZATION': 373,
#                                                                                                                                                                                                                                                                                                                                                                        'COUNSELING ADDICTIVE DISORDERS': 743,
#                                                                                                                                                                                                                                                                                                                                                                        'AMERICAN ASSOCIATION OF DIABETES EDUCATORS ONLINE CORE CONCEPTS COURSE': 194,
#                                                                                                                                                                                                                                                                                                                                                                         'SATELLITE COMMUNICATION SYSTEMS': 2584,
#                                                                                                                                                                                                                                                                                                                                                                          'FSEL 630: ONLINE INVESTIGATIONS: STRATEGY AND TECHNIQUES': 1281,
#                                                                                                                                                                                                                                                                                                                                                                           'CM 310 - COMMUNICATION AND CONFLICT': 584,
#                                                                                                                                                                                                                                                                                                                                                                            'ACCT 422 AUDITING THEORY AND PRACTICE': 77,
#                                                                                                                                                                                                                                                                                                                                                                             'HUMAN GROWTH AND DEVELOPEMENT': 1554,
#                                                                                                                                                                                                                                                                                                                                                                              'SPAN 204 - 0301': 2678,
#                                                                                                                                                                                                                                                                                                                                                                              'CRJ 303 - ADMIN OF CRIMINAL JUSTICE ORGANIZATIONS': 812,
#                                                                                                                                                                                                                                                                                                                                                                               'FUNDAMENTALS OF NURSING CONCEPTS': 1300,
#                                                                                                                                                                                                                                                                                                                                                                               'BUS 689 - MBA PROJECT EXECUTION': 405,
#                                                                                                                                                                                                                                                                                                                                                                                "ARMORER'S COURSE": 250,
#                                                                                                                                                                                                                                                                                                                                                                                'LBSC791 DESIGNING PRINCIPLED INQUIRY': 1896,
#                                                                                                                                                                                                                                                                                                                                                                                 'WRITING CLASS': 2904,
#                                                                                                                                                                                                                                                                                                                                                                                  'DATABASE CONCEPTS': 854,
#                                                                                                                                                                                                                                                                                                                                                                                  'CSEC 670 CYBERSECURITY CAPSTONE': 828,
#                                                                                                                                                                                                                                                                                                                                                                                  'CONTRACTS I': 724,
#                                                                                                                                                                                                                                                                                                                                                                                   'CERTIFIED SOCIAL MEDIA INTELLIGENCE EXPERT': 509,
#                                                                                                                                                                                                                                                                                                                                                                                    "MASTER'S IN PUBLIC HEALTH (MPA)": 2009,
#                                                                                                                                                                                                                                                                                                                                                                                     'DATA SCIENCE AND BUSINESS INTELLIGENCE': 852,
#                                                                                                                                                                                                                                                                                                                                                                                     'AMERICAN SIGN LANGUAGE IV': 212,
#                                                                                                                                                                                                                                                                                                                                                                                     'PROJECT MANAGER': 2420,
#                                                                                                                                                                                                                                                                                                                                                                                     'IFSM201- CONCEPTS AND APPLICATIONS OF INFORMATION TECHNOLOGY': 1601,
#                                                                                                                                                                                                                                                                                                                                                                                      '32 ANNUAL INFECTIOUS DISEASES IN CHILDREN SYMPOSIUM': 25,
#                                                                                                                                                                                                                                                                                                                                                                                       'JUSTICE IN A MULTI CULTURAL SOCIETY': 1863,
#                                                                                                                                                                                                                                                                                                                                                                                        'PEDIATRIC AND ADOLESCENT GYNECOLOGY': 2287,
#                                                                                                                                                                                                                                                                                                                                                                                         'COMMUNICATING, PROBLEM SOLVING, AND LEADING IN CYBERSECURITY': 658,
#                                                                                                                                                                                                                                                                                                                                                                                          'CRIMINAL PRODURE CRMJ 329': 795,
#                                                                                                                                                                                                                                                                                                                                                                                           'THE COMING PLAGUE: PUBLIC HEALTH PROSPECTIVES': 2784,
#                                                                                                                                                                                                                                                                                                                                                                                            'COMP II: WRITING FOR BUSINESS': 671,
#                                                                                                                                                                                                         'PROFESSIONALISM & COMMUNICATION IN NURSING': 2404, 'BSN499 CAPSONE PROJECT': 388, 'EMERGENCY SERVICE RESOURCE MANAGEMENT': 1008, 'FORENSIC SOCIAL WORK CERTIFICATE PROGRAM': 1240, 'COMPUTER SCIENCE I': 688, 'DIGITAL MEDIA & MARKETING': 881, 'HRM 530 - STRATEGIC HUMAN RESOURCE MGT': 1507, 'HSA 530 HEALTH SERVICES HUMAN RESOURCES': 1527, 'INVESTIGATIVE INTERVIEWING AND ADVANCED INTERROGATION': 1809, '413 DATA ANALYSIS SEMINAR': 31, '412 METHODS OF RESEARCH': 30, 'CS 528 ARTIFICIAL INTELLIGENCE': 824, 'EMERGENCY AND DISASTER THEORY EDMG502': 999, 'INTRODUCTION TO CREATIVE ARTS': 1739, 'CCJS 230 - INTRODUCTION TO CORRECTIONS': 463, 'DBST 663 - DISTRIBUTED DATABASE MANAGEMENT SYSTEMS': 858, 'HLTH 230 CRN 25038': 1474, 'EDUC 6160 EARLY CHILDHOOD DEVELOPMENT': 951, 'CORRECTIONS': 734, 'GERMAN 1': 1333, 'CRJ 350 - TECHNOLGY APPLICATIONS IN CRIMINAL JUSTICE': 814, 'GLOCK 2 DAY ADVANCEC ARMORERS COURSE- AT GLOCK FACTORY': 1358, 'PACE 111T  PROGRAM AND CAREER EXPLORATION IN TECHNOLOGY': 2261, 'ORGANIZATIONAL DEVELOPMENT AND CHANGE': 2243, 'BMGT310 INTERMEDIATE ACCONTING': 370, 'HSMG 701-HEALTH ECONOMICS- CLASS NUMBER 4770': 1529, 'CANNABIS SCIENCE AND MEDICINE CERTIFICATE PROGRAM': 451, 'POLITICAL, ETHICAL AND LEGAL FOUNDATIONS OF EMERGENCY': 2348, 'BIOLOGY 204': 342, 'CRIME PREVENTION STRATEGIES': 773, 'EDUC 6005 FOUNDATIONS: EARLY CHILDHOOD STUDIES': 950, 'GENEALOGICAL PRINCIPLES': 1315, 'PCN-622 PRE-PRACTICUM': 2281, 'PRECALCULUS': 2360, 'BUSI 987 DBA DISSERTATION I': 411, 'HEALTH CARE POLICY, LAW AND ETHICS': 1409, 'ASPPA WEBINAR: ADVANCES RMDS': 268, 'BEHS 103 TECHNOLOGY IN CONTEMPORARY SOCIETY': 306, 'INTRODUCTION TO RESEARCH(LIBS 150)': 1789, 'ADVANCED GEOSPATIAL ANALYSIS': 133, 'HUMAN ANATOMY AND PHYSIOLOGY HSC 110-G01': 1544, 'SOC 1213 - SOCIETY, INTERACTION AND THE INDIVIDUAL': 2628, 'DBST 652 - ADVANCED RELATIONAL / OBJECT - RELATIONAL DATABASE SYSTEMS': 857, 'DIVERSITY AWARENESS BEHS 220': 899, 'BASIC HEALTH ASSESSMENT': 292, 'CMSC 405 COMPUTER GRAPHICS': 620, 'HRMN 300 5160 HUMAN RESOURCE MANAGEMENT': 1512, 'CS 330 - OBJECT ORIENTED PROGRAMMING AND DESIGN': 823, 'AMERICAN POLICING': 204, 'BMGT340 BUSINESS FINANCE': 372, 'BEHS 220- DIVERSITY AWARENESS': 310, 'INTRODUCTION TO HEALTH POLICY AND SERVICES': 1761, 'MASTER ELECTRICAL CALCULATION&MASTER EXAM PREP': 2005, 'ELEMENTS OF SUPERVISION': 990, 'FES 3720- STRATEGIC PLANNING FOR FES': 1166, 'HSA 515 HEALTH CARE POLICY, LAW AND ETHICS': 1526,
#                                                                                                                                                                                                         'PCN-622B PRACTICUM/INTERNSHIP 2': 2282, 'FUNDAMENTALS OF NURSING': 1299,
#                                                                                                                                                                                                          "ASPPA WEBINAR: CYBERSECURITY: WHAT YOU DON'T KNOW AND DO WILL HURT YOU": 269,
#                                                                                                                                                                                                           'DATABASE DESIGN AND IMPLEMENTATION': 855, 'FIRE & EMERGENCY SCENE OPERATIONS': 1192, 'JURI 540 - CRIMINAL LAW': 1859,
#                                                                                                                                                                                                            'SOCIAL CHANGE IN ACTION: PREVENTION, CONSULTATION, AND ADVOCACY.': 2631,
#                                                                                                                                                                                                            'ETHICAL AND LEGAL ISSUES IN COUNSELING': 1104,
#                                                                                                                                                                                                             'THEMIS MARYLAND BAR/LAW COURSE': 2804,
#                                                                                                                                                                                                              'HUMANITIES': 1571,
#                                                                                                                                                                                                               'ACCOUNTING 453-0 ACCOUNTING PROJECT': 60, 'CRITICAL READING/WRITING/RESEARCH': 806,
#                                                                                                                                                                                                               'ENCE 641 ADVANCED FOUNDATIONS SYSTEMS': 1035,
#                                                                                                                                                                                                               'EMERGENCY MANAGEMENT MITIGATION AND RECOVERY': 1002,
#                                                                                                                                                                                                                'HISTORY OF WESTERN ART 1 - ARTH 372': 1471,
#                                                                                                                                                                                                                 'BIOMECHANICS OF HUMAN MOTION': 345,
#                                                                                                                                                                                                                  'DISPUTE RESOLUTION & NEGOTIATION (2 CREDITS); LAW & POLICY CYBERSECURITY (3 CREDITS)': 892,
#                                                                                                                                                                                                                   'HLSS523 DOMESTIC TERRORISM AND EXTREMIST': 1473,
#                                                                                                                                                                                                                   'CMIT 454 - CISCO CCNA SECURITY': 602,
#                                                                                                                                                                                                                    'HN 499-01: BACHELORS CAPSTONE FOR HUMAN SERVICES': 1482,
#                                                                                                                                                                                                                     'FW 370 CONSERVATION GENETICS': 1306,
#                                                                                                                                                                                                                     'GLOBAL SECURITY EXCHANGE': 1353,
#                                                                                                                                                                                                                      'CONTEMPORARY ISSUES IN AGING - GERO 100': 714,
#                                                                                                                                                                                                                      'WRITING FOR HEALTH PROFESSIONALS': 2905,
#                                                                                                                                                                                                                      'PROGRAMMING CONCEPTS AND PROBLEM SOLVING': 2408,
#                                                                                                                                                                                                                       'NURSING HEALTH & ILLNESS': 2197,
#                                                                                                                                                                                                                        'IT-410 CERTIFIED INFORMATION SYSTEMS SECURITY PRFESSIONAL III': 1835,
#                                                                                                                                                                                                                         'MICROCOMPUTER ESSENTIALS': 2114,
#                                                                                                                                                                                                                         'MOTOR DEVELOPMENT': 2131,
#                                                                                                                                                                                                                          'INTERNET AND NETWORK SECURITY': 1677,
#                                                                                                                                                                                                                           'OASIS PSYCHIATRY CONFERENCE': 2220, 'ARABIC 204': 246,
#
#                                                                                                                                                                                                                           'TLPL 479C - FIELD EXPERIENCE IN EDUCATION': 2820,
#                                                                                                                                                                                                                            'HRM 517 - MANAGING HUMAN RESOURCE PROJECTS': 1506,
#                                                                                                                                                                                                                           'BUSINESS LAW I - BMGT 380 6382': 430,
#                                                                                                                                                                                                                           'CMSC 451   DESIGN COMPUTER ALGORITHMS': 621,
#                                                                                                                                                                                                                            'NETWORK SECURITY': 2164,
#                                                                                                                                                                                                                            'FREN 204 - 0101': 1262,
#                                                                                                                                                                                                                            'ASC WEBINAR:  ETHICS_EMPLOYEE BENEFITS PRACTIONERS': 264,
#                                                                                                                                                                                                                             'BASIC MEDIATION COURSE': 293,
#                                                                                                                                                                                                                             'PROBLEM OF PRACTICE': 2398,
#                                                                                                                                                                                                                              'HSA 510 HEALTH ECONOMICS': 1525,
#                                                                                                                                                                                                                               'CELL BIOLOGY AND PHYSIOLOGY': 486,
#                                                                                                                                                                                                                               'QUANTITATIVE RESEARCH METHODS 720': 2518,
#                                                                                                                                                                                                                               'DTBS 652': 907,
#                                                                                                                                                                                                                                'MULTICULTURAL COUNSELING': 2146,
#                                                                                                                                                                                                                                'PUBLIC SAFETY LEGAL ISSUES': 2504,
#                                                                                                                                                                                                                                 'MGMT 615 (9080) INTERCULTURAL COMMUNICATION & LEADERSHIP (2202)': 2093,
#                                                                                                                                                                                                                                'PHYSICS 122': 2331,
#                                                                                                                                                                                                                                 'PUBLIC SAFETY RESEARCH AND TECHNOLOGY PSAD 410': 2507,
#                                                                                                                                                                                                                                  'VIDEO EVIDENCE TRAINING SYMPOSIUM': 2859,
#                                                                                                                                                                                                                                  'HMGT 310 HEALTH CARE POLICIES': 1478,
#                                                                                                                                                                                                                                   'HOME INSPECTIONS': 1485,
#                                                                                                                                                                                                                                   'PACE111': 2262,
#                                                                                                                                                                                                                                   'STATISTICS FOR MANGERIAL DECISION MAKING': 2716,
#                                                                                                                                                                                                                                    'BMGT  465 ORGANIZATIONAL DEVELOPMENT AND TRANSFORMATION': 355,
#                                                                                                                                                                                                                                   'MATH 105': 2028,
#                                                                                                                                                                                                                                    'MATH 300: STATISTICS': 2037,
#                                                                                                                                                                                                                                     'PSYCH 100 & STAT 200': 2445,
#                                                                                                                                                                                                                                      'BSN 410': 387,
#                                                                                                                                                                                                                                       'NURSING, QUALITY IMPROVEMENT': 2207,
#                                                                                                                                                                                                                                       'DESIGN CONSIDERATIONS': 868,
#                                                                                                                                                                                                                                       'WRTG 112 7357 ACADEMIC WRITING II': 2913,
#                                                                                                                                                                                                                                       'ECON 522 PUBLIC FINANCE': 919,
#                                                                                                                                                                                                                                        'FES 3153- FES COMMUNICATION AND INFORMATIONAL TECHNOLOGY': 1165,
#                                                                                                                                                                                                                                         'CONVERSATIONAL GERMAN': 727,
#                                                                                                                                                                                                                                         'HEALTHSERVICES MARKETING': 1423,
#                                                                                                                                                                                                                                         'ILPA MEMBERS CONFERENCE': 1606,
#                                                                                                                                                                                                                                          'INFORMATION SYSTEMS PROTECTION': 1636,
#                                                                                                                                                                                                                                           'CMSC - 451 - DESIGN AND ANALYSIS OF COMPUTER ALGORITHMS': 615,
#                                                                                                                                                                                                                                            'CLINICAL MICROBIOLOGY': 577,
#                                                                                                                                                                                                                                            'LEADING ORGANIZATIONS': 1917,
#                                                                                                                                                                                                                                             'FINANCIAL MANAGEMENT FOR HEALTH CARE ORGANIZATIONS': 1183,
#                                                                                                                                                                                                                                            'ENGLISH 215: RESEARCH AND WRITING': 1066,
#                                                                                                                                                                                                                                             'PMI PROJECT MANAGEMENT PROFESSIONAL PREPARATION': 2335,
#                                                                                                                                                                                                                                             'PHL 1010: CRITICAL THINKING': 2325,
#                                                                                                                                                                                                                                             'GERO 342 - LONG_TERM CARE ADMINISTRATION': 1335,
#                                                                                                                                                                                                                                              'STANDARD ENGLISH GRAMMAR': 2707,
#                                                                                                                                                                                                                                              'FARSI BEGINNER 1': 1148,
#                                                                                                                                                                                                                                               'AR15/M4 ARMORER': 242,
#                                                                                                                                                                                                                                                'HEALTH CARE HUMAN RESOURCE MNGT': 1406,
#                                                                                                                                                                                                                                                 'ACCOUNTING 220: PRINCIPLES OF ACCOUNTING 1': 50,
#                                                                                                                                                                                                                                                  'IBMS 504': 1584,
#                                                                                                                                                                                                                                                  'BSCI 223': 385,
#                                                                                                                                                                                                                                                   'AUDIO PRODUCTION TECHNIQUES': 278,
#                                                                                                                                                                                                                                                    'DIGITAL VIDEO EDITING': 886,
#                                                                                                                                                                                                                                                     'INTRODUCTION TO NEWS WRITING (JOUR 201)': 1774,
#                                                                                                                                                                                                                                                    'ENGL 102': 1049,
#                                                                                                                                                                                                                                                     'MATH 115': 2033,
#                                                                                                                                                                                                                                                      'PBIO 602': 2274,
#                                                                                                                                                                                                                                                      'PHOTOSHOP FOR GRAPHICS & PHOTO': 2327,
#                                                                                                                                                                                                                                                       'CHEM 121': 526, 'CPA REVIEW COURSE': 757,
#                                                                                                                                                                                                                                                        'CHEM 131': 527,
#                                                                                                                                                                                                                                                         'TELEVISION PRODUCTION': 2779,
#                                                                                                                                                                                                                                                         'HLTH 371': 1475,
#                                                                                                                                                                                                                                                         'FREN 387': 1263,
#                                                                                                                                                                                                                                                         'IBMS 501': 1583,
#                                                                                                                                                                                                                                                         'INTRODUCTION TO GRAPHIC COMMUNICATION (GRCO 100)': 1759,
#                                                                                                                                                                                                                                                          'DIGITAL PHOTOGRAPHY I': 884, 'ENCE 627': 1034,
#                                                                                                                                                                                                                                                           'CONVERSATIONAL GERMAN II': 728,
#                                                                                                                                                                                                                                                           'HLTH-441': 1476,
#                                                                                                                                                                                                                                                           'HISTORICAL PERSPECTIVES OF HIGHER EDUCATION': 1449,
#                                                                                                                                                                                                                                                            'FARSI BEGINNER 3': 1151,
#                                                                                                                                                                                                                                                             'CONFERENCE': 704,
#                                                                                                                                                                                                                                                           'FIRE PROTECTION HYDRAULIC AND WATER': 1218,
#                                                                                                                                                                                                                                                           'CST 630 ADVANCED CYBER EXPLOITATION AND MITIGATION METHODOLOGIES': 832,
#                                                                                                                                                                                                                                                            'CCJS 345': 468,
#                                                                                                                                                                                                                                                             'ENVIRONMENTAL ECONOMICS AND POLICY': 1089,
#                                                                                                                                                                                                                                                             'BMS 13500 - PHYSIOLOGY I': 376,
#                                                                                                                                                                                                                                                             'CRIME SCENE, FORENSICS, AND EVIDENCE COLLECTION': 777,
#                                                                                                                                                                                                                                                             'AMERICAN PUBLIC POLICY': 207,
#                                                                                                                                                                                                                                                              'GLOCK ADVANCED ARMORER COURSE - AA': 1359,
#                                                                                                                                                                                                                                                              'LEGAL ASPECTS OF CONTRACTING': 1927, 'COMMUNITY HEALTH NURSING': 667,
#                                                                                                                                                                                                                                                               'ACADEMIC READING II - ELAR 980': 42,
#                                                                                                                                                                                                                                                                'COGNITIVE BEHAVIORAL THERAPY INTENSIVE TRAINING COURSE': 637,
#                                                                                                                                                                                                                                                                'CLINICAL MEDICINE I': 576,
#                                                                                                                                                                                                                                                                 'BUSO 620 STRATEGIC INFORMATION SYSTEMS': 444,
#                                                                                                                                                                                                                                                                  'SOCIAL WORK 480': 2642,
#                                                                                                                                                                                                                                                                   'ADVANCED FORCE SCIENCE SPECIALIST COURSE': 131,
#                                                                                                                                                                                                                                                                   'CYBERSECURITY CAPSTONE': 844,
#                                                                                                                                                                                                                                                                   'NR.120.502 (8301) FOUNDATIONS OF NURSING PRACTICE': 2170,
#                                                                                                                                                                                                                                                                    'COMPUTER SCIENCE I(CMSC 201)': 689,
#                                                                                                                                                                                                                                                                     'ROBERT BORKENSTEIN COURSE ON ALCOHOL AND HIGHWAY SAFETY: TESTING, RESEARCH, AND LITIGATION - ONLINE': 2569,
#                                                                                                                                                                                                                                                                      'LSTD516 - HOMELAND SECURITY AND THE LAW': 1965,
#                                                                                                                                                                                                                                                                      'RED DOT PISTOL: FUNDAMENTALS INSTRUCTOR 2-DAY COURSE / *LEO ONLY*': 2536,
#                                                                                                                                                                                                                                                                      'ADVANCED SUPERVISOR LIABILITY COURSE': 151,
#                                                                                                                                                                                                                                                                       'PURCHASING AND MATERIALS MANAGEMENT': 2511,
#                                                                                                                                                                                                                                                                        'MRKT 354 INTEGRATED MARKETING COMMUNICATIONS': 2138,
#                                                                                                                                                                                                                                                                        'ADVANCED PROFESSIONAL WEB TECHNOLOGIES': 141,
#                                                                                                                                                                                                                                                                         'HUMAN SERVICE AGENCIES AND THE LAW': 1568,
#                                                                                                                                                                                                                                                                          'LSTD502 CRIMINAL LAW': 1964, 'FARSI BEGINNER 3.2': 1152,
#                                                                                                                                                                                                                                                                         'BUSO 602 FINANCIAL ACCOUNTING': 443,
#                                                                                                                                                                                                                                                                          'PACE 111C': 2260, 'FOUND HUMAN COMMUNICATION - COMM 108': 1243,
#                                                                                                                                                                                                                                                                           'BEHS 364 6981 ALCOHOL IN U.S. SOCIETY': 312,
#                                                                                                                                                                                                                                                                            'RECR 611 CONCEPTS AND FOUNDATIONS OF LEISURE': 2533,
#                                                                                                                                                                                                                                                                            'RECR 651 ORGANIZATIONAL BEHAVIOR AND LEADERSHIP IN RECREATION & PARKS MANAGEMENT': 2534,
#                                                                                                                                                                                                                                                                             'FIRE PREVENTION ORGANIZATION AND MANAGEMENT': 1216,
#                                                                                                                                                                                                                                                                              'THE ROBERT F. BORKENSTEIN COURSE ON ALCOHOL, AND HIGHWAY SAFETY': 2799,
#                                                                                                                                                                                                                                                                              'ORGANIZATIONAL DYNAMICS AND HUMAN BEHAVIOR': 2244,
#                                                                                                                                                                                                                                                                               'PUAD, PUBLIC ADMINISTRATION': 2477,
#                                                                                                                                                                                                                                                                               'COUN 504 COUNSELING TECHNIQUES': 737,
#                                                                                                                                                                                                                                                                                'VM 10500 - INTRODUCTION TO VETERINARY TECHNOLOGY-DL': 2861,
#                                                                                                                                                                                                                                                                               'HUMAN GROWTH DEVELOPMENT': 1556,
#                                                                                                                                                                                                                                                                                'CMIT 350': 597, 'COMM 300': 651,
#                                                                                                                                                                                                                                                                                 'PEDESTRIAN/BICYCLE CRASH INVESTIGATION - LEVEL I': 2286,
#                                                                                                                                                                                                                                                                                  'INTRODUCTION TO PRIVATE EQUITY': 1781,
#                                                                                                                                                                                                                                                                                  'RED DOT PISTOL: FUNDAMENTALS INSTRUCTOR 2-DAY COURSE': 2535,
#                                                                                                                                                                                                                                                                                   'APPLIED RESEARCH PROJECT IN ADMINISTRATION': 236,
#                                                                                                                                                                                                                                                                                   'INTRODUCTION TO SPANISH': 1797,
#                                                                                                                                                                                                                                                                                    'MANAGEMENT 650 STATISTICS FOR MANAGERIAL DECISION MAKING': 1981,
#                                                                                                                                                                                                                                                                                    'HIST 125': 1437,
#                                                                                                                                                                                                                                                                                    'THE STREET SMART COP/PRO-ACTIVE PATROL TACTICS': 2800,
#                                                                                                                                                                                                                                                                                    'ASCM 628 CONTRACT PRICING AND NEGOTIATIONS': 265,
#                                                                                                                                                                                                                                                                                    'INTERNAL AFFAIRS TRAINING PROGRAM': 1669,
#                                                                                                                                                                                                                                                                                    'ADMINISTRATIVE THEORY': 99,
#                                                                                                                                                                                                                                                                                    'BIO HUMAN ANATOMY AND PHYSIOLOGY': 327,
#                                                                                                                                                                                                                                                                                    'DATA DRIVEN BUSINESS DECISIONS': 851,
#                                                                                                                                                                                                                                                                                     'BMS 13600': 377,
#                                                                                                                                                                                                                                                                                     'MASTER OF SCIENCE IN CYBERSECURITY LAW': 2008,
#                                                                                                                                                                                                                                                                                     'MBA 610 LEADING ORGANIZATIONS AND PEOPLE': 2051,
#                                                                                                                                                                                                                                                                                      'CMIS 102': 586,
#                                                                                                                                                                                                                                                                                      'FS208 LEGAL ASPECTS OF EMERGENCY SERVICES': 1269,
#                                                                                                                                                                                                                                                                                     'ENGL 103 TECHNICAL COMMUNICATIONS FOR PROFESSIONS': 1050,
#                                                                                                                                                                                                                                                                                     'ACC599: GRADUATE ACCOUNTING CAPSTONE': 45,
#                                                                                                                                                                                                                                                                                     'ADMINISTRATION, GLOBALIZATION AND MULTICULTURALISM': 97,
#                                                                                                                                                                                                                                                                                      'PRO 600 COMMUNICATING, PROBLEM SOLVING, AND LEADING IN PROFESSIONAL FIELDS': 2396,
#                                                                                                                                                                                                                                                                                      'MEDS 511': 2065,
#                                                                                                                                                                                                                                                                                       'FORCE SCIENCE CERIFICATION': 1232,
#                                                                                                                                                                                                                                                                                       'BORKENSTEIN COURSE ON ALCOHOL AND HIGHWAY SAFETY: TESTING, RESEARCH AND LITIGATION': 382,
#                                                                                                                                                                                                                                                                                       'SCMT - SECURITY ARCHITECTURE': 2590,
#                                                                                                                                                                                                                                                                                       'FORCE SCIENCE ANALYST CERTIFICATION': 1231,
#                                                                                                                                                                                                                                                                                        'TELECOMUNICATION AND NETWORKING': 2778,
#                                                                                                                                                                                                                                                                                         'ELEMENTARY STATISTICS': 984,
#                                                                                                                                                                                                                                                                                         'MASTERING THE ART OF TECHNICAL WRITING': 2010,
#                                                                                                                                                                                                                                                                                        'PYTHON PROGRAMMING - CMSC 206': 2512,
#                                                                                                                                                                                                                                                                                        'VCQB INSTRUCTOR': 2853,
#                                                                                                                                                                                                                                                                                         'JUSTICE INSTITUTIONS': 1864,
#                                                                                                                                                                                                                                                                                          'AR15 ARMORERS COURSE LEVEL 1': 241,
#                                                                                                                                                                                                                                                                                          'IFSM 300 INFORMATION SYSTEMS IN ORGANIZATIONS': 1597,
#
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'REALISTIC DE-ESCALATION INSTRUCTOR COURSE': 2526,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'NURSING RESERACH': 2206,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                       'STRUCTURAL COLLAPSE TECHNICIAN': 2735,
#                                                                                                                                                                                                                                                                                                                                                                                                                                             'ETHICS AND CULTURAL COMPETENCY : 1-DAY INTENSIVE TRAINING': 1111,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         'INTERNAL AFFAIRS INVESTIGATIONS': 1668,
#                                                                                                                                                                                                                                                                                                                                                                                                                                             'IO578 BEYOND COMPLIANCE: BUILDING ETHICAL ORGANIZATIONS': 1814,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                           'ETHICAL THEORIES AND PROBLEMS': 1109,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                            'BORKENSTEIN ALCOHOL COURSE': 379,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'WRTG 394 7376 ADVANCED BUSINESS WRITING': 2920,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'INTRODUCTION TO ANIMATION': 1728,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'BMS 11500 - ANATOMY FOR VETERINARY TECHNICIANS I - DL': 375,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'EH 1020 ENGLISH COMPOSITION II': 962,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'PERSPECTIVES IN DIVERSITY & EQUITY EDUC 6164': 2305,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'SOCIAL MEDIA MARKETING TACTICS AND APPLICATIONS': 2633,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                 'CMIT 440': 600,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'AR15/M4 ARMORER COURSE': 243,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                   'FIRE PERSONAL MANAGEMENT': 1213,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'DISSERTATION LITERATURE REVIEW': 896,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                     'WRITTING FOR PROFESSIONALS': 2907,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                      'PSAD 495 PUBLIC SAFETY ISSUES AND CHALLANGES': 2429,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                      'QDRO TRAINING & CERTIFICATION PROGRAM': 2514,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                       'MEDS 517': 2067,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                        'ACCOUNTING 311 - INTERMEDIATE ACOCUNTING II': 55,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                         'AGILE PROJECT MANAGEMENT WITH SCRUM': 164, 'TOTAL TOX COURSE': 2826,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                          'DISCIPLESHIP MINISTRIES 500 - 3 CREDIT HOURS': 889,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                           'DEFINED BENEFIT PLAN TRAINING AND CERTIFICATION PROGRAM': 865,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                            'HRMD 665 - MANAGING VIRTUAL & GLOBAL TEAMS': 1510,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                             'ACC562: ADVANCED AUDITING': 44,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                             'PHIL-241': 2321,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                              'ACCOUNTING 320 FRADU DETECTION AND DETERRANCE': 56,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                               'VICTIMOLOGY:THE VICTIM AND THE LAW': 2858, 'BUSI 740': 410,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                'BORKENSTEIN ALCOHOL COURSE - VIRTUAL': 380, 'FORCE SCIENCE CERTIFICATION COURSE ONLINE': 1236,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                'AMERICAN SIGN LANGUAGE II': 209,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 'ENVIRONMENT AND ECOSYSTEMS MANAGEMENT - ENMT 301': 1085,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'LEADERSHIP BBA 3651': 1904,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'CERTIFIED FINANCIAL CRIMES INVESTIGATOR CERTIFICATION (CFCI)': 501,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'CERTIFIED ECONOMIC CRIME FORENSIC EXAMINER': 500,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'CASH BALANCE TRAINING & CERTIFICATION': 458,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'UNIX OPERATING SYSTEM': 2845,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'TACTICAL MEDICAL PRACTITIONER': 2767,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'LGST 101 INTRODUCTION TO LAW': 1941,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'FORCE SCIENCE CERTIFICATION COURSE': 1235,
#                                                                                                                                                                                                                                                                                                                                                                                                                                         'NEGOTIATION SKILLS: STRATEGIES FOR INCREASED EFFECTIVENESS (ONLINE)': 2159,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'LEADING ORGANIZATIONAL CHANGE': 1916,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'APPLIED PROJECT/CAPSTONE PROJECT FOR THE OFFICE OF EMERG MGMT AND HOMELAND SEC': 234,
#
#                                                                                                                                                                                                                                                                                                                                                                                                                                         'COMMUNICATION AND COLLABORATION IN EARLY CHILDHOOD EDUC 6165': 660,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'OLD TESTAMENT ORIENTATION II   -OBST520': 2228,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'CALCULUS AND ANALYTIC GEOMETRY I': 447,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'IFSM 201': 1590,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'CRJ- 412 ETHICS IN CRIMINAL JUSTICE': 816,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'LBSC602-SERVING INFORMATION NEEDS': 1895,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                       'ENG 102': 1042,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                        'COLOR THEORY FA630': 645,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         'CONVERSATIONAL GERMAN III': 729,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                          'NEW TESTAMENT ORIENTATION I NBST-515': 2167,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                          'PSAD 416': 2428,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                           'CRJ 410 - MULTICULTURAL ISSUES IN CRIMINAL JUSTICE': 815,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                            'CCJS 201': 462,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                            'SHRM ESSENTIALS OF HR MANAGEMENT': 2613, 'NONE': 2169,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'COUNSELING SKILLS AND PRACTICE AND MT. SEMINAR': 745,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'ACCOUNTING 310 INTERMEDIATE ACCOUNTING': 54,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'WRTG 112 ACADEMIC WRITING II': 2914,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'AUDIT MANAGEMENT BUNDLE FROM IIA': 279,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'PERCEPTION IN ARTIFICAL INTELLIGENCE': 2290,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'BIO 131': 323,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'CENTER FOR EXECUTIVE COACHING': 492,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                'MGMT 640 (9080) FINACIAL DECISION MAKING FOR MANAGERS': 2097,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                 'E-MARKETING': 913,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'ECONOMIC IMPACT IN HIGHER EDUCATION': 921,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'CCJS DRUGS & CRIME': 479,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                   'GOVERNMENT 444 AMERICAN POLITICAL THEORY': 1373,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                   'STRATEGIC COMPENSATION AND BENEFITS': 2718,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'SOCIAL WORK 481': 2643,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                     'PHA 6855 - FORENSIC GENETICS': 2309,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                      'INTRODUCTION TO C++': 1732,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                       'CST 620 PREVENTION OF CYBER ATTACK METHODOLOGIES': 831,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                       'CHEM 103': 525,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'CRIME PREVENTION THROUGH ENVIORNMENTAL DESIGN': 774,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                         'LIBRARY &INFO SCIENCE': 1945,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                         'CEP EXPRESS': 495,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                          'HISTORY OF CRIME AND PUNISHMENT': 1460,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                           'DOCTORAL DISSERTATION': 902,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'POLITICS IN COMPARATIVE PERSPECTIVE': 2349,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                            'COMS 101 SPEECH COMMUNICATION': 696,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                             'RED DOT PISTOL: FUNDAMENTALS INSTRUCTOR COURSE': 2537,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                              'REGULATORY PROCESSES AND ADMINISTRATIVE LAW': 2539,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                               "AR15/M4 RIFLE ARMORER'S COURSE": 245,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                'POLICE ADMINISTRATION PSAD 304': 2342,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 'LEADERSHIP MONTGOMERY': 1911,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'PUAD 785 PUBLIC SECTOR PERFORMANCE MEASUREMENT': 2475,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   'PUBLIC PERSONNEL ADMINISTRATION PRACTICE': 2490,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'HRM533': 1509, 'AFRICAN AMERICAN HISTORY SINCE 1865': 161,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     'INTELLIGENCE AND NATIONAL SECURITY': 1647,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      'EXECUTIVE LEADERSHIP INSTITUTE': 1136,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      'MGMT 670 - STRATEGIC MANAGEMENT CAPSTONE': 2101, 'FOUNDATIONS OF RESEARCH METHODS IN ADMINISTRATION': 1257,
#
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'CMIT 326': 596,
#                                                                                                                                                                                                                                                                                                                                                                                                                                  'RESEARCH, WRITING AND MINISTRY PREP  RTCH-500': 2563,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'PSYC 100 INTRODUCTION TO PSYCHOLOGY': 2438,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'ADVANCED RESEARCH WRITING 391': 144,
#                                                                                                                                                                                                                                                                                                                                                                                                                 'ANPS 8030 SUPERVISED CLINICAL PRACTICE ACROSS THE LIFESPAN': 224,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'RISK MANAGEMENT FOR PROJECTS, PROGRAMS AND OPERATIONS': 2568,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'INTENSIVE ENGLISH': 1648,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'DISCOVERING PUBLIC HEALTH HLTH200': 891,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                       'CMST 301 DIGITAL MEDIA & SOCIETY': 627,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                        'CJUS 110 INTRO TO CRIMINAL JUSTICE': 564,
#                                                                                                                                                                                                                                                                                                                                                                                                     'PSYCHIATRIC DISORDERS IN WOMEN: DIAGNOSTIC AND TREATMENT CONSIDERATIONS ACROSS THE FEMALE LIFESPAN': 2447,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         '870 ARMORER COURSE': 33,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                          'OLD TESTAMENT ORIENTATION I': 2227,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                           'NUTR101 NUTRITION': 2210,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                            'EL206: ACADEMIC PRIOR LEARNING PORTFOLIO': 965,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'BIO 150 PRIN OF BIOL I': 324,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'CO-OCCURRING DISORDER': 631,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'APPLYING ENTREPRENEURIAL MARKETIN TO THE ENTERPRISE': 237,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'PROJECT TIME AND COST MANAGEMENT': 2421,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'PUBLIC ADMINISTRATION AND MANAGEMENT':2480,
#
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'LWRCI ARMORER COURSE': 1966,
#                                                                                                                                                                                                                                                                                                                                                                                                                                             'HMLS 406 LEGAL AND POLITICAL ISSUES OF HOMELAND SECURITY': 1481,
#                                                                                                                                                                                                                                                                                                                                                                                                                                         'CMSC - 495 - CURRENT TRENDS AND PROJECTS IN COMPUTER SCIENCE': 616,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                '401K TRAINING & CERTIFICATION PROGRAM': 29, 'CMSC140 INTRO TO PROGRAMMING': 623,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                 'ANPS 8008 ROLE FOR THE PSYCHIATRIC MENTAL HEALTH NURSE PRACTITIONER IN PROMOTING HEALTH': 223,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                  '2 DAY RDS INSTRUCTOR LEO ONLY': 6,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'CHILD SOCIAL AND EMOTIONAL GROWTH': 535,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'MEDS 512': 2066,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'ACHIEVING ITIL� FOUNDATION CERTIFICATION': 82,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'TABLEAU 3': 2766,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'ACADEMIC  ELAI990': 39,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'NSCI 120 NATURAL SCIENCES LABORATORY': 2174,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                       'GENEALOGICAL PRINCIPALS PROGRAM': 1314,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                        'ACCOUNTING 321': 58,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         "3 DAY ADVANCED ARMORER'S COURSE": 20,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         'ENGLISH 103': 1059,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         'TLMT341 LOGISTICS MANAGEMENT': 2819,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                          'SCMG201 PRINCIPLES OF SUPPLY CHAIN MANAGEMENT': 2589,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'BASIC RIDER COURSE (COURSE#: XB-918-8915(5411))': 294,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'FSCOR 603: LITIGATION THEORY AND PRACTICE': 1277,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'PSYCHO THERAPY': 2449,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                       'ARMORER COURSE:  REMINGTON 700': 249,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                        'WCF, WEB API AND SIGNALR SERVICES FOR .NET': 2867,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                        'SOCIAL THEORY': 2638,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         'CJ 481 HOMELAND SECURITY': 552,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                          'ASC 605 BASIC INFORMATION TECHNOLOGY': 263,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                          'CSCI 561: ETHICS, LEGAL ISSUES AND POLICY': 825,
#                                                                                                                                                                                                                                                                                                                                                                                                                                          'POLITICAL AND LEGAL FOUNDATIONS OF FIRE PROTECTION': 2344,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                          'GENERAL BIOLOGY 101': 1317,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                           'WRTG 393 ADVANCED TECHNICAL WRITING': 2918,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                            'FARSI 3.2': 1147,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'ASSESSMENT AND TREATMENT OF ADDICITIVE BEHAVIORS': 272,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'BMGT321 MANAGERIAL ACCOUNTING': 371,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'SPRING LIVE-FIRE TRAINING CAMP': 2704,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'TABLEAU 2': 2765,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                   'PUBLIC SPEAKING': 2508, 'THEORIES OF FAMILY SYSTEMS': 2809,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'REMINGTON 870 ARMORER COURSE': 2544,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                 'ACCOUNTING 235': 53,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'COUNSELING 505 GROUP DYNAMICS, PROCESSES, AND COUNSELING': 742,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                 'SONS OF LIBERTY GUN WORKS AR15 ARMORERS CLASS- 2 DAY': 2668,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    "ADVANCED ARMORER'S COURSE": 116,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'BUSINESS MANAGEMENT 380 - BUSINESS LAW I': 435,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'FES4014 FOUNDATIONS OF EMERGENCY MANAGEMENT': 1169,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                      'COMMUNICATION SKILLS FOR LEADERS': 662,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                       '3 DAY COMPREHENSIVE AR15 ARMORER�S COURSE': 23,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                        'PUBLIC SAFETY GRANT WRITING': 2500,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                         'WFB 6300 WILDLIFE CONSERVATION POLICY': 2880,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                          'ISM 531 CYBERSECURITY DEFENSE AND COUNTER MEASURES': 1822,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                           'ADVANCED TOPICS IN TERRORISIM AND INTELLIGENCE': 153,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                            'FORCE SCIENCE CERTIFICATION': 1233,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                             'CONDUCTING PROPER AND EFFECTIVE INVESTIGATIONS': 703,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                              'INTRODUCTION TO SCRIPTING - CMSC 135': 1790,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                   'ADVANCED VIRTUAL INTERNAL AFFAIRS CERTIFICATION PROGRAM': 157,
#                                                                                                                                                                                                                                                                                                                                                                                                                                      'CBR 600 COMMUNICATING, PROBLEM SOLVING, AND LEADING IN CYBERSECURITY': 459,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                'PHARMACOLOGY IN NURSING': 2316,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                'ENGINE COMPANY OPERATIONS I': 1046,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                'PATHOGENIC MICROBIOLOGY': 2270,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                 'INTRO TO RELIGION': 1713,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                  'FORCE SCIENCE CERTIFICATION -ONLINE COURSE': 1234,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                               'IDENTIFYING CRIMINAL VEHICLES AND OCCUPANTS': 1586,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                    'CHILD DEVELOPMENT PORTFOLIO AND SYNTHESIS': 533,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     '� LEVEL 2 DISC': 2924,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'ISM 530 ENTERPRISE CYBERSECURITY': 1821,
#
#                                                                                                                                                                                                                                                                                                                                                                                                                                                  'FES 3753 FIRE AND EMERGENCY SERVICES FINANCIAL MANAGEMENT': 1167, 'APPLICATIONS IN FIRE RESEARCH': 231,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'GLOBAL POLITICAL ECONOMY': 1351,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'ADMINISTRATION AND GOVERNMENT': 94,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'CRAFT OF EMDR THERAPY TAKING THE NEXT LEVEL': 770,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'PACE 111B PROGRAM AND CAREER EXPLORATION IN BUSINESS': 2259,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     "3 DAY ARMORER'S COURSE AR15": 22,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'NETWORKING BASICS': 2166,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'AMERICAN HISTORY II': 201,
#                                                                                                                                                                                                                                                                                                                                                                                                                                          'UC TECH & SURVIVAL - WEBINAR': 2840,
#                                                                                                                                                                                                                                                                                                                                                                                                                                        'NSCI 362 OUR ENVIRONMENT: HUMAN IMPACT AND SUSTAINABLE CHOICES': 2176,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'LEGAL TRADITIONS OF THE WORLD': 1935,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'GES 308 - ECOLOGY': 1338,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                     'WFB 6350 AQUATIC HABITAT MANAGEMENT': 2881,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    "AR15/M4 RIFLE ARMORER'S CLASS": 244,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'CJ 400 APPLIED ETHICS IN CRIMINAL JUSTICE': 551, 'MBA FUNDAMENTALS': 2055,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'LWRCI M6/IC ARMORER COURSE': 1967,
#                                                                                                                                                                                                                                                                                                                                                                                                                                                    'TLMT311 INTRODUCTION TO TRANSPORTATION MANAGEMENT': 2818, 'FUNDAMENTALS OF SUPERVISION': 1303
#
#
#
#
#
#
#
#     if request.GET['titlen'] == 'INTRODUCTION TO BUSINESS':
#         lis2.append(1731)
#     elif request.GET['titlen'] == 'MA 160':
#         lis2.append(1968)





   #if request.Get['schooln'] == 'AA':
       #lis2.append(0)
   #elif request.Get['schooln'] == 'Masters (MA/MS/MPH/etc.)':
       #lis2.append(4)













    #cost = knn.predict([lis2])

    #a = linearmodel.predict([lis])
    #b = np.array(a, dtype=float) #  convert using numpy
    #cost = [float(i) for i in a]

    cost = xgb_model.predict([lis2])
    cost = cost[0]
    cost = cost.round()
    cost = cost.astype('int')
    print(lis)


    my_list = {'lis':lis}

    print(cost)

    #return render(request,'result.html','ans':ans,'lis':lis)
    return render(request,'result.html',{'lis':lis,'cost':cost})
    #return render(request,'result.html',context=my_list)
